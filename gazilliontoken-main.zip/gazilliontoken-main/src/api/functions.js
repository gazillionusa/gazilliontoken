import { base44 } from './base44Client';


export const createPaymentIntent = base44.functions.createPaymentIntent;

export const confirmPayment = base44.functions.confirmPayment;

export const logBondPurchase = base44.functions.logBondPurchase;

export const connectWallet = base44.functions.connectWallet;

export const getLeaderboard = base44.functions.getLeaderboard;

export const sendMessage = base44.functions.sendMessage;

export const createCampaign = base44.functions.createCampaign;

export const getPartnerAnalytics = base44.functions.getPartnerAnalytics;

export const updatePartnerProfile = base44.functions.updatePartnerProfile;

export const manageTeam = base44.functions.manageTeam;

export const cryptoPayment = base44.functions.cryptoPayment;

export const walletOperations = base44.functions.walletOperations;

export const kycVerification = base44.functions.kycVerification;

export const cryptoPricing = base44.functions.cryptoPricing;

export const generateChartImage = base44.functions.generateChartImage;

export const lendingOperations = base44.functions.lendingOperations;

export const creditBureauService = base44.functions.creditBureauService;

export const generateBondCertificate = base44.functions.generateBondCertificate;

export const mintBondNFT = base44.functions.mintBondNFT;

export const getEtherscanData = base44.functions.getEtherscanData;

export const generateSavingsBondCertificate = base44.functions.generateSavingsBondCertificate;

export const purchaseSavingsBond = base44.functions.purchaseSavingsBond;

export const redeemSavingsBond = base44.functions.redeemSavingsBond;

export const createBondClass = base44.functions.createBondClass;

