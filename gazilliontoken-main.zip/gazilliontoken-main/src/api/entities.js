import { base44 } from './base44Client';


export const Bond = base44.entities.Bond;

export const Character = base44.entities.Character;

export const Job = base44.entities.Job;

export const Application = base44.entities.Application;

export const Post = base44.entities.Post;

export const Comment = base44.entities.Comment;

export const Like = base44.entities.Like;

export const Friendship = base44.entities.Friendship;

export const UserPurchase = base44.entities.UserPurchase;

export const Message = base44.entities.Message;

export const MessageThread = base44.entities.MessageThread;

export const Notification = base44.entities.Notification;

export const CivicPartner = base44.entities.CivicPartner;

export const CivicPartnerPortal = base44.entities.CivicPartnerPortal;

export const CivicCampaign = base44.entities.CivicCampaign;

export const CivicEvent = base44.entities.CivicEvent;

export const EventRSVP = base44.entities.EventRSVP;

export const CivicContact = base44.entities.CivicContact;

export const PartnerSubscription = base44.entities.PartnerSubscription;

export const MasterAdmin = base44.entities.MasterAdmin;

export const FeatureFlag = base44.entities.FeatureFlag;

export const AbuseReport = base44.entities.AbuseReport;

export const CryptoTransaction = base44.entities.CryptoTransaction;

export const WalletActivity = base44.entities.WalletActivity;

export const KYCVerification = base44.entities.KYCVerification;

export const ChartSnapshot = base44.entities.ChartSnapshot;

export const BondIssuer = base44.entities.BondIssuer;

export const Investor = base44.entities.Investor;

export const BorrowerCompany = base44.entities.BorrowerCompany;

export const BondToken = base44.entities.BondToken;

export const LoanAgreement = base44.entities.LoanAgreement;

export const PaymentSchedule = base44.entities.PaymentSchedule;

export const Collateral = base44.entities.Collateral;

export const Covenant = base44.entities.Covenant;

export const DefaultEvent = base44.entities.DefaultEvent;

export const CreditRequest = base44.entities.CreditRequest;

export const CreditReportRecord = base44.entities.CreditReportRecord;

export const CreditAccessLog = base44.entities.CreditAccessLog;

export const UnderwritingDecision = base44.entities.UnderwritingDecision;

export const Insight = base44.entities.Insight;

export const CaseStudy = base44.entities.CaseStudy;

export const ZillionBrand = base44.entities.ZillionBrand;

export const SavingsBond = base44.entities.SavingsBond;

export const UserSavingsBond = base44.entities.UserSavingsBond;

export const UserHolding = base44.entities.UserHolding;

export const PaymentTransaction = base44.entities.PaymentTransaction;



// auth sdk:
export const User = base44.auth;