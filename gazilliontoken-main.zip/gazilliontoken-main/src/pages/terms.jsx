import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Terms() {
  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <Card className="glass-effect border-white/10 bg-transparent">
          <CardHeader>
            <CardTitle className="text-3xl text-white">Terms of Service</CardTitle>
            <p className="text-gray-400">Last Updated: September 21, 2025</p>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-300">
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Applies To:</h2>
              <ul className="list-disc list-inside space-y-1 text-gray-400">
                <li>gazillionusa.com</li>
                <li>gazillionnft.com</li>
                <li>gazillioncoin.net</li>
                <li>gazillionbonds.com</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">1. Introduction</h2>
              <p>This Terms of Service Agreement (“Agreement”) governs your access to and use of the Gazillion digital platforms (collectively, the “Platform”) operated by Gazillion Bonds NFT LLC (“Gazillion,” “we,” or “us”), which facilitate the offering, minting, and management of tokenized municipal bond NFTs (“Bond NFTs”) via blockchain technology.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">2. Jurisdiction and Governance</h2>
              <p>These Terms shall be governed and construed in accordance with the laws of the State of Nevada, United States, without regard to conflict-of-law principles. You agree that any dispute arising from or relating to the use of this Platform shall be resolved exclusively in the courts of Clark County, Nevada.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">3. Scope of Services</h2>
              <p>We provide digital tools to access municipal bond offerings through blockchain-based smart contracts, including:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Smart contract issuance (ERC-721 Gazillion Standard)</li>
                <li>NFT bond minting and trading</li>
                <li>Investment dashboards and asset tracking</li>
                <li>Cross-platform wallet integration</li>
              </ul>
              <p className="mt-2">Our services span but are not limited to:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Delaware (corporate formation and compliance)</li>
                <li>California (infrastructure investment projects)</li>
                <li>Nevada (governing law and operational headquarters)</li>
                <li>Arizona (municipal project participation)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">4. No Investment or Legal Advice</h2>
              <p>Nothing on our platforms constitutes investment, legal, or tax advice. Users should consult with professional advisors before participating in any offering.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">5. Platform Eligibility</h2>
              <p>To use our services, you must:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Be at least 18 years old</li>
                <li>Not be a resident of a sanctioned jurisdiction</li>
                <li>Possess a compliant crypto wallet (MetaMask, WalletConnect, etc.)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">6. Smart Contract Terms</h2>
              <p>Bond NFTs are issued via immutable or upgradeable smart contracts on the Gazillion Chain, conforming to ERC-721 standards. Each NFT includes:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Unique token ID</li>
                <li>Face value, APY, maturity date</li>
                <li>Metadata such as project description, risk level, and jurisdiction</li>
              </ul>
              <p className="mt-2">Once issued, NFTs are non-reversible and publicly viewable on-chain.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">7. Risks & Disclaimers</h2>
              <p>Users understand and accept the risks associated with:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Volatile crypto markets</li>
                <li>Smart contract vulnerabilities</li>
                <li>Regulatory changes in securities, taxation, or blockchain law</li>
                <li>Lack of FDIC or government guarantee (unless explicitly provided for a specific bond issuance)</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">8. Payment & Fees</h2>
              <p>Gazillion accepts fiat (via Stripe or ACH) and crypto payments (USDC, ETH). Fees may include minting costs, platform service fees, and blockchain gas fees. These will be disclosed at the time of purchase.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">9. User Responsibilities</h2>
              <p>Users are solely responsible for:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Maintaining private keys and wallet security</li>
                <li>Ensuring tax compliance</li>
                <li>Ensuring participation is legal in their jurisdiction</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">10. Intellectual Property</h2>
              <p>All platform content, excluding public blockchain data, is owned by Gazillion. Unauthorized reproduction is prohibited.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">11. Termination</h2>
              <p>We reserve the right to suspend or terminate access for any violation of these terms or suspected misuse of the Platform.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">12. Contact</h2>
              <p>For questions:</p>
              <p>Email: compliance@gazillionusa.com</p>
              <p>Address: 2929 N Central Ave, Ste 1605, Phoenix, AZ 85004</p>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}