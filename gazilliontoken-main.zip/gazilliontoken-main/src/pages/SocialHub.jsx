import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Users } from 'lucide-react';

export default function SocialHubPage() {
  return (
    <div className="space-y-8">
        <div className="mb-8 p-6 rounded-lg bg-gray-800/30 text-center">
            <h1 className="text-3xl font-bold text-gradient">Social Hub</h1>
            <p className="text-gray-400 mt-2">Connect with other investors and the community.</p>
        </div>

        <Card className="bg-gray-800/50 border-teal-500/20">
            <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                    <Users className="w-6 h-6 mr-3 text-teal-400" />
                    Coming Soon
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-gray-300">The Gazillion Social Hub is under development. This will be the place to share insights, discuss investments, and connect with the community.</p>
            </CardContent>
        </Card>
    </div>
  );
}