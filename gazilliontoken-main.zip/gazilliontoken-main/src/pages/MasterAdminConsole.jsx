
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { CivicPartner } from '@/api/entities';
import { PartnerSubscription } from '@/api/entities';
import { AbuseReport } from '@/api/entities';
import { FeatureFlag } from '@/api/entities';
import { MasterAdmin } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
    Shield, 
    Users, 
    Building, 
    AlertTriangle, 
    BarChart3,
    Settings,
    Eye,
    DollarSign,
    Flag,
    Search,
    Loader2
} from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function MasterAdminConsole() {
    const [user, setUser] = useState(null);
    const [isAuthorized, setIsAuthorized] = useState(false);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('overview');
    
    // Data states
    const [partners, setPartners] = useState([]);
    const [subscriptions, setSubscriptions] = useState([]);
    const [abuseReports, setAbuseReports] = useState([]);
    const [featureFlags, setFeatureFlags] = useState([]);
    const [impersonationTarget, setImpersonationTarget] = useState('');

    const loadAdminData = useCallback(async () => {
        try {
            const [partnerData, subscriptionData, reportData, flagData] = await Promise.all([
                CivicPartner.list('-created_date'),
                PartnerSubscription.list('-created_date'),
                AbuseReport.list('-created_date', 50),
                FeatureFlag.list()
            ]);
            
            setPartners(partnerData);
            setSubscriptions(subscriptionData);
            setAbuseReports(reportData);
            setFeatureFlags(flagData);
        } catch (error) {
            console.error("Failed to load admin data:", error);
        }
    }, []);

    const checkAdminAccess = useCallback(async () => {
        try {
            const userData = await User.me();
            setUser(userData);
            
            // Check if user is master admin
            const adminRecord = await MasterAdmin.filter({ admin_user_id: userData.id });
            if (adminRecord.length > 0) {
                setIsAuthorized(true);
                loadAdminData();
            }
        } catch (error) {
            console.error("Failed to check admin access:", error);
        } finally {
            setLoading(false);
        }
    }, [loadAdminData]); // Added loadAdminData to dependency array

    useEffect(() => {
        checkAdminAccess();
    }, [checkAdminAccess]); // Added checkAdminAccess to dependency array

    const handleImpersonation = async () => {
        if (!impersonationTarget.trim()) return;
        
        try {
            // Log impersonation attempt
            console.log('Impersonating user:', impersonationTarget);
            // In real implementation, this would switch user context
            alert(`Impersonating user: ${impersonationTarget}`);
        } catch (error) {
            console.error("Impersonation failed:", error);
        }
    };

    const toggleFeatureFlag = async (flagId, enabled) => {
        try {
            await FeatureFlag.update(flagId, { is_enabled: enabled });
            setFeatureFlags(prev => prev.map(flag => 
                flag.id === flagId ? { ...flag, is_enabled: enabled } : flag
            ));
        } catch (error) {
            console.error("Failed to toggle feature flag:", error);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
            </div>
        );
    }

    if (!isAuthorized) {
        return (
            <div className="min-h-screen px-6 py-12">
                <div className="max-w-4xl mx-auto text-center">
                    <div className="glass-effect p-8 rounded-2xl border border-red-500/20">
                        <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
                        <h2 className="text-2xl font-bold text-white mb-4">Access Denied</h2>
                        <p className="text-gray-300">
                            Master Admin privileges required to access this console.
                        </p>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen px-6 py-8">
            <div className="max-w-7xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white flex items-center">
                            <Shield className="w-8 h-8 mr-3 text-cyan-400" />
                            Master Admin Console
                        </h1>
                        <p className="text-gray-400 mt-2">Platform-wide administration and monitoring</p>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                        <Dialog>
                            <DialogTrigger asChild>
                                <Button variant="outline" className="text-amber-400 border-amber-400">
                                    <Eye className="w-4 h-4 mr-2" />
                                    Impersonate User
                                </Button>
                            </DialogTrigger>
                            <DialogContent className="bg-slate-800 border-white/10 text-white">
                                <DialogHeader>
                                    <DialogTitle>Impersonate User</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                    <Input
                                        placeholder="Enter user email or ID"
                                        value={impersonationTarget}
                                        onChange={(e) => setImpersonationTarget(e.target.value)}
                                        className="glass-effect border-white/20 bg-transparent text-white"
                                    />
                                    <Button 
                                        onClick={handleImpersonation} 
                                        className="w-full bg-amber-600 hover:bg-amber-700"
                                    >
                                        Start Impersonation
                                    </Button>
                                </div>
                            </DialogContent>
                        </Dialog>
                    </div>
                </div>

                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="glass-effect bg-transparent border-white/20 p-1">
                        <TabsTrigger 
                            value="overview"
                            className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600"
                        >
                            <BarChart3 className="w-4 h-4 mr-2" />
                            Overview
                        </TabsTrigger>
                        <TabsTrigger 
                            value="partners"
                            className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600"
                        >
                            <Building className="w-4 h-4 mr-2" />
                            Partners
                        </TabsTrigger>
                        <TabsTrigger 
                            value="billing"
                            className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600"
                        >
                            <DollarSign className="w-4 h-4 mr-2" />
                            Billing
                        </TabsTrigger>
                        <TabsTrigger 
                            value="abuse"
                            className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600"
                        >
                            <AlertTriangle className="w-4 h-4 mr-2" />
                            Abuse Reports
                        </TabsTrigger>
                        <TabsTrigger 
                            value="features"
                            className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600"
                        >
                            <Flag className="w-4 h-4 mr-2" />
                            Feature Flags
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                            <Card className="glass-effect border-white/10 bg-transparent">
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-gray-400 text-sm">Total Partners</p>
                                            <p className="text-2xl font-bold text-white">{partners.length}</p>
                                        </div>
                                        <Building className="w-8 h-8 text-cyan-400" />
                                    </div>
                                </CardContent>
                            </Card>
                            
                            <Card className="glass-effect border-white/10 bg-transparent">
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-gray-400 text-sm">Active Subscriptions</p>
                                            <p className="text-2xl font-bold text-white">
                                                {subscriptions.filter(s => s.status === 'active').length}
                                            </p>
                                        </div>
                                        <DollarSign className="w-8 h-8 text-green-400" />
                                    </div>
                                </CardContent>
                            </Card>
                            
                            <Card className="glass-effect border-white/10 bg-transparent">
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-gray-400 text-sm">Pending Reports</p>
                                            <p className="text-2xl font-bold text-white">
                                                {abuseReports.filter(r => r.status === 'pending').length}
                                            </p>
                                        </div>
                                        <AlertTriangle className="w-8 h-8 text-red-400" />
                                    </div>
                                </CardContent>
                            </Card>
                            
                            <Card className="glass-effect border-white/10 bg-transparent">
                                <CardContent className="p-6">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <p className="text-gray-400 text-sm">Active Features</p>
                                            <p className="text-2xl font-bold text-white">
                                                {featureFlags.filter(f => f.is_enabled).length}
                                            </p>
                                        </div>
                                        <Flag className="w-8 h-8 text-purple-400" />
                                    </div>
                                </CardContent>
                            </Card>
                        </div>
                    </TabsContent>

                    <TabsContent value="partners">
                        <Card className="glass-effect border-white/10 bg-transparent">
                            <CardHeader>
                                <CardTitle className="text-white">Partner Organizations</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {partners.map((partner) => (
                                        <div key={partner.id} className="border border-white/10 rounded-lg p-4">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center space-x-4">
                                                    <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-teal-500 rounded-lg flex items-center justify-center">
                                                        {partner.partner_type === 'business' ? 
                                                            <Building className="w-6 h-6 text-white" /> :
                                                            <Shield className="w-6 h-6 text-white" />
                                                        }
                                                    </div>
                                                    <div>
                                                        <h4 className="text-white font-semibold">{partner.name}</h4>
                                                        <p className="text-gray-400 text-sm">{partner.description}</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center space-x-2">
                                                    <Badge className={
                                                        partner.status === 'active' ? 'bg-green-600 text-white' :
                                                        partner.status === 'pending' ? 'bg-yellow-600 text-white' :
                                                        'bg-red-600 text-white'
                                                    }>
                                                        {partner.status}
                                                    </Badge>
                                                    <Badge variant="outline">
                                                        {partner.partner_type}
                                                    </Badge>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    <TabsContent value="features">
                        <Card className="glass-effect border-white/10 bg-transparent">
                            <CardHeader>
                                <CardTitle className="text-white">Feature Flag Management</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-4">
                                    {featureFlags.map((flag) => (
                                        <div key={flag.id} className="border border-white/10 rounded-lg p-4">
                                            <div className="flex items-center justify-between">
                                                <div>
                                                    <h4 className="text-white font-semibold">{flag.flag_name}</h4>
                                                    <p className="text-gray-400 text-sm">{flag.description}</p>
                                                    <Badge variant="outline" className="mt-2">
                                                        {flag.target_audience}
                                                    </Badge>
                                                </div>
                                                <div className="flex items-center space-x-4">
                                                    <span className="text-gray-400 text-sm">
                                                        {flag.rollout_percentage}% rollout
                                                    </span>
                                                    <Switch
                                                        checked={flag.is_enabled}
                                                        onCheckedChange={(checked) => toggleFeatureFlag(flag.id, checked)}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </TabsContent>

                    {/* Additional tab contents for billing and abuse reports would go here */}
                </Tabs>
            </div>
        </div>
    );
}
