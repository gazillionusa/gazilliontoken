
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Landmark, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CivicGuardiansPage() {
    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-8">
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        <Landmark className="w-12 h-12 inline-block mr-4 text-cyan-400" />
                        Civic <span className="text-gradient">Guardians</span>
                    </h1>
                    <p className="text-lg text-gray-300">
                        Municipalities empowering communities through innovative bond solutions.
                    </p>
                </div>

                <div className="text-center mb-12">
                    <h3 className="text-2xl font-bold text-white">Ready to Transform Municipal Finance?</h3>
                    <p className="text-gray-400 mt-2 max-w-2xl mx-auto">
                        Create your municipal portal to issue bonds, engage citizens, and fund infrastructure projects.
                    </p>
                </div>

                {/* Municipal Partner Welcome Banner */}
                <div className="mb-12 max-w-xl mx-auto">
                    <Link to={createPageUrl("Onboarding")}>
                        <div className="text-center bg-cyan-500 hover:bg-cyan-600 transition-colors duration-300 p-6 rounded-2xl cursor-pointer shadow-lg hover:shadow-xl">
                            <img 
                                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/3e9649f97_MuniSignupImageGazillion.png"
                                alt="Welcome, Municipal Partner!" 
                                className="max-w-full h-auto rounded-lg shadow-md hover:scale-105 transition-transform duration-300"
                            />
                        </div>
                    </Link>
                </div>
            </div>
        </div>
    );
}
