import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { 
  UserCheck, 
  Wallet, 
  ShoppingCart, 
  TrendingUp, 
  DollarSign,
  ArrowRight,
  CheckCircle,
  Shield,
  Clock
} from 'lucide-react';
import MetaTags from "@/components/seo/MetaTags";

export default function HowItWorks() {
  const steps = [
    {
      number: 1,
      icon: UserCheck,
      title: "Complete KYC Verification",
      description: "Submit your identity documents for quick verification. We comply with all regulatory requirements to ensure a secure platform.",
      details: [
        "Government-issued ID verification",
        "Address confirmation",
        "Accredited investor status (if applicable)",
        "Typically completed in 24-48 hours"
      ],
      color: "from-blue-500 to-blue-600"
    },
    {
      number: 2,
      icon: Wallet,
      title: "Connect Your Wallet",
      description: "Link your crypto wallet or use our integrated custodial solution. We support MetaMask, WalletConnect, and major providers.",
      details: [
        "Support for 20+ wallet providers",
        "Secure key management",
        "Multi-chain compatibility",
        "Custodial options available"
      ],
      color: "from-purple-500 to-purple-600"
    },
    {
      number: 3,
      icon: ShoppingCart,
      title: "Browse & Buy Bond NFTs",
      description: "Explore our marketplace of vetted municipal bonds. Each bond is tokenized as an NFT with transparent terms and government backing.",
      details: [
        "Detailed bond information",
        "Real-time pricing",
        "Instant purchase confirmation",
        "Blockchain-verified ownership"
      ],
      color: "from-green-500 to-green-600"
    },
    {
      number: 4,
      icon: TrendingUp,
      title: "Trade or Hold Your Investment",
      description: "Track your portfolio, trade on secondary markets, or hold until maturity. Enjoy instant liquidity and transparent pricing.",
      details: [
        "Real-time portfolio tracking",
        "Secondary market trading",
        "Automatic interest payments",
        "Performance analytics"
      ],
      color: "from-amber-500 to-amber-600"
    },
    {
      number: 5,
      icon: DollarSign,
      title: "Redeem at Maturity",
      description: "Receive your principal plus accrued interest automatically at maturity. All payments are blockchain-verified and instant.",
      details: [
        "Automated redemption process",
        "Instant settlement",
        "Tax documentation provided",
        "Reinvestment options available"
      ],
      color: "from-cyan-500 to-cyan-600"
    }
  ];

  const benefits = [
    { icon: Shield, title: "SEC Compliant", description: "Full regulatory compliance and investor protection" },
    { icon: CheckCircle, title: "Transparent", description: "All transactions verified on blockchain" },
    { icon: Clock, title: "Fast Settlement", description: "Instant trades and automated payments" }
  ];

  return (
    <>
      <MetaTags
        title="How It Works | Gazillion"
        description="Learn how to invest in tokenized municipal bonds on Gazillion. From KYC to redemption, we make NFT bond investing simple and secure."
        keywords="how to invest, NFT bonds, municipal bonds guide, tokenized bonds"
      />
      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              How <span className="text-gradient">Gazillion</span> Works
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Investing in municipal bonds has never been easier. Follow these 5 simple steps to start earning from infrastructure projects.
            </p>
          </div>

          {/* Steps */}
          <div className="space-y-12 mb-20">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isEven = index % 2 === 0;
              
              return (
                <div key={step.number} className={`flex flex-col ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-8 items-center`}>
                  {/* Icon Card */}
                  <div className="flex-shrink-0">
                    <div className={`w-32 h-32 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center relative`}>
                      <Icon className="w-16 h-16 text-white" />
                      <div className="absolute -top-4 -right-4 w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg">
                        <span className="text-2xl font-bold text-slate-900">{step.number}</span>
                      </div>
                    </div>
                  </div>

                  {/* Content Card */}
                  <Card className="glass-effect border-white/10 bg-transparent flex-1">
                    <CardContent className="p-8">
                      <h2 className="text-3xl font-bold text-white mb-4">{step.title}</h2>
                      <p className="text-gray-300 text-lg mb-6 leading-relaxed">{step.description}</p>
                      <ul className="space-y-3">
                        {step.details.map((detail, i) => (
                          <li key={i} className="flex items-start text-gray-400">
                            <CheckCircle className="w-5 h-5 text-green-400 mr-3 flex-shrink-0 mt-0.5" />
                            <span>{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              );
            })}
          </div>

          {/* Benefits */}
          <div className="grid md:grid-cols-3 gap-6 mb-16">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <Card key={index} className="glass-effect border-white/10 bg-transparent text-center">
                  <CardContent className="p-8">
                    <div className="w-16 h-16 primary-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{benefit.title}</h3>
                    <p className="text-gray-400">{benefit.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* CTA */}
          <div className="text-center glass-effect p-12 rounded-3xl">
            <h2 className="text-3xl font-bold text-white mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
              Join thousands of investors already earning from municipal NFT bonds. Start your journey today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("BondMarketplace")}>
                <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-8 py-4 text-lg rounded-full transform hover:scale-105 transition-all duration-300">
                  Browse Bonds
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to={createPageUrl("Contact")}>
                <Button variant="outline" className="bg-background text-slate-950 px-8 py-4 text-lg font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/30 hover:bg-white/10 rounded-full backdrop-blur-sm">
                  Contact Sales
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}