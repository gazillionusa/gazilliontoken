import React, { useState, useEffect } from 'react';
import { Insight } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { User, Clock, ArrowLeft, BookOpen, Share2 } from 'lucide-react';
import { format } from 'date-fns';
import ReactMarkdown from 'react-markdown';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import MetaTags from '@/components/seo/MetaTags';
import { toast } from "sonner";

export default function InsightDetails() {
  const [insight, setInsight] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadInsight = async () => {
      const urlParams = new URLSearchParams(window.location.search);
      const slug = urlParams.get('slug');

      if (slug) {
        try {
          const results = await Insight.filter({ slug: slug });
          if (results.length > 0) {
            setInsight(results[0]);
          } else {
            console.error("Insight not found for slug:", slug);
          }
        } catch (error) {
          console.error("Error loading insight:", error);
        } finally {
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    };

    loadInsight();
  }, []);

  const categoryColors = {
    blockchain: "bg-purple-500/20 text-purple-300 border-purple-500/30",
    municipal_bonds: "bg-blue-500/20 text-blue-300 border-blue-500/30",
    investment: "bg-green-500/20 text-green-300 border-green-500/30",
    regulation: "bg-red-500/20 text-red-300 border-red-500/30",
    technology: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
    case_study: "bg-amber-500/20 text-amber-300 border-amber-500/30"
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success("Article link copied to clipboard!");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen px-4 sm:px-6 py-12 flex items-center justify-center">
        <div className="animate-spin rounded-full h-24 w-24 border-t-2 border-b-2 border-cyan-400"></div>
      </div>);

  }

  if (!insight) {
    return (
      <div className="min-h-screen px-4 sm:px-6 py-12 text-center flex flex-col items-center justify-center">
        <BookOpen className="w-20 h-20 text-gray-500 mb-6" />
        <h2 className="text-3xl font-bold text-white mb-4">Insight Not Found</h2>
        <p className="text-gray-400 mb-8 max-w-md">The article you are looking for might have been moved or deleted.</p>
        <Link to={createPageUrl("insights")}>
          <Button variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Insights
          </Button>
        </Link>
      </div>);

  }

  return (
    <>
      <MetaTags
        title={`${insight.title} | Gazillion Insights`}
        description={insight.excerpt}
        keywords={insight.tags?.join(', ') || ''} />

      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <div className="mb-8">
            <Link to={createPageUrl("insights")}>
              <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-white/10">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to All Insights
              </Button>
            </Link>
          </div>

          <article>
            <Card className="glass-effect border-white/10 bg-transparent">
              <CardHeader>
                {/* Category and Read Time */}
                <div className="flex items-center gap-4 text-sm text-gray-400 mb-4">
                  <Badge className={`${categoryColors[insight.category]} border`}>
                    {insight.category.replace('_', ' ')}
                  </Badge>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{insight.read_time_minutes || 5} min read</span>
                  </div>
                </div>

                {/* Title */}
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-4 leading-tight">{insight.title}</h1>
                
                {/* Author and Date */}
                <div className="flex items-center justify-between text-gray-400">
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    <span>{insight.author_name || 'Gazillion Team'}</span>
                    {insight.author_title && <span>&bull; {insight.author_title}</span>}
                  </div>
                  {insight.publish_date &&
                  <span>{format(new Date(insight.publish_date), 'MMMM d, yyyy')}</span>
                  }
                </div>
                
                {/* Share Button */}
                <div className="mt-4">
                    <Button variant="outline" size="sm" onClick={handleShare} className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border h-9 rounded-md hover:text-white border-white/20 hover:bg-white/10">
                        <Share2 className="w-4 h-4 mr-2" />
                        Share
                    </Button>
                </div>
              </CardHeader>
              
              {/* Featured Image */}
              {insight.featured_image_url &&
              <div className="w-full h-80 rounded-lg overflow-hidden my-6">
                  <img src={insight.featured_image_url} alt={insight.title} className="bg-cyan-300 w-full h-full object-cover" />
                </div>
              }

              <CardContent>
                <div className="bg-slate-50 text-slate-950 prose prose-invert prose-lg max-w-none prose-p:text-gray-300 prose-headings:text-white prose-strong:text-white prose-a:text-cyan-400 hover:prose-a:text-cyan-300">
                  <ReactMarkdown>{insight.content}</ReactMarkdown>
                </div>
              </CardContent>
            </Card>
          </article>
        </div>
      </div>
    </>);

}