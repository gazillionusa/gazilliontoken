
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Code, Shield, BookOpen, FileText, ExternalLink, Github, CheckCircle } from 'lucide-react';
import MetaTags from "@/components/seo/MetaTags";

export default function Developers() {
  const smartContractStandards = [
  {
    name: "ERC-721G Gazillion Standard",
    description: "Extended ERC-721 with municipal bond specific metadata and compliance hooks.",
    version: "v2.1.0",
    audited: true,
    github_url: "https://github.com/gazillionusa/contracts/blob/main/ERC721G.sol"
  },
  {
    name: "Interest Distribution Contract",
    description: "Automated payment distribution with multi-sig governance.",
    version: "v1.8.3",
    audited: true,
    github_url: "https://github.com/gazillionusa/contracts/blob/main/InterestDistribution.sol"
  },
  {
    name: "KYC Registry Contract",
    description: "On-chain KYC verification with privacy-preserving zero-knowledge proofs.",
    version: "v1.5.0",
    audited: true,
    github_url: "https://github.com/gazillionusa/contracts/blob/main/KYCRegistry.sol"
  },
  {
    name: "Secondary Market Contract",
    description: "DEX integration with compliance checks and transfer restrictions.",
    version: "v2.0.1",
    audited: true,
    github_url: "https://github.com/gazillionusa/contracts/blob/main/SecondaryMarket.sol"
  }];


  const apiEndpoints = [
  { method: "POST", endpoint: "/api/functions/createPaymentIntent", description: "Creates a Stripe payment intent for bond purchases." },
  { method: "POST", endpoint: "/api/functions/confirmPayment", description: "Confirms a payment and logs the bond purchase." },
  { method: "POST", endpoint: "/api/functions/mintBondNFT", description: "Mints a bond NFT after successful payment and KYC." },
  { method: "POST", endpoint: "/api/functions/walletOperations", description: "Handles wallet connection, balance checks, and transactions." },
  { method: "POST", endpoint: "/api/functions/kycVerification", description: "Initiates and checks the status of KYC verification sessions." },
  { method: "GET", endpoint: "/api/functions/getLeaderboard", description: "Fetches the public investor leaderboard." },
  { method: "GET", endpoint: "/api/functions/cryptoPricing", description: "Gets live cryptocurrency prices from an external oracle." }];


  const auditReports = [
  {
    firm: "CertiK",
    date: "December 2024",
    scope: "Full Platform Security Audit",
    rating: "AA",
    url: "https://github.com/gazillionusa/audits/blob/main/CertiK_Report_2024.pdf"
  },
  {
    firm: "OpenZeppelin",
    date: "October 2024",
    scope: "Smart Contract Audit",
    rating: "A+",
    url: "https://github.com/gazillionusa/audits/blob/main/OpenZeppelin_Report_2024.pdf"
  },
  {
    firm: "Trail of Bits",
    date: "September 2024",
    scope: "Cryptographic Implementation Review",
    rating: "A",
    url: "https://github.com/gazillionusa/audits/blob/main/TrailOfBits_Report_2024.pdf"
  }];


  return (
    <>
      <MetaTags
        title="Developers | Gazillion"
        description="Technical documentation, API reference, smart contract standards, and security audits for the Gazillion NFT municipal bond platform."
        keywords="blockchain API, smart contracts, developer docs, NFT standards, audit reports" />

      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Developer <span className="text-gradient">Portal</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Build on Gazillion's institutional-grade infrastructure. Access our APIs, smart contracts, and technical resources.
            </p>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="overview" className="space-y-8">
            <TabsList className="glass-effect bg-transparent border-white/10 w-full justify-start overflow-x-auto">
              <TabsTrigger value="overview" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">Overview</TabsTrigger>
              <TabsTrigger value="contracts" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">Smart Contracts</TabsTrigger>
              <TabsTrigger value="api" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">API Reference</TabsTrigger>
              <TabsTrigger value="audits" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">Security Audits</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-8">
              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">Platform Architecture</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="glass-effect p-8 rounded-lg mb-6">
                    <img
                      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/4cf51a669_Gazillion_Platform_Architecture.png"
                      alt="Gazillion Platform Architecture"
                      className="w-full rounded-lg"
                      onError={(e) => {
                        e.target.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='400'%3E%3Crect fill='%23334155' width='800' height='400'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%234ECDC4' font-size='24' font-family='Arial'%3EArchitecture Diagram Coming Soon%3C/text%3E%3C/svg%3E";
                      }} />

                  </div>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-xl font-bold text-white mb-4">Layer 1: Blockchain</h3>
                      <ul className="space-y-2 text-gray-300">
                        <li className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Ethereum mainnet for security and settlement.</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>L2 rollups for low-cost, high-speed transactions.</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Cross-chain bridge support via Chainlink CCIP.</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white mb-4">Layer 2: Services</h3>
                      <ul className="space-y-2 text-gray-300">
                        <li className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>Serverless backend functions for scalable APIs.</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>WebSocket support for real-time market data.</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-400 mr-2 flex-shrink-0 mt-0.5" />
                          <span>IPFS and Filecoin for decentralized metadata storage.</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">Getting Started</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">1. Request API Access</h3>
                      <p className="text-gray-300 mb-3">Contact our developer relations team to receive your API credentials for our sandbox environment.</p>
                      <Button asChild variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10">
                        <a href="mailto:devs@gazillionusa.com">
                          Request API Key
                          <ExternalLink className="w-4 h-4 ml-2" />
                        </a>
                      </Button>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">2. Review Documentation</h3>
                      <p className="text-gray-300">Explore our comprehensive API docs and smart contract references to understand the platform capabilities.</p>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-2">3. Build in Sandbox</h3>
                      <p className="text-gray-300">Use our full-featured testnet environment to build and validate your integration before deploying to production.</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Smart Contracts Tab */}
            <TabsContent value="contracts" className="space-y-6">
              {smartContractStandards.map((contract, index) =>
              <Card key={index} className="glass-effect border-white/10 bg-transparent">
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <div>
                        <CardTitle className="text-white text-xl mb-2">{contract.name}</CardTitle>
                        <p className="text-gray-300">{contract.description}</p>
                      </div>
                      <div className="flex flex-col sm:items-end gap-2">
                        <Badge className="bg-blue-600 text-white whitespace-nowrap">{contract.version}</Badge>
                        {contract.audited &&
                      <Badge className="bg-green-600 text-white whitespace-nowrap">
                            <Shield className="w-3 h-3 mr-1" />
                            Audited
                          </Badge>
                      }
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-3">
                      <Button asChild variant="outline" size="sm" className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md border-white/20 hover:bg-white/10">
                        <a href={contract.github_url} target="_blank" rel="noopener noreferrer">
                          <Code className="w-4 h-4 mr-2" />
                          View Source
                        </a>
                      </Button>
                      <Button variant="outline" size="sm" className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md border-white/20 hover:bg-white/10">
                        <BookOpen className="w-4 h-4 mr-2" />
                        Documentation
                      </Button>
                      <Button variant="outline" size="sm" className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md border-white/20 hover:bg-white/10">
                        <FileText className="w-4 h-4 mr-2" />
                        ABI
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* API Reference Tab */}
            <TabsContent value="api" className="space-y-6">
              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">REST API Endpoints</CardTitle>
                  <p className="text-gray-300">Base URL: https://gazillionusa.base44.com</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {apiEndpoints.map((endpoint, index) =>
                    <div key={index} className="glass-effect p-4 rounded-lg">
                        <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-2">
                          <Badge className={`${
                        endpoint.method === 'GET' ? 'bg-green-600' :
                        endpoint.method === 'POST' ? 'bg-blue-600' :
                        'bg-amber-600'} text-white whitespace-nowrap w-20 justify-center`
                        }>
                            {endpoint.method}
                          </Badge>
                          <code className="text-cyan-400 text-sm break-all">{endpoint.endpoint}</code>
                        </div>
                        <p className="text-gray-300 text-sm">{endpoint.description}</p>
                      </div>
                    )}
                  </div>
                  <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                    <h4 className="text-white font-semibold mb-2 flex items-center">
                      <BookOpen className="w-5 h-5 mr-2 text-blue-400" />
                      Authentication
                    </h4>
                    <p className="text-gray-300 text-sm">All API requests require an Authorization header with a Bearer token. Contact us for an API key.</p>
                    <code className="block mt-2 p-2 bg-slate-900 rounded text-cyan-400 text-xs overflow-x-auto">
                      Authorization: Bearer YOUR_API_KEY
                    </code>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Audits Tab */}
            <TabsContent value="audits" className="space-y-6">
              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">Independent Security Audits</CardTitle>
                  <p className="text-gray-300">Our platform undergoes regular third-party security audits by leading blockchain security firms.</p>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {auditReports.map((audit, index) =>
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between mb-4">
                            <Shield className="w-10 h-10 text-green-400" />
                            <Badge className="bg-green-600 text-white">{audit.rating}</Badge>
                          </div>
                          <h3 className="text-xl font-bold text-white mb-2">{audit.firm}</h3>
                          <p className="text-gray-400 text-sm mb-3">{audit.date}</p>
                          <p className="text-gray-300 text-sm mb-4">{audit.scope}</p>
                          <Button asChild variant="outline" size="sm" className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md w-full border-white/20 hover:bg-white/10">
                            <a href={audit.url} target="_blank" rel="noopener noreferrer">
                              View Report
                              <ExternalLink className="w-4 h-4 ml-2" />
                            </a>
                          </Button>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">Bug Bounty Program</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-4">
                    We reward security researchers who responsibly disclose vulnerabilities. Rewards range from $500 to $50,000 depending on severity.
                  </p>
                  <Button asChild className="primary-gradient text-white">
                    <a href="https://github.com/gazillionusa/security" target="_blank" rel="noopener noreferrer">
                      Learn More & Report a Bug
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* GitHub CTA */}
          <Card className="glass-effect border-white/10 bg-transparent mt-12">
            <CardContent className="p-8 text-center">
              <Github className="w-16 h-16 text-white mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-4">Open Source Contributions</h2>
              <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                We believe in transparency and community collaboration. Check out our open-source repositories and contribute to the future of tokenized municipal bonds.
              </p>
              <Button asChild variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10">
                <a href="https://github.com/gazillionusa" target="_blank" rel="noopener noreferrer">
                  <Github className="w-5 h-5 mr-2" />
                  View on GitHub
                </a>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </>);

}
