import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Info } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="space-y-8">
        <div className="mb-8 p-6 rounded-lg bg-gray-800/30 text-center">
            <h1 className="text-3xl font-bold text-gradient">About Gazillion</h1>
            <p className="text-gray-400 mt-2">Learn more about our mission, team, and technology.</p>
        </div>

        <Card className="bg-gray-800/50 border-teal-500/20">
            <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                    <Info className="w-6 h-6 mr-3 text-teal-400" />
                    Coming Soon
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-gray-300">This page is currently under construction. Check back soon for more information about Gazillion and our goal to revolutionize municipal finance.</p>
            </CardContent>
        </Card>
    </div>
  );
}