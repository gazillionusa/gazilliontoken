
import React, { useState, useEffect } from 'react';
import { Job } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Briefcase, MapPin, Clock } from 'lucide-react';
import ApplicationForm from '@/components/careers/ApplicationForm';
import { toast } from "sonner";

export default function CareersPage() {
    const [jobs, setJobs] = useState([]);
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [selectedJob, setSelectedJob] = useState(null);
    const [isFormOpen, setIsFormOpen] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [activeJobs, currentUser] = await Promise.all([
                    Job.filter({ is_active: true }),
                    User.me().catch(() => null)
                ]);
                setJobs(activeJobs);
                setUser(currentUser);
            } catch (error) {
                console.error("Failed to fetch data:", error);
                toast.error("Could not load job openings. Please try again later.");
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const handleApplyClick = async (job) => {
        if (!user) {
            toast.info("Please create an account or sign in to apply.");
            try {
                // Redirect user to login, then return them to the careers page.
                await User.loginWithRedirect(window.location.href);
            } catch (error) {
                toast.error("Login failed. Please try again.");
            }
            return;
        }
        setSelectedJob(job);
        setIsFormOpen(true);
    };

    const handleFormClose = () => {
        setIsFormOpen(false);
        setSelectedJob(null);
    };

    const handleFormSuccess = () => {
        handleFormClose();
        toast.success("Your application has been submitted successfully!");
    };

    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="text-center mb-16">
                    <div className="inline-block glass-effect px-6 py-3 rounded-full mb-6">
                        <span className="brand-accent text-sm font-medium">Join Our Mission</span>
                    </div>
                    <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                        Build the Future of Finance at <span className="text-gradient">Gazillion</span>
                    </h1>
                    <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                        We're a team of innovators, dreamers, and builders revolutionizing municipal finance. If you're passionate about technology and community impact, you've come to the right place.
                    </p>
                </div>

                {/* Job Listings */}
                <div className="space-y-8">
                    {loading ? (
                        <div className="flex justify-center items-center py-20">
                            <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
                        </div>
                    ) : jobs.length > 0 ? (
                        jobs.map((job) => (
                            <Card key={job.id} className="glass-effect border-white/10 bg-transparent group hover:bg-white/5 transition-all duration-500">
                                <CardHeader>
                                    <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                                        <div>
                                            <CardTitle className="text-2xl text-white mb-2">{job.title}</CardTitle>
                                            <div className="flex flex-wrap gap-x-4 gap-y-2 text-gray-400">
                                                <div className="flex items-center gap-2"><Briefcase className="w-4 h-4" />{job.department}</div>
                                                <div className="flex items-center gap-2"><MapPin className="w-4 h-4" />{job.location}</div>
                                                <div className="flex items-center gap-2"><Clock className="w-4 h-4" />{job.job_type}</div>
                                            </div>
                                        </div>
                                        <Button onClick={() => handleApplyClick(job)} className="mt-4 sm:mt-0 primary-gradient text-white hover:opacity-90 shrink-0">
                                            Apply Now
                                        </Button>
                                    </div>
                                </CardHeader>
                                <CardContent>
                                    <p className="text-gray-300 line-clamp-3">{job.description}</p>
                                </CardContent>
                            </Card>
                        ))
                    ) : (
                        <div className="text-center py-20 glass-effect rounded-2xl">
                            <h3 className="text-2xl font-bold text-white">No Open Positions</h3>
                            <p className="text-gray-400 mt-2">We're not actively hiring right now, but check back soon!</p>
                        </div>
                    )}
                </div>
            </div>

            {selectedJob && (
                <ApplicationForm
                    job={selectedJob}
                    user={user}
                    isOpen={isFormOpen}
                    onClose={handleFormClose}
                    onSubmitSuccess={handleFormSuccess}
                />
            )}
        </div>
    );
}
