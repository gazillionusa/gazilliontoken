import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, User, MapPin, Edit, Check, Link as LinkIcon, Twitter, Linkedin, Globe } from 'lucide-react';
import PortfolioAnalytics from '@/components/profile/PortfolioAnalytics';
import TransactionHistory from '@/components/profile/TransactionHistory';
import SettingsTab from '@/components/profile/SettingsTab';
import MyBonds from '@/components/profile/MyBonds';

const StatCard = ({ label, value, icon: Icon }) => (
  <div className="glass-effect p-4 rounded-lg text-center">
    <div className="flex justify-center items-center mb-2">
      {Icon && <Icon className="w-5 h-5 text-teal-400 mr-2" />}
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
    <p className="text-sm text-gray-400">{label}</p>
  </div>
);

export default function Profile() {
  const { data: user, isLoading, error } = useQuery({
    queryKey: ['currentUserProfile'],
    queryFn: () => base44.auth.me(),
  });

  if (isLoading) {
    return <div className="flex justify-center items-center h-[60vh]"><Loader2 className="w-12 h-12 animate-spin text-teal-400" /></div>;
  }

  if (error || !user) {
    return <div className="text-center text-red-400">Could not load user profile. Please try again later.</div>;
  }

  const socialLinks = user.social_links || {};

  return (
    <div className="space-y-8">
      {/* Profile Header */}
      <Card className="glass-effect border-0 overflow-hidden">
        <div className="h-48 bg-cover bg-center relative" style={{ backgroundImage: `url(${user.cover_image_url || 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&q=80'})` }}>
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        <div className="px-6 pb-6 -mt-16 sm:-mt-20">
          <div className="flex flex-col sm:flex-row items-end sm:space-x-5">
            <img
              className="h-24 w-24 sm:h-32 sm:w-32 rounded-full ring-4 ring-gray-800 object-cover"
              src={user.avatar_image_url || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${user.email}`}
              alt={`${user.full_name}'s avatar`}
            />
            <div className="mt-4 sm:mt-0 flex-grow">
              <h1 className="text-2xl sm:text-3xl font-bold text-white">{user.full_name}</h1>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-gray-400 text-sm mt-1">
                {user.username && <p>@{user.username}</p>}
                {user.location && <p className="flex items-center"><MapPin className="w-4 h-4 mr-1" />{user.location}</p>}
              </div>
            </div>
            <div className="mt-4 sm:mt-0">
               <Button variant="outline" className="glass-effect text-white hover:bg-white/10">Follow</Button>
            </div>
          </div>
          {user.bio && <p className="mt-4 text-gray-300 max-w-2xl">{user.bio}</p>}
           <div className="flex gap-4 mt-4">
              {socialLinks.twitter && <a href={socialLinks.twitter} target="_blank" rel="noreferrer"><Twitter className="w-5 h-5 text-gray-400 hover:text-white" /></a>}
              {socialLinks.linkedin && <a href={socialLinks.linkedin} target="_blank" rel="noreferrer"><Linkedin className="w-5 h-5 text-gray-400 hover:text-white" /></a>}
              {socialLinks.website && <a href={socialLinks.website} target="_blank" rel="noreferrer"><Globe className="w-5 h-5 text-gray-400 hover:text-white" /></a>}
          </div>
        </div>
      </Card>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Portfolio Value" value={`$${(user.portfolio_value || 0).toLocaleString()}`} />
        <StatCard label="Lifetime Earnings" value={`$${(user.lifetime_earnings || 0).toLocaleString()}`} />
        <StatCard label="Civic XP" value={(user.lifetime_earnings || 0) * 10} />
        <StatCard label="Bonds Held" value={user.active_investments || 0} />
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="portfolio" className="w-full">
        <TabsList className="grid w-full grid-cols-4 glass-effect p-1 h-auto">
          <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="portfolio" className="mt-6">
          <MyBonds user={user} />
        </TabsContent>
        <TabsContent value="analytics" className="mt-6">
          <PortfolioAnalytics />
        </TabsContent>
        <TabsContent value="activity" className="mt-6">
          <TransactionHistory user={user} />
        </TabsContent>
        <TabsContent value="settings" className="mt-6">
          <SettingsTab user={user} />
        </TabsContent>
      </Tabs>
    </div>
  );
}