import React, { useState, useEffect } from 'react';
import { getLeaderboard } from '@/api/functions';
import { Loader2, Award, Shield, Crown } from 'lucide-react';
import { toast } from "sonner";
import { Card } from '@/components/ui/card';

export default function LeaderboardPage() {
    const [leaderboard, setLeaderboard] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLeaderboard = async () => {
            try {
                const { data } = await getLeaderboard();
                setLeaderboard(data);
            } catch (error) {
                console.error("Failed to load leaderboard:", error);
                toast.error("Could not load the leaderboard.");
            } finally {
                setLoading(false);
            }
        };
        fetchLeaderboard();
    }, []);

    const getRankIcon = (rank) => {
        if (rank === 0) return <Crown className="w-6 h-6 text-yellow-400" />;
        if (rank === 1) return <Award className="w-6 h-6 text-gray-300" />;
        if (rank === 2) return <Shield className="w-6 h-6 text-orange-400" />;
        return <span className="text-gray-400 font-bold">{rank + 1}</span>;
    };
    
    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-12">
                    <div className="inline-block glass-effect px-6 py-3 rounded-full mb-6">
                        <span className="brand-accent text-sm font-medium">Community Ranking</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        Top Civic <span className="text-gradient">Zookeepers</span>
                    </h1>
                    <p className="text-lg text-gray-300">
                        Celebrating the investors making the biggest community impact.
                    </p>
                </div>
                
                <div className="space-y-4">
                    {leaderboard.map((user, index) => (
                        <Card key={user.id} className={`glass-effect p-4 border transition-all duration-300 ${
                            index === 0 ? 'border-yellow-400/30' : 
                            index === 1 ? 'border-gray-300/30' : 
                            index === 2 ? 'border-orange-400/30' : 
                            'border-white/10'
                        }`}>
                            <div className="flex items-center gap-4">
                                <div className="w-12 text-center flex-shrink-0 flex items-center justify-center">
                                    {getRankIcon(index)}
                                </div>
                                <img 
                                    src={user.avatar_image_url || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/c8697d8dc_ChatGPTImageSep22202503_14_30PM.png'}
                                    alt={user.full_name}
                                    className="w-12 h-12 rounded-full object-cover border-2 border-cyan-400/50"
                                />
                                <div className="flex-grow">
                                    <p className="text-white font-semibold">{user.full_name}</p>
                                    <p className="text-sm text-gray-400">Civic Score: {user.civic_score.toLocaleString()}</p>
                                </div>
                                <div className="text-right hidden sm:block">
                                    <p className="text-white font-bold">${user.portfolio_value.toLocaleString()}</p>
                                    <p className="text-xs text-gray-400">Invested</p>
                                </div>
                                <div className="text-right hidden sm:block">
                                    <p className="text-cyan-400 font-bold">{user.civic_xp.toLocaleString()} XP</p>
                                    <p className="text-xs text-gray-400">Civic XP</p>
                                </div>
                            </div>
                        </Card>
                    ))}
                </div>
            </div>
        </div>
    );
}