import Layout from "./Layout.jsx";

import Home from "./Home";

import Services from "./Services";

import Dashboard from "./Dashboard";

import About from "./About";

import Contact from "./Contact";

import BondMarketplace from "./BondMarketplace";

import Invest from "./Invest";

import BondDetails from "./BondDetails";

import InvestorSupport from "./InvestorSupport";

import Technology from "./Technology";

import CivicZoo from "./CivicZoo";

import Profile from "./Profile";

import Careers from "./Careers";

import CommunityFeed from "./CommunityFeed";

import Applications from "./Applications";

import Leaderboard from "./Leaderboard";

import Messages from "./Messages";

import Settings from "./Settings";

import MessageThread from "./MessageThread";

import ZooVendors from "./ZooVendors";

import CivicGuardians from "./CivicGuardians";

import PartnerPortal from "./PartnerPortal";

import MasterAdminConsole from "./MasterAdminConsole";

import PublicPageEditor from "./PublicPageEditor";

import CampaignBuilder from "./CampaignBuilder";

import BillingPortal from "./BillingPortal";

import CivicPartnerDirectory from "./CivicPartnerDirectory";

import CivicPartnerProfile from "./CivicPartnerProfile";

import Directory from "./Directory";

import UserProfile from "./UserProfile";

import SocialHub from "./SocialHub";

import Onboarding from "./Onboarding";

import Public from "./Public";

import PartnerDirectory from "./PartnerDirectory";

import HowItWorks from "./HowItWorks";

import Code1 from "./Code1";

import InvestmentPool from "./InvestmentPool";

import Developers from "./Developers";

import CaseStudies from "./CaseStudies";

import CryptoNews from "./CryptoNews";

import EducationHub from "./EducationHub";

import Governance from "./Governance";

import insights from "./insights";

import insightdetails from "./insightdetails";

import GettingStarted from "./GettingStarted";

import riskdisclosure from "./riskdisclosure";

import terms from "./terms";

import privacy from "./privacy";

import legalnotice from "./legalnotice";

import SavingsBondsMarketplace from "./SavingsBondsMarketplace";

import BondPayments from "./BondPayments";

import VerifyIdentity from "./VerifyIdentity";

import Minter from "./Minter";

import CreateToken from "./CreateToken";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Services: Services,
    
    Dashboard: Dashboard,
    
    About: About,
    
    Contact: Contact,
    
    BondMarketplace: BondMarketplace,
    
    Invest: Invest,
    
    BondDetails: BondDetails,
    
    InvestorSupport: InvestorSupport,
    
    Technology: Technology,
    
    CivicZoo: CivicZoo,
    
    Profile: Profile,
    
    Careers: Careers,
    
    CommunityFeed: CommunityFeed,
    
    Applications: Applications,
    
    Leaderboard: Leaderboard,
    
    Messages: Messages,
    
    Settings: Settings,
    
    MessageThread: MessageThread,
    
    ZooVendors: ZooVendors,
    
    CivicGuardians: CivicGuardians,
    
    PartnerPortal: PartnerPortal,
    
    MasterAdminConsole: MasterAdminConsole,
    
    PublicPageEditor: PublicPageEditor,
    
    CampaignBuilder: CampaignBuilder,
    
    BillingPortal: BillingPortal,
    
    CivicPartnerDirectory: CivicPartnerDirectory,
    
    CivicPartnerProfile: CivicPartnerProfile,
    
    Directory: Directory,
    
    UserProfile: UserProfile,
    
    SocialHub: SocialHub,
    
    Onboarding: Onboarding,
    
    Public: Public,
    
    PartnerDirectory: PartnerDirectory,
    
    HowItWorks: HowItWorks,
    
    Code1: Code1,
    
    InvestmentPool: InvestmentPool,
    
    Developers: Developers,
    
    CaseStudies: CaseStudies,
    
    CryptoNews: CryptoNews,
    
    EducationHub: EducationHub,
    
    Governance: Governance,
    
    insights: insights,
    
    insightdetails: insightdetails,
    
    GettingStarted: GettingStarted,
    
    riskdisclosure: riskdisclosure,
    
    terms: terms,
    
    privacy: privacy,
    
    legalnotice: legalnotice,
    
    SavingsBondsMarketplace: SavingsBondsMarketplace,
    
    BondPayments: BondPayments,
    
    VerifyIdentity: VerifyIdentity,
    
    Minter: Minter,
    
    CreateToken: CreateToken,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Services" element={<Services />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/BondMarketplace" element={<BondMarketplace />} />
                
                <Route path="/Invest" element={<Invest />} />
                
                <Route path="/BondDetails" element={<BondDetails />} />
                
                <Route path="/InvestorSupport" element={<InvestorSupport />} />
                
                <Route path="/Technology" element={<Technology />} />
                
                <Route path="/CivicZoo" element={<CivicZoo />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Careers" element={<Careers />} />
                
                <Route path="/CommunityFeed" element={<CommunityFeed />} />
                
                <Route path="/Applications" element={<Applications />} />
                
                <Route path="/Leaderboard" element={<Leaderboard />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/MessageThread" element={<MessageThread />} />
                
                <Route path="/ZooVendors" element={<ZooVendors />} />
                
                <Route path="/CivicGuardians" element={<CivicGuardians />} />
                
                <Route path="/PartnerPortal" element={<PartnerPortal />} />
                
                <Route path="/MasterAdminConsole" element={<MasterAdminConsole />} />
                
                <Route path="/PublicPageEditor" element={<PublicPageEditor />} />
                
                <Route path="/CampaignBuilder" element={<CampaignBuilder />} />
                
                <Route path="/BillingPortal" element={<BillingPortal />} />
                
                <Route path="/CivicPartnerDirectory" element={<CivicPartnerDirectory />} />
                
                <Route path="/CivicPartnerProfile" element={<CivicPartnerProfile />} />
                
                <Route path="/Directory" element={<Directory />} />
                
                <Route path="/UserProfile" element={<UserProfile />} />
                
                <Route path="/SocialHub" element={<SocialHub />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/Public" element={<Public />} />
                
                <Route path="/PartnerDirectory" element={<PartnerDirectory />} />
                
                <Route path="/HowItWorks" element={<HowItWorks />} />
                
                <Route path="/Code1" element={<Code1 />} />
                
                <Route path="/InvestmentPool" element={<InvestmentPool />} />
                
                <Route path="/Developers" element={<Developers />} />
                
                <Route path="/CaseStudies" element={<CaseStudies />} />
                
                <Route path="/CryptoNews" element={<CryptoNews />} />
                
                <Route path="/EducationHub" element={<EducationHub />} />
                
                <Route path="/Governance" element={<Governance />} />
                
                <Route path="/insights" element={<insights />} />
                
                <Route path="/insightdetails" element={<insightdetails />} />
                
                <Route path="/GettingStarted" element={<GettingStarted />} />
                
                <Route path="/riskdisclosure" element={<riskdisclosure />} />
                
                <Route path="/terms" element={<terms />} />
                
                <Route path="/privacy" element={<privacy />} />
                
                <Route path="/legalnotice" element={<legalnotice />} />
                
                <Route path="/SavingsBondsMarketplace" element={<SavingsBondsMarketplace />} />
                
                <Route path="/BondPayments" element={<BondPayments />} />
                
                <Route path="/VerifyIdentity" element={<VerifyIdentity />} />
                
                <Route path="/Minter" element={<Minter />} />
                
                <Route path="/CreateToken" element={<CreateToken />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}