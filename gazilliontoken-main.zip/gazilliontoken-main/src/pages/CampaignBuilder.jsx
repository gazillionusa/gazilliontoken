import React, { useState } from 'react';
import { CivicCampaign } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Loader2, Zap, Trophy, Gift, ArrowLeft, ArrowRight, CalendarIcon, Send } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate, Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { format } from "date-fns";

export default function CampaignBuilder() {
    const navigate = useNavigate();
    const [step, setStep] = useState(1);
    const [submitting, setSubmitting] = useState(false);
    const [campaign, setCampaign] = useState({
        campaign_name: '',
        description: '',
        campaign_type: 'xp_reward',
        reward_type: 'xp',
        reward_amount: 100,
        requirement_description: '',
        start_date: null,
        end_date: null,
        max_participants: null,
        status: 'draft',
    });

    const handleInputChange = (field, value) => {
        setCampaign(prev => ({ ...prev, [field]: value }));
    };

    const handleNext = () => setStep(s => s + 1);
    const handleBack = () => setStep(s => s - 1);

    const handleSubmit = async () => {
        setSubmitting(true);
        try {
            const user = await User.me();
            if (!user.partner_id) {
                toast.error("You are not associated with a partner account.");
                setSubmitting(false);
                return;
            }

            const dataToCreate = {
                ...campaign,
                partner_id: user.partner_id,
                reward_amount: Number(campaign.reward_amount),
                max_participants: campaign.max_participants ? Number(campaign.max_participants) : null,
                status: 'active'
            };

            await CivicCampaign.create(dataToCreate);
            toast.success("Campaign created successfully!");
            navigate(createPageUrl("PartnerPortal"));

        } catch (error) {
            toast.error("Failed to create campaign.");
            console.error(error);
        } finally {
            setSubmitting(false);
        }
    };
    
    return (
        <div className="min-h-screen px-6 py-8">
            <div className="max-w-2xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white">Create New Campaign</h1>
                        <p className="text-gray-400">Engage the community with rewards and challenges.</p>
                    </div>
                     <Link to={createPageUrl("PartnerPortal")}>
                        <Button variant="outline"><ArrowLeft className="w-4 h-4 mr-2" /> Cancel</Button>
                    </Link>
                </div>
                
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white">Step {step} of 3</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {step === 1 && (
                            <div className="space-y-4">
                                <h3 className="text-xl text-white font-semibold">Campaign Details</h3>
                                <div className="space-y-2">
                                    <Label className="text-white">Campaign Name</Label>
                                    <Input value={campaign.campaign_name} onChange={e => handleInputChange('campaign_name', e.target.value)} placeholder="e.g., Downtown Cleanup Challenge" className="glass-effect border-white/20 bg-transparent text-white" />
                                </div>
                                 <div className="space-y-2">
                                    <Label className="text-white">Description</Label>
                                    <Textarea value={campaign.description} onChange={e => handleInputChange('description', e.target.value)} placeholder="Describe your campaign..." className="glass-effect border-white/20 bg-transparent text-white" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-white">Campaign Type</Label>
                                     <Select value={campaign.campaign_type} onValueChange={(v) => handleInputChange('campaign_type', v)}>
                                        <SelectTrigger className="glass-effect border-white/20 bg-transparent text-white">
                                            <SelectValue placeholder="Select type" />
                                        </SelectTrigger>
                                        <SelectContent className="bg-slate-700 border-white/20">
                                            <SelectItem value="xp_reward" className="text-white focus:bg-white/10">XP Reward</SelectItem>
                                            <SelectItem value="badge_drop" className="text-white focus:bg-white/10">Badge Drop</SelectItem>
                                            <SelectItem value="nft_drop" className="text-white focus:bg-white/10">NFT Drop</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <Button onClick={handleNext} className="w-full primary-gradient text-white">Next <ArrowRight className="w-4 h-4 ml-2" /></Button>
                            </div>
                        )}
                        {step === 2 && (
                            <div className="space-y-4">
                                 <h3 className="text-xl text-white font-semibold">Reward & Requirements</h3>
                                 <div className="space-y-2">
                                    <Label className="text-white">Reward Amount (XP)</Label>
                                    <Input type="number" value={campaign.reward_amount} onChange={e => handleInputChange('reward_amount', e.target.value)} className="glass-effect border-white/20 bg-transparent text-white" />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-white">Requirement</Label>
                                    <Textarea value={campaign.requirement_description} onChange={e => handleInputChange('requirement_description', e.target.value)} placeholder="What do users need to do?" className="glass-effect border-white/20 bg-transparent text-white" />
                                </div>
                                 <div className="flex gap-2">
                                    <Button onClick={handleBack} variant="outline" className="w-full">Back</Button>
                                    <Button onClick={handleNext} className="w-full primary-gradient text-white">Next <ArrowRight className="w-4 h-4 ml-2" /></Button>
                                </div>
                            </div>
                        )}
                         {step === 3 && (
                            <div className="space-y-4">
                                <h3 className="text-xl text-white font-semibold">Schedule & Publish</h3>
                                 <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-2">
                                        <Label className="text-white">Start Date</Label>
                                        <Popover>
                                            <PopoverTrigger asChild>
                                                <Button variant="outline" className="w-full justify-start glass-effect border-white/20 bg-transparent text-white">{campaign.start_date ? format(campaign.start_date, 'PPP') : "Pick a date"}</Button>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={campaign.start_date} onSelect={d => handleInputChange('start_date', d)} initialFocus /></PopoverContent>
                                        </Popover>
                                    </div>
                                    <div className="space-y-2">
                                        <Label className="text-white">End Date</Label>
                                        <Popover>
                                            <PopoverTrigger asChild>
                                                <Button variant="outline" className="w-full justify-start glass-effect border-white/20 bg-transparent text-white">{campaign.end_date ? format(campaign.end_date, 'PPP') : "Pick a date"}</Button>
                                            </PopoverTrigger>
                                            <PopoverContent className="w-auto p-0"><Calendar mode="single" selected={campaign.end_date} onSelect={d => handleInputChange('end_date', d)} initialFocus /></PopoverContent>
                                        </Popover>
                                    </div>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-white">Max Participants (optional)</Label>
                                    <Input type="number" value={campaign.max_participants || ''} onChange={e => handleInputChange('max_participants', e.target.value)} placeholder="Leave blank for unlimited" className="glass-effect border-white/20 bg-transparent text-white" />
                                </div>
                                <div className="flex gap-2">
                                    <Button onClick={handleBack} variant="outline" className="w-full">Back</Button>
                                    <Button onClick={handleSubmit} className="w-full primary-gradient text-white" disabled={submitting}>
                                        {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                                        <span className="ml-2">Publish Campaign</span>
                                    </Button>
                                </div>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}