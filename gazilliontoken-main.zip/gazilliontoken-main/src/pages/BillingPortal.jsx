import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { PartnerSubscription } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  CreditCard,
  Crown,
  Zap,
  Building,
  Users,
  BarChart3,
  Shield,
  ArrowLeft,
  Check,
  ExternalLink,
  Loader2 } from
'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

const SUBSCRIPTION_TIERS = {
  free: {
    name: 'Free',
    price: 0,
    features: ['basic_dashboard', 'public_profile'],
    limits: { staff: 1, campaigns: 3, events: 5, contacts: 100 },
    description: 'Perfect for getting started'
  },
  standard: {
    name: 'Standard',
    price: 49,
    features: ['basic_dashboard', 'public_profile', 'campaign_builder', 'team_management'],
    limits: { staff: 3, campaigns: 10, events: 15, contacts: 500 },
    description: 'Great for small teams'
  },
  pro: {
    name: 'Pro',
    price: 149,
    features: ['basic_dashboard', 'public_profile', 'campaign_builder', 'team_management', 'crm_basic', 'advanced_analytics', 'custom_branding'],
    limits: { staff: 10, campaigns: 50, events: 50, contacts: 2500 },
    description: 'Perfect for growing organizations'
  },
  enterprise: {
    name: 'Enterprise',
    price: 399,
    features: ['basic_dashboard', 'public_profile', 'campaign_builder', 'team_management', 'crm_basic', 'advanced_analytics', 'custom_branding', 'api_access', 'priority_support', 'sso_integration', 'civic_market_api'],
    limits: { staff: 'unlimited', campaigns: 'unlimited', events: 'unlimited', contacts: 'unlimited' },
    description: 'Full enterprise solution'
  }
};

const ADDON_FEATURES = {
  advertising_boost: { name: 'Advertising Boost', price: 49, description: 'Featured placement on homepage & Civic Zoo map' },
  client_support: { name: 'Client Support System', price: 29, description: 'Live chat widget & priority help desk' },
  xp_event_sponsor: { name: 'XP Event Sponsor', price: 99, description: 'Boost community XP + civic challenge creation', type: 'per_event' },
  consultation: { name: 'Consultation Session', price: 75, description: '30-minute 1-on-1 onboarding session', type: 'one_time' }
};

export default function BillingPortal() {
  const [user, setUser] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [upgrading, setUpgrading] = useState(false);

  useEffect(() => {
    loadSubscriptionData();
  }, []);

  const loadSubscriptionData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      if (userData.partner_id) {
        const subscriptions = await PartnerSubscription.filter({ partner_id: userData.partner_id });
        setSubscription(subscriptions[0] || {
          partner_id: userData.partner_id,
          subscription_tier: 'free',
          status: 'trial',
          features: SUBSCRIPTION_TIERS.free.features
        });
      }
    } catch (error) {
      console.error("Failed to load subscription:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = async (newTier) => {
    if (!subscription || !SUBSCRIPTION_TIERS[newTier]) return;
    setUpgrading(true);
    try {
      const tierData = SUBSCRIPTION_TIERS[newTier];

      if (subscription.id) {
        // Update existing subscription
        await PartnerSubscription.update(subscription.id, {
          subscription_tier: newTier,
          monthly_fee: tierData.price,
          features: tierData.features,
          max_staff_users: tierData.limits.staff === 'unlimited' ? 999 : tierData.limits.staff,
          max_campaigns: tierData.limits.campaigns === 'unlimited' ? 999 : tierData.limits.campaigns,
          max_events: tierData.limits.events === 'unlimited' ? 999 : tierData.limits.events,
          max_contacts: tierData.limits.contacts === 'unlimited' ? 99999 : tierData.limits.contacts,
          status: 'active'
        });
      } else {
        // Create new subscription
        const newSubscription = await PartnerSubscription.create({
          partner_id: subscription.partner_id,
          subscription_tier: newTier,
          monthly_fee: tierData.price,
          features: tierData.features,
          max_staff_users: tierData.limits.staff === 'unlimited' ? 999 : tierData.limits.staff,
          max_campaigns: tierData.limits.campaigns === 'unlimited' ? 999 : tierData.limits.campaigns,
          max_events: tierData.limits.events === 'unlimited' ? 999 : tierData.limits.events,
          max_contacts: tierData.limits.contacts === 'unlimited' ? 99999 : tierData.limits.contacts,
          status: 'active'
        });
        setSubscription(newSubscription);
      }

      toast.success(`Successfully upgraded to ${tierData.name} plan!`);
      loadSubscriptionData();
    } catch (error) {
      console.error('Upgrade error:', error);
      toast.error('Upgrade failed. Please try again.');
    } finally {
      setUpgrading(false);
    }
  };

  const openStripePortal = () => {
    // In production, this would redirect to Stripe Customer Portal
    toast.info('Stripe Customer Portal would open here in production');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
            </div>);

  }

  if (!user?.partner_id) {
    return (
      <div className="min-h-screen px-6 py-12">
                <div className="max-w-4xl mx-auto text-center">
                    <div className="glass-effect p-8 rounded-2xl border border-white/10">
                        <Building className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
                        <h2 className="text-2xl font-bold text-white mb-4">Access Denied</h2>
                        <p className="text-gray-300 mb-6">
                            You need to be associated with a Civic Partner organization to access billing.
                        </p>
                        <Link to={createPageUrl("Contact")}>
                            <Button className="primary-gradient text-white">
                                Contact Support
                            </Button>
                        </Link>
                    </div>
                </div>
            </div>);

  }

  // Safe tier access with fallback
  const currentTier = subscription?.subscription_tier || 'free';
  const currentPlan = SUBSCRIPTION_TIERS[currentTier] || SUBSCRIPTION_TIERS.free;

  return (
    <div className="min-h-screen px-6 py-8">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white">Subscription & Billing</h1>
                        <p className="text-gray-400">Manage your civic partner subscription and add-ons</p>
                    </div>
                    <div className="flex gap-3">
                        <Link to={createPageUrl("PartnerPortal")}>
                            <Button variant="outline">
                                <ArrowLeft className="w-4 h-4 mr-2" />
                                Back to Portal
                            </Button>
                        </Link>
                        {subscription?.stripe_customer_id &&
            <Button onClick={openStripePortal} className="bg-purple-600 hover:bg-purple-700">
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Stripe Portal
                            </Button>
            }
                    </div>
                </div>

                {/* Current Plan */}
                <Card className="glass-effect border-white/10 bg-transparent mb-8">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <Crown className="w-5 h-5 mr-2 text-amber-400" />
                            Current Plan: {currentPlan.name}
                            {subscription?.status === 'trial' &&
              <Badge variant="outline" className="ml-3 text-amber-400 border-amber-400">
                                    Trial
                                </Badge>
              }
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                            <div className="text-center">
                                <Users className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-white">{currentPlan.limits.staff}</p>
                                <p className="text-gray-400 text-sm">Staff Members</p>
                            </div>
                            <div className="text-center">
                                <Zap className="w-8 h-8 text-green-400 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-white">{currentPlan.limits.campaigns}</p>
                                <p className="text-gray-400 text-sm">Active Campaigns</p>
                            </div>
                            <div className="text-center">
                                <BarChart3 className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-white">{currentPlan.limits.events}</p>
                                <p className="text-gray-400 text-sm">Monthly Events</p>
                            </div>
                            <div className="text-center">
                                <Building className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                                <p className="text-2xl font-bold text-white">{currentPlan.limits.contacts}</p>
                                <p className="text-gray-400 text-sm">CRM Contacts</p>
                            </div>
                        </div>
                        {currentTier === 'free' &&
            <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-400/20 rounded-lg p-4">
                                <p className="text-white font-medium">Ready to unlock more features?</p>
                                <p className="text-gray-300 text-sm">Upgrade to access advanced campaign tools, team management, and CRM capabilities.</p>
                            </div>
            }
                    </CardContent>
                </Card>

                {/* Subscription Plans */}
                <h2 className="text-2xl font-bold text-white mb-6">Choose Your Plan</h2>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                    {Object.entries(SUBSCRIPTION_TIERS).map(([tier, plan]) =>
          <Card key={tier} className={`glass-effect border-white/10 bg-transparent relative ${
          tier === currentTier ? 'border-cyan-400/50 bg-cyan-400/5' : ''} ${
          tier === 'pro' ? 'border-purple-400/50' : ''}`}>
                            {tier === 'pro' &&
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                                    <Badge className="bg-purple-600 text-white">Most Popular</Badge>
                                </div>
            }
                            <CardHeader>
                                <CardTitle className="text-white text-center">
                                    {plan.name}
                                    {tier === currentTier &&
                <Badge variant="outline" className="ml-2 text-cyan-400 border-cyan-400">
                                            Current
                                        </Badge>
                }
                                </CardTitle>
                                <div className="text-center">
                                    <span className="text-3xl font-bold text-white">${plan.price}</span>
                                    <span className="text-gray-400">/month</span>
                                </div>
                                <p className="text-gray-300 text-sm text-center">{plan.description}</p>
                            </CardHeader>
                            <CardContent>
                                <ul className="space-y-2 mb-6">
                                    <li className="flex items-center text-sm text-gray-300">
                                        <Check className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                                        {plan.limits.staff} staff members
                                    </li>
                                    <li className="flex items-center text-sm text-gray-300">
                                        <Check className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                                        {plan.limits.campaigns} campaigns
                                    </li>
                                    <li className="flex items-center text-sm text-gray-300">
                                        <Check className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                                        {plan.limits.contacts} CRM contacts
                                    </li>
                                    {plan.features.includes('advanced_analytics') &&
                <li className="flex items-center text-sm text-gray-300">
                                            <Check className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                                            Advanced analytics
                                        </li>
                }
                                    {plan.features.includes('api_access') &&
                <li className="flex items-center text-sm text-gray-300">
                                            <Check className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                                            API access
                                        </li>
                }
                                </ul>
                                <Button
                onClick={() => handleUpgrade(tier)}
                disabled={tier === currentTier || upgrading}
                className={`w-full ${
                tier === 'pro' ? 'bg-purple-600 hover:bg-purple-700' :
                tier === 'enterprise' ? 'bg-amber-600 hover:bg-amber-700' :
                'primary-gradient'}`
                }>

                                    {upgrading ?
                <Loader2 className="w-4 h-4 animate-spin" /> :
                tier === currentTier ?
                'Current Plan' :

                `Upgrade to ${plan.name}`
                }
                                </Button>
                            </CardContent>
                        </Card>
          )}
                </div>

                {/* Add-ons */}
                <h2 className="text-2xl font-bold text-white mb-6">Premium Add-ons</h2>
                <div className="grid md:grid-cols-2 gap-6">
                    {Object.entries(ADDON_FEATURES).map(([key, addon]) =>
          <Card key={key} className="glass-effect border-white/10 bg-transparent">
                            <CardHeader>
                                <CardTitle className="text-white flex items-center justify-between">
                                    {addon.name}
                                    <div className="text-right">
                                        <span className="text-xl font-bold text-cyan-400">${addon.price}</span>
                                        {addon.type &&
                  <span className="text-gray-400 text-sm block">
                                                /{addon.type.replace('_', ' ')}
                                            </span>
                  }
                                    </div>
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <p className="text-gray-300 mb-4">{addon.description}</p>
                                <Button variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 w-full border-white/20 hover:bg-white/10">
                                    Add to Plan
                                </Button>
                            </CardContent>
                        </Card>
          )}
                </div>
            </div>
        </div>);

}