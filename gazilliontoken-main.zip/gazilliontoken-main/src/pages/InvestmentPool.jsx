
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, 
  Shield, 
  DollarSign, 
  Users,
  Clock,
  CheckCircle,
  AlertTriangle,
  BarChart3,
  PieChart,
  ArrowRight,
  Wallet,
  Info
} from 'lucide-react';
import { User } from "@/api/entities";
import { Investor } from "@/api/entities";
import { BondToken } from "@/api/entities";
import { BondIssuer } from "@/api/entities";
import { lendingOperations } from "@/api/functions";
import MetaTags from "@/components/seo/MetaTags";
import { createPageUrl } from '@/utils';

export default function InvestmentPoolPage() {
  const [searchParams] = useSearchParams();
  const poolType = searchParams.get('pool') || 'senior';
  
  const [user, setUser] = useState(null);
  const [investmentAmount, setInvestmentAmount] = useState('');
  const [isInvesting, setIsInvesting] = useState(false);
  const [poolData, setPoolData] = useState(null);
  const [userInvestments, setUserInvestments] = useState([]);

  const poolConfigs = {
    senior: {
      name: "Senior Lending Pool",
      apy: "8.5%",
      riskLevel: "Low",
      minInvestment: 1000,
      description: "Conservative investment backed by government-guaranteed collateral with priority repayment.",
      features: [
        "Government-backed collateral",
        "Priority repayment status",
        "Quarterly distributions",
        "Low default risk",
        "Stable returns"
      ],
      riskFactors: [
        "Interest rate fluctuations",
        "Early withdrawal penalties",
        "Limited liquidity"
      ],
      color: "green"
    },
    growth: {
      name: "Growth Lending Pool",
      apy: "12.3%",
      riskLevel: "Medium-High",
      minInvestment: 5000,
      description: "Higher yield opportunities through diversified portfolio of revenue-backed municipal projects.",
      features: [
        "Higher yield potential",
        "Diversified portfolio",
        "Monthly distributions",
        "Growth-oriented projects",
        "Active management"
      ],
      riskFactors: [
        "Higher default risk",
        "Market volatility",
        "Project completion risk",
        "Revenue dependency"
      ],
      color: "amber"
    }
  };

  const currentPool = poolConfigs[poolType];

  const loadPoolData = React.useCallback(() => {
    // In a real implementation, this would load actual pool performance data
    setPoolData({
      totalInvested: poolType === 'senior' ? 15500000 : 8900000,
      activeInvestors: poolType === 'senior' ? 1247 : 634,
      avgInvestment: poolType === 'senior' ? 12440 : 14043,
      ytdReturns: poolType === 'senior' ? 8.2 : 11.8,
      defaultRate: poolType === 'senior' ? 0.3 : 1.8
    });
  }, [poolType]);

  useEffect(() => {
    loadUserData();
    loadPoolData();
  }, [poolType, loadPoolData]);

  const loadUserData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);
      
      if (userData && userData.id) {
        // Load user's existing investments in this pool
        const investments = await BondToken.filter({
          investor_id: userData.id,
          status: 'active'
        });
        setUserInvestments(investments);
      }
    } catch (error) {
      console.error("Error loading user data:", error);
      // Set user to null to show login prompt on error
      setUser(null);
    }
  };

  const handleInvestment = async (e) => {
    e.preventDefault();
    setIsInvesting(true);

    try {
      const amount = parseFloat(investmentAmount);
      
      if (amount < currentPool.minInvestment) {
        alert(`Minimum investment is $${currentPool.minInvestment.toLocaleString()}`);
        return;
      }

      // Create investor record if needed
      let investor = await Investor.filter({ created_by: user.email });
      
      if (investor.length === 0) {
        investor = await Investor.create({
          investor_name: user.full_name || user.email,
          investor_type: 'individual',
          total_invested: amount,
          active_investments: 1,
          kyc_status: 'approved',
          risk_tolerance: poolType === 'senior' ? 'low' : 'medium',
          whitelist_status: 'approved'
        });
      } else {
        investor = investor[0];
        await Investor.update(investor.id, {
          total_invested: investor.total_invested + amount,
          active_investments: investor.active_investments + 1
        });
      }

      // Issue bond token for the investment
      const tokenResponse = await lendingOperations({
        operation: 'issue_bond_token',
        data: {
          investorId: investor.id,
          faceValue: amount,
          interestRate: parseFloat(currentPool.apy),
          termMonths: poolType === 'senior' ? 24 : 18
        }
      });

      if (tokenResponse.data.success) {
        alert(`Successfully invested $${amount.toLocaleString()} in ${currentPool.name}!`);
        setInvestmentAmount('');
        loadUserData();
        loadPoolData();
      } else {
        throw new Error('Investment processing failed');
      }

    } catch (error) {
      console.error("Investment error:", error);
      alert('Investment failed. Please try again.');
    } finally {
      setIsInvesting(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen px-6 py-12 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Please Log In to Continue</h2>
          <p className="text-gray-400 mb-6">You need to be logged in to invest in our lending pools.</p>
          <Link to={createPageUrl("Home")}>
            <Button onClick={async () => await User.login()}>
              Log In / Sign Up
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <MetaTags
        title={`${currentPool.name} - Investment Opportunity | Gazillion`}
        description={`Invest in ${currentPool.name} with ${currentPool.apy} APY. ${currentPool.description}`}
        keywords={`investment pool, lending, ${currentPool.apy}, municipal bonds, ${currentPool.riskLevel} risk`}
      />
      <div className="min-h-screen px-6 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <Badge className={`${currentPool.color === 'green' ? 'bg-green-600' : 'bg-amber-600'} text-white mb-4`}>
              {currentPool.apy} APY
            </Badge>
            <h1 className="text-4xl font-bold text-white mb-4">
              {currentPool.name}
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              {currentPool.description}
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Investment Form */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="invest" className="space-y-6">
                <TabsList className="glass-effect bg-transparent border-white/10 w-full">
                  <TabsTrigger value="invest" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">
                    Invest Now
                  </TabsTrigger>
                  <TabsTrigger value="details" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">
                    Pool Details
                  </TabsTrigger>
                  <TabsTrigger value="performance" className="data-[state=active]:bg-white/10 data-[state=active]:text-white">
                    Performance
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="invest">
                  <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                      <CardTitle className="text-white text-2xl">Make Your Investment</CardTitle>
                      <p className="text-gray-400">
                        Minimum investment: ${currentPool.minInvestment.toLocaleString()}
                      </p>
                    </CardHeader>
                    <CardContent>
                      <form onSubmit={handleInvestment} className="space-y-6">
                        <div>
                          <Label className="text-white text-lg">Investment Amount (USD)</Label>
                          <Input
                            type="number"
                            value={investmentAmount}
                            onChange={(e) => setInvestmentAmount(e.target.value)}
                            placeholder={currentPool.minInvestment.toString()}
                            min={currentPool.minInvestment}
                            className="glass-effect border-white/20 bg-transparent text-white text-2xl py-6 mt-2"
                            required
                          />
                          <p className="text-gray-400 text-sm mt-2">
                            Estimated annual return: ${investmentAmount ? 
                              (parseFloat(investmentAmount) * parseFloat(currentPool.apy) / 100).toLocaleString() 
                              : '0'}
                          </p>
                        </div>

                        <div className="glass-effect p-6 rounded-lg border border-cyan-400/20">
                          <h3 className="text-white font-semibold mb-4">Investment Summary</h3>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-gray-400">Pool:</span>
                              <span className="text-white">{currentPool.name}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Expected APY:</span>
                              <span className="text-green-400">{currentPool.apy}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Risk Level:</span>
                              <span className="text-white">{currentPool.riskLevel}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-400">Lock-up Period:</span>
                              <span className="text-white">{poolType === 'senior' ? '24' : '18'} months</span>
                            </div>
                          </div>
                        </div>

                        <Button
                          type="submit"
                          disabled={isInvesting || !investmentAmount || parseFloat(investmentAmount) < currentPool.minInvestment}
                          className="w-full primary-gradient hover:opacity-90 text-white font-semibold py-6 text-lg rounded-full"
                        >
                          {isInvesting ? (
                            <div className="flex items-center justify-center">
                              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                              Processing Investment...
                            </div>
                          ) : (
                            <>
                              <Wallet className="w-5 h-5 mr-2" />
                              Invest ${investmentAmount ? parseFloat(investmentAmount).toLocaleString() : '0'}
                            </>
                          )}
                        </Button>
                      </form>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="details">
                  <div className="space-y-6">
                    <Card className="glass-effect border-white/10 bg-transparent">
                      <CardHeader>
                        <CardTitle className="text-white">Pool Features</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {currentPool.features.map((feature, index) => (
                            <div key={index} className="flex items-center">
                              <CheckCircle className="w-5 h-5 text-green-400 mr-3" />
                              <span className="text-gray-300">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="glass-effect border-white/10 bg-transparent">
                      <CardHeader>
                        <CardTitle className="text-white flex items-center">
                          <AlertTriangle className="w-5 h-5 mr-2 text-amber-400" />
                          Risk Factors
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {currentPool.riskFactors.map((risk, index) => (
                            <div key={index} className="flex items-center">
                              <Info className="w-5 h-5 text-amber-400 mr-3" />
                              <span className="text-gray-300">{risk}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="performance">
                  {poolData && (
                    <div className="grid md:grid-cols-2 gap-6">
                      <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                          <CardTitle className="text-white">Pool Statistics</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="flex justify-between">
                            <span className="text-gray-400">Total Invested:</span>
                            <span className="text-white font-semibold">${poolData.totalInvested.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Active Investors:</span>
                            <span className="text-white font-semibold">{poolData.activeInvestors.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Avg Investment:</span>
                            <span className="text-white font-semibold">${poolData.avgInvestment.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">YTD Returns:</span>
                            <span className="text-green-400 font-semibold">{poolData.ytdReturns}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-400">Default Rate:</span>
                            <span className="text-white font-semibold">{poolData.defaultRate}%</span>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                          <CardTitle className="text-white">Your Investments</CardTitle>
                        </CardHeader>
                        <CardContent>
                          {userInvestments.length > 0 ? (
                            <div className="space-y-3">
                              {userInvestments.slice(0, 3).map((investment) => (
                                <div key={investment.id} className="flex justify-between items-center p-3 glass-effect rounded-lg">
                                  <div>
                                    <p className="text-white font-semibold">${investment.face_value.toLocaleString()}</p>
                                    <p className="text-gray-400 text-sm">{investment.interest_rate}% APY</p>
                                  </div>
                                  <Badge className="bg-green-600 text-white">Active</Badge>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-gray-400 text-center py-8">No investments yet</p>
                          )}
                        </CardContent>
                      </Card>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Quick Facts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center p-4 glass-effect rounded-lg">
                    <div className={`text-3xl font-bold ${currentPool.color === 'green' ? 'text-green-400' : 'text-amber-400'}`}>
                      {currentPool.apy}
                    </div>
                    <p className="text-gray-400 text-sm">Expected APY</p>
                  </div>
                  <div className="text-center p-4 glass-effect rounded-lg">
                    <div className="text-2xl font-bold text-white">
                      ${currentPool.minInvestment.toLocaleString()}
                    </div>
                    <p className="text-gray-400 text-sm">Minimum Investment</p>
                  </div>
                  <div className="text-center p-4 glass-effect rounded-lg">
                    <div className="text-xl font-bold text-white">{currentPool.riskLevel}</div>
                    <p className="text-gray-400 text-sm">Risk Level</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-lg">Need Help?</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400 text-sm mb-4">
                    Have questions about this investment opportunity?
                  </p>
                  <Button variant="outline" className="w-full border-white/30 hover:bg-white/10">
                    Contact Investment Team
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
