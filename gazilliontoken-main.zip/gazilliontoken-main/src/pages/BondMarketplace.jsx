import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Eye, ShoppingCart, Loader2, Search, SlidersHorizontal } from 'lucide-react';
import { format } from 'date-fns';

const BondCard = ({ bond }) => {
    const term = format(new Date(bond.maturity_date), 'yyyy');
    
    // Placeholder for a real "Buy GBT Tokens" modal/flow
    const handleBuyClick = () => {
        alert(`KYC check & disclaimer required to buy tokens for ${bond.bond_id}.`);
    };

    return (
        <Card className="bg-gray-800/50 border-teal-500/20 flex flex-col justify-between hover:border-teal-400/50 transition-all">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <CardTitle className="text-lg text-teal-300">{bond.bond_id}</CardTitle>
                    <Badge variant={bond.status === 'active' ? 'default' : 'secondary'} className={bond.status === 'active' ? 'bg-green-600' : ''}>{bond.status}</Badge>
                </div>
                <p className="text-sm text-gray-400">{bond.municipality_name}</p>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4 text-sm">
                <div>
                    <p className="text-gray-500">Yield</p>
                    <p className="font-semibold text-lg">{bond.coupon_rate}%</p>
                </div>
                <div>
                    <p className="text-gray-500">Maturity</p>
                    <p className="font-semibold text-lg">{term}</p>
                </div>
                <div>
                    <p className="text-gray-500">Available</p>
                    <p className="font-semibold text-lg">{bond.available_supply?.toLocaleString()}</p>
                </div>
                <div>
                    <p className="text-gray-500">Par Value</p>
                    <p className="font-semibold text-lg">${bond.par_value?.toLocaleString()}</p>
                </div>
            </CardContent>
            <CardFooter className="flex justify-between">
                <Button variant="ghost" size="sm"><Eye className="w-4 h-4 mr-2" />Details</Button>
                <Button size="sm" className="primary-gradient" onClick={handleBuyClick}>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Buy GBT Tokens
                </Button>
            </CardFooter>
        </Card>
    );
};

export default function BondMarketplace() {
    const [searchTerm, setSearchTerm] = useState('');
    const [filters, setFilters] = useState({ yield: 'all', term: 'all' });

    const { data: bonds, isLoading } = useQuery({
        queryKey: ['bonds'],
        queryFn: () => base44.entities.Bond.list()
    });

    const filteredBonds = bonds?.filter(bond => {
        const matchesSearch = (bond.municipality_name || '').toLowerCase().includes(searchTerm.toLowerCase()) || (bond.bond_id || '').toLowerCase().includes(searchTerm.toLowerCase());
        const matchesYield = filters.yield === 'all' || (filters.yield === 'high' ? bond.coupon_rate >= 5 : bond.coupon_rate < 5);
        const matchesTerm = filters.term === 'all' || (filters.term === 'long' ? new Date(bond.maturity_date).getFullYear() >= 2035 : new Date(bond.maturity_date).getFullYear() < 2035);
        return matchesSearch && matchesYield && matchesTerm;
    }) || [];

    return (
        <div>
            <div className="mb-8 p-6 rounded-lg bg-gray-800/30">
                <h1 className="text-3xl font-bold mb-2 text-gradient">Bond Marketplace</h1>
                <p className="text-gray-400">Browse active municipal bond NFTs and purchase fractional GBT tokens.</p>
                <div className="mt-6 flex flex-col md:flex-row gap-4">
                    <div className="relative flex-grow">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                        <Input 
                            placeholder="Search by Municipality or Bond ID..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10"
                        />
                    </div>
                    <div className="flex gap-4">
                        <Select onValueChange={(v) => setFilters(p => ({...p, yield: v}))} defaultValue="all">
                            <SelectTrigger className="w-full md:w-[150px]">
                                <SlidersHorizontal className="h-4 w-4 mr-2" />
                                <SelectValue placeholder="Yield" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Yields</SelectItem>
                                <SelectItem value="high">High Yield (&gt;=5%)</SelectItem>
                                <SelectItem value="low">Low Yield (&lt;5%)</SelectItem>
                            </SelectContent>
                        </Select>
                        <Select onValueChange={(v) => setFilters(p => ({...p, term: v}))} defaultValue="all">
                            <SelectTrigger className="w-full md:w-[150px]">
                                <SlidersHorizontal className="h-4 w-4 mr-2" />
                                <SelectValue placeholder="Term" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">All Terms</SelectItem>
                                <SelectItem value="long">Long Term (&gt;= 2035)</SelectItem>
                                <SelectItem value="short">Short Term (&lt; 2035)</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </div>
            </div>

            {isLoading ? (
                <div className="flex justify-center items-center h-64">
                    <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {filteredBonds.map(bond => <BondCard key={bond.id} bond={bond} />)}
                </div>
            )}
        </div>
    );
}