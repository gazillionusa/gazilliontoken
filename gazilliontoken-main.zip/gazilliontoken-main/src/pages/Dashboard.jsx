import React from 'react';
import { useGazillionWallet } from '../components/hooks/useGazillionWallet';
import { Button } from '@/components/ui/button';
import { Wallet, Loader2 } from 'lucide-react';

export default function Dashboard() {
  const { account, error, connectWallet } = useGazillionWallet();

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-gradient">Investor Dashboard</h1>
        <p className="text-gray-400">Track your portfolio, yield, and manage your bond tokens.</p>
      </div>

      <div className="flex flex-col items-center justify-center h-[50vh] bg-gray-800/30 rounded-lg p-8 border border-teal-500/20">
        {account ? (
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-200 mb-2">Wallet Connected</h2>
            <p className="text-lg font-mono text-teal-300 break-all bg-gray-900/50 px-4 py-2 rounded-md">{account}</p>
          </div>
        ) : (
          <div className="text-center">
            <p className="text-lg text-gray-400 mb-4">Please connect your wallet to view your dashboard.</p>
            <Button onClick={connectWallet} className="primary-gradient hover:opacity-90 text-white font-semibold px-6 py-3 text-base rounded-full transform hover:scale-105 transition-all duration-300 shadow-lg">
              <Wallet className="w-5 h-5 mr-2" />
              Connect Wallet
            </Button>
          </div>
        )}
        {error && <p className="text-red-500 mt-4">{error}</p>}
      </div>
    </div>
  );
}