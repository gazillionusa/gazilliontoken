import React from 'react';
import GovernanceVoting from '@/components/governance/GovernanceVoting';
import MetaTags from '@/components/seo/MetaTags';

export default function Governance() {
  return (
    <>
      <MetaTags
        title="Governance | Gazillion"
        description="Participate in the future of Gazillion. Vote on proposals and shape the platform."
        keywords="DAO, governance, voting, blockchain governance, community voting"
      />
      <GovernanceVoting />
    </>
  );
}