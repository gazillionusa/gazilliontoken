import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function Privacy() {
  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <Card className="glass-effect border-white/10 bg-transparent">
          <CardHeader>
            <CardTitle className="text-3xl text-white">Privacy Policy</CardTitle>
            <p className="text-gray-400">Last Updated: September 21, 2025</p>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-300">
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">1. Platforms Covered</h2>
              <p>This Privacy Policy applies to data collected across:</p>
              <ul className="list-disc list-inside space-y-1 mt-2 text-gray-400">
                <li>gazillionusa.com</li>
                <li>gazillionnft.com</li>
                <li>gazillioncoin.net</li>
                <li>gazillionbonds.com</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">2. What We Collect</h2>
              <p>We may collect the following from users:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Wallet addresses</li>
                <li>Email addresses (for receipts, updates)</li>
                <li>IP address and device info</li>
                <li>Bond purchase details (maturity, face value, APY, etc.)</li>
                <li>Metadata stored via NFT smart contracts</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">3. How We Use It</h2>
              <p>We use your information to:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Mint and confirm NFT bond purchases</li>
                <li>Provide investor dashboards</li>
                <li>Comply with regulatory and legal obligations</li>
                <li>Improve and secure the Platform</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">4. Third-Party Integrations</h2>
              <p>We integrate with:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                <li>Payment processors (e.g., Stripe)</li>
                <li>Wallet providers (e.g., MetaMask)</li>
                <li>Analytics tools (Google Analytics, Base 44 analytics suite)</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">5. Cookies</h2>
              <p>Cookies are used to maintain session states, track preferences, and support functionality.</p>
            </section>
            
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">6. Data Sharing</h2>
              <p>We do not sell personal data. We may share your information with:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                  <li>Regulators when legally required</li>
                  <li>Contractors or partners performing services under NDA</li>
                  <li>Law enforcement if a legal process is served</li>
              </ul>
            </section>
            
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">7. Blockchain Data</h2>
              <p>NFT transaction history is permanently recorded on the blockchain and cannot be modified or deleted.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">8. Security & Retention</h2>
              <p>We use AES-256 encryption and secure databases for off-chain data. Data is retained only as long as necessary for compliance and platform integrity.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">9. Your Rights</h2>
              <p>Depending on your location (e.g., California, Delaware), you may have rights to:</p>
              <ul className="list-disc list-inside space-y-1 mt-2">
                  <li>Access your data</li>
                  <li>Request corrections</li>
                  <li>Opt out of marketing communications</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">10. Children’s Privacy</h2>
              <p>Our services are not intended for individuals under 18. We do not knowingly collect data from minors.</p>
            </section>
            
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">11. Contact</h2>
              <p>Privacy-related questions may be directed to:</p>
              <p>Email: privacy@gazillionusa.com</p>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}