
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Loader2, Save, User as UserIcon, Globe, Lock, Twitter, Linkedin, Instagram, Link as LinkIcon } from 'lucide-react';

const checkUsernameAvailability = async (username) => {
    if (!username) return true;
    const existingUsers = await User.filter({ username });
    return existingUsers.length === 0;
};

export default function Settings() {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    
    const [username, setUsername] = useState('');
    const [isUsernameAvailable, setIsUsernameAvailable] = useState(true);
    const [debouncedUsername, setDebouncedUsername] = useState(username);

    // Manual debounce implementation
    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedUsername(username);
        }, 500);

        return () => {
            clearTimeout(handler);
        };
    }, [username]);


    useEffect(() => {
        const loadUser = async () => {
            try {
                const currentUser = await User.me();
                setUser(currentUser);
                setUsername(currentUser.username || '');
            } catch (error) {
                toast.error("Failed to load user data.");
            } finally {
                setLoading(false);
            }
        };
        loadUser();
    }, []);

    useEffect(() => {
        const checkAvailability = async () => {
            if (debouncedUsername && debouncedUsername !== user?.username) {
                const isAvailable = await checkUsernameAvailability(debouncedUsername);
                setIsUsernameAvailable(isAvailable);
            } else {
                setIsUsernameAvailable(true);
            }
        };
        checkAvailability();
    }, [debouncedUsername, user?.username]);

    const handleSave = async () => {
        if (!user) return;

        if (username && !isUsernameAvailable && username !== user.username) {
            toast.error("Username is not available.");
            return;
        }

        setSaving(true);
        try {
            const userData = { ...user, username };
            await User.updateMyUserData(userData);
            setUser(userData);
            toast.success("Settings saved successfully!");
        } catch (error) {
            toast.error("Failed to save settings.");
        } finally {
            setSaving(false);
        }
    };
    
    const handleFieldChange = (field, value) => {
        setUser(prev => ({...prev, [field]: value}));
    };
    
    const handleSocialLinkChange = (platform, value) => {
        setUser(prev => ({
            ...prev,
            social_links: {
                ...prev.social_links,
                [platform]: value
            }
        }));
    };

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="w-8 h-8 animate-spin text-cyan-400" /></div>;
    }
    
    if (!user) {
        return <div className="text-center py-12 text-white">Please log in to view settings.</div>;
    }

    return (
        <div className="min-h-screen px-6 py-8">
            <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                    <h1 className="text-3xl font-bold text-white">Settings</h1>
                    <Button onClick={handleSave} disabled={saving || !isUsernameAvailable}>
                        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                        <span className="ml-2">Save Changes</span>
                    </Button>
                </div>

                <div className="space-y-8">
                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white flex items-center"><UserIcon className="w-5 h-5 mr-2" />Public Profile</CardTitle></CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <Label htmlFor="username" className="text-white">Username</Label>
                                <div className="relative">
                                    <Input 
                                        id="username"
                                        value={username} 
                                        onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
                                        className="glass-effect pr-24"
                                    />
                                    <div className="absolute inset-y-0 right-0 pr-3 flex items-center text-xs">
                                        {debouncedUsername && username === debouncedUsername ? (
                                            isUsernameAvailable ? <span className="text-green-400">Available</span> : <span className="text-red-400">Taken</span>
                                        ) : (
                                            <span className="text-gray-400">Checking...</span>
                                        )}
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400 mt-1">Your public profile will be at /UserProfile?username={username}</p>
                            </div>
                             <div>
                                <Label htmlFor="bio" className="text-white">Bio</Label>
                                <textarea id="bio" value={user.bio || ''} onChange={(e) => handleFieldChange('bio', e.target.value)} className="w-full glass-effect p-2 rounded-md min-h-[100px]" />
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white flex items-center"><LinkIcon className="w-5 h-5 mr-2" />Social Links</CardTitle></CardHeader>
                        <CardContent className="space-y-4">
                            <div className="flex items-center space-x-2">
                                <Twitter className="w-5 h-5 text-gray-400" />
                                <Input value={user.social_links?.twitter || ''} onChange={e => handleSocialLinkChange('twitter', e.target.value)} placeholder="https://twitter.com/username" className="glass-effect"/>
                            </div>
                             <div className="flex items-center space-x-2">
                                <Linkedin className="w-5 h-5 text-gray-400" />
                                <Input value={user.social_links?.linkedin || ''} onChange={e => handleSocialLinkChange('linkedin', e.target.value)} placeholder="https://linkedin.com/in/username" className="glass-effect"/>
                            </div>
                             <div className="flex items-center space-x-2">
                                <Instagram className="w-5 h-5 text-gray-400" />
                                <Input value={user.social_links?.instagram || ''} onChange={e => handleSocialLinkChange('instagram', e.target.value)} placeholder="https://instagram.com/username" className="glass-effect"/>
                            </div>
                        </CardContent>
                    </Card>
                    
                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white flex items-center"><Lock className="w-5 h-5 mr-2" />Privacy</CardTitle></CardHeader>
                        <CardContent>
                            <div className="flex items-center justify-between">
                                <div>
                                    <Label htmlFor="is_public" className="text-white font-medium">Public Profile</Label>
                                    <p className="text-sm text-gray-400">Allow others to find and view your profile in the directory.</p>
                                </div>
                                <Switch id="is_public" checked={user.is_public} onCheckedChange={(checked) => handleFieldChange('is_public', checked)} />
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}
