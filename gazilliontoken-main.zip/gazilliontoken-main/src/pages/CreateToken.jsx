import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { FilePlus, Eye, Send } from 'lucide-react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function CreateToken() {
    const [bondData, setBondData] = useState({
        municipality_name: '',
        bond_id: '',
        par_value: '',
        maturity_date: '',
        coupon_rate: '',
        project_description: '',
    });
    const [file, setFile] = useState(null);
    const queryClient = useQueryClient();

    const createBondMutation = useMutation({
        mutationFn: (newBond) => base44.functions.invoke('createBondClass', newBond),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['bonds'] });
            toast.success('Token class created and published to marketplace!');
            // Reset form
            setBondData({
                municipality_name: '', bond_id: '', par_value: '',
                maturity_date: '', coupon_rate: '', project_description: ''
            });
            setFile(null);
        },
        onError: (error) => {
            const errorDetails = error.response?.data?.details || error.message;
            toast.error(`Failed to create token: ${errorDetails}`);
        }
    });

    const handleSubmit = async (e) => {
        e.preventDefault();
        // In a real app, you'd handle file upload first and get a URL.
        // For now, we'll just include a placeholder URL if a file is selected.
        const documentation_url = file ? `/uploads/placeholder/${file.name}` : '';
        
        const finalBondData = {
            ...bondData,
            par_value: Number(bondData.par_value),
            coupon_rate: Number(bondData.coupon_rate),
            documentation_url,
            // Mock data for fields not in form but in entity
            available_supply: Math.floor(Math.random() * 10000) + 1000, // Random supply
            status: 'active',
        };
        createBondMutation.mutate(finalBondData);
    };

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setBondData(prev => ({ ...prev, [id]: value }));
    };

    return (
        <div className="max-w-3xl mx-auto">
            <Card className="bg-gray-800/50 border-teal-500/20">
                <CardHeader>
                    <CardTitle className="flex items-center text-2xl">
                        <FilePlus className="w-6 h-6 mr-3 text-teal-400" />
                        Create New Token Class
                    </CardTitle>
                </CardHeader>
                <form onSubmit={handleSubmit}>
                    <CardContent className="space-y-6">
                        <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <Label htmlFor="municipality_name">Municipality Name</Label>
                                <Input id="municipality_name" value={bondData.municipality_name} onChange={handleInputChange} placeholder="e.g., City of Metropolis" required />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="bond_id">Token ID / Symbol</Label>
                                <Input id="bond_id" value={bondData.bond_id} onChange={handleInputChange} placeholder="e.g., METRO-2030-01" required />
                            </div>
                        </div>
                        <div className="grid md:grid-cols-3 gap-6">
                            <div className="space-y-2">
                                <Label htmlFor="par_value">Par Value ($)</Label>
                                <Input id="par_value" type="number" value={bondData.par_value} onChange={handleInputChange} placeholder="1000" required />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="coupon_rate">Coupon Rate (%)</Label>
                                <Input id="coupon_rate" type="number" step="0.01" value={bondData.coupon_rate} onChange={handleInputChange} placeholder="5.25" required />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="maturity_date">Maturity Date</Label>
                                <Input id="maturity_date" type="date" value={bondData.maturity_date} onChange={handleInputChange} required />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="project_description">Project Description</Label>
                            <Textarea id="project_description" value={bondData.project_description} onChange={handleInputChange} placeholder="Describe the municipal project this token will fund..." required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="documentation">Upload Documentation</Label>
                            <Input id="documentation" type="file" onChange={(e) => setFile(e.target.files[0])} className="file:text-white" />
                        </div>
                    </CardContent>
                    <CardFooter className="flex justify-end space-x-3">
                        <Button type="button" variant="outline">
                            <Eye className="w-4 h-4 mr-2" />
                            Preview Tokenization
                        </Button>
                        <Button type="submit" className="primary-gradient" disabled={createBondMutation.isPending}>
                            {createBondMutation.isPending ? 'Creating Class...' : <><Send className="w-4 h-4 mr-2" /> Create Token Class</>}
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </div>
    );
}