import React, { useState, useEffect } from 'react';
import { CivicPartner } from '@/api/entities';
import { CivicPartnerPortal } from '@/api/entities';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
    Building, 
    Search, 
    Briefcase, 
    Landmark, 
    Globe, 
    Loader2, 
    MapPin,
    ExternalLink,
    Users,
    Calendar
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CivicPartnerDirectory() {
    const [partners, setPartners] = useState([]);
    const [portals, setPortals] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [filterType, setFilterType] = useState('all');
    const [filterLocation, setFilterLocation] = useState('all');

    useEffect(() => {
        const loadPartners = async () => {
            try {
                const [partnerData, portalData] = await Promise.all([
                    CivicPartner.filter({ status: 'active' }, '-created_date'),
                    CivicPartnerPortal.filter({ is_active: true })
                ]);
                
                setPartners(partnerData);
                setPortals(portalData);
            } catch (error) {
                console.error("Failed to load partners:", error);
            } finally {
                setLoading(false);
            }
        };
        loadPartners();
    }, []);

    // Merge partner data with portal data
    const enrichedPartners = partners.map(partner => {
        const portal = portals.find(p => p.partner_id === partner.id);
        return { ...partner, portal };
    });

    const filteredPartners = enrichedPartners.filter(p => {
        const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (p.description || '').toLowerCase().includes(searchTerm.toLowerCase());
        const matchesType = filterType === 'all' || p.partner_type === filterType;
        return matchesSearch && matchesType;
    });

    const uniqueLocations = [...new Set(partners.map(p => p.location).filter(Boolean))];

    const PartnerCard = ({ partner }) => (
        <Card className="glass-effect border-white/10 bg-transparent hover:border-cyan-400/50 transition-all duration-300 group">
            <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                    {/* Logo */}
                    <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                        {partner.logo_url ? (
                            <img src={partner.logo_url} alt={partner.name} className="w-full h-full object-cover rounded-full" />
                        ) : (
                            partner.partner_type === 'business' ? 
                                <Briefcase className="w-8 h-8 text-cyan-400" /> : 
                                <Landmark className="w-8 h-8 text-cyan-400" />
                        )}
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                            <h3 className="text-xl font-bold text-white group-hover:text-cyan-300 transition-colors">
                                {partner.name}
                            </h3>
                            <Badge className={
                                partner.partner_type === 'business' ? 
                                    'bg-blue-600 text-white' : 
                                    'bg-purple-600 text-white'
                            }>
                                {partner.partner_type === 'business' ? 'Zoo Vendor' : 'Civic Guardian'}
                            </Badge>
                        </div>

                        <p className="text-gray-300 text-sm mb-3 line-clamp-2">
                            {partner.description || 'No description available'}
                        </p>

                        <div className="flex items-center space-x-4 text-xs text-gray-400 mb-4">
                            {partner.location && (
                                <div className="flex items-center">
                                    <MapPin className="w-3 h-3 mr-1" />
                                    {partner.location}
                                </div>
                            )}
                            <div className="flex items-center">
                                <Users className="w-3 h-3 mr-1" />
                                Active since {new Date(partner.created_date).getFullYear()}
                            </div>
                        </div>

                        <div className="flex justify-between items-center">
                            <div className="flex space-x-2">
                                {partner.website && (
                                    <a 
                                        href={partner.website} 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-cyan-400 hover:text-cyan-300"
                                    >
                                        <ExternalLink className="w-4 h-4" />
                                    </a>
                                )}
                            </div>
                            
                            {partner.portal && (
                                <Link to={createPageUrl(`CivicPartnerProfile?partner=${partner.portal.partner_name}`)}>
                                    <Button size="sm" variant="outline" className="text-cyan-400 border-cyan-400 hover:bg-cyan-400/10">
                                        View Profile
                                    </Button>
                                </Link>
                            )}
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );

    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        <Globe className="w-12 h-12 inline-block mr-4 text-cyan-400" />
                        Civic Partner <span className="text-gradient">Directory</span>
                    </h1>
                    <p className="text-lg text-gray-300 mb-2">
                        Discover the businesses and municipalities powering our community.
                    </p>
                    <p className="text-cyan-300 text-sm">
                        {filteredPartners.length} active partners • Connecting citizens with local organizations
                    </p>
                </div>

                {/* Filters */}
                <Card className="glass-effect border-white/10 bg-transparent mb-8">
                    <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row gap-4">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <Input
                                    placeholder="Search partners by name or description..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="pl-10 glass-effect text-white w-full"
                                />
                            </div>
                            <Select value={filterType} onValueChange={setFilterType}>
                                <SelectTrigger className="glass-effect text-white md:w-48">
                                    <SelectValue placeholder="Filter by type" />
                                </SelectTrigger>
                                <SelectContent className="bg-slate-800 text-white">
                                    <SelectItem value="all">All Types</SelectItem>
                                    <SelectItem value="business">Zoo Vendors</SelectItem>
                                    <SelectItem value="municipality">Civic Guardians</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </CardContent>
                </Card>

                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-cyan-400">
                                {partners.filter(p => p.partner_type === 'business').length}
                            </div>
                            <div className="text-sm text-gray-400">Zoo Vendors</div>
                        </CardContent>
                    </Card>
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-purple-400">
                                {partners.filter(p => p.partner_type === 'municipality').length}
                            </div>
                            <div className="text-sm text-gray-400">Civic Guardians</div>
                        </CardContent>
                    </Card>
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-green-400">
                                {partners.length}
                            </div>
                            <div className="text-sm text-gray-400">Total Partners</div>
                        </CardContent>
                    </Card>
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4 text-center">
                            <div className="text-2xl font-bold text-amber-400">
                                {uniqueLocations.length}
                            </div>
                            <div className="text-sm text-gray-400">Cities</div>
                        </CardContent>
                    </Card>
                </div>

                {/* Directory Grid */}
                {loading ? (
                    <div className="flex justify-center items-center py-20">
                        <Loader2 className="w-12 h-12 animate-spin text-cyan-400" />
                    </div>
                ) : filteredPartners.length > 0 ? (
                    <div className="space-y-6">
                        {filteredPartners.map(partner => (
                            <PartnerCard key={partner.id} partner={partner} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20">
                        <Building className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                        <h3 className="text-2xl font-bold text-white">No Partners Found</h3>
                        <p className="text-gray-400">Try adjusting your search filters.</p>
                    </div>
                )}

                {/* Call to Action */}
                <Card className="glass-effect border-white/10 bg-transparent mt-12">
                    <CardContent className="p-8 text-center">
                        <h3 className="text-2xl font-bold text-white mb-4">
                            Want to join our partner network?
                        </h3>
                        <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                            Whether you're a business looking to engage with the community or a municipality 
                            seeking innovative funding solutions, we'd love to have you as a partner.
                        </p>
                        <Link to={createPageUrl("PartnerOnboarding")}>
                            <Button className="primary-gradient text-white px-8 py-3">
                                Become a Partner
                            </Button>
                        </Link>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}