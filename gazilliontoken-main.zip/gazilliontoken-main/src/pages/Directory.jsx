import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { CivicPartner } from '@/api/entities';
import { CivicPartnerPortal } from '@/api/entities';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Building, Search, Briefcase, Landmark, Globe, Loader2, User as UserIcon } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const UserCard = ({ user }) =>
<Card className="glass-effect border-white/10 bg-transparent hover:border-cyan-400/50 transition-colors">
        <CardContent className="p-6">
            <div className="flex flex-col items-center text-center">
                <img
        src={user.avatar_image_url || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${user.email}`}
        alt={user.full_name}
        className="w-20 h-20 rounded-full mb-4 bg-white/10 p-1 object-cover" />

                <h3 className="text-xl font-bold text-white">{user.full_name || 'Anonymous User'}</h3>
                <p className="text-sm text-cyan-300 capitalize mb-2">{user.occupation || 'Community Member'}</p>
                {user.location &&
      <p className="text-xs text-gray-400 mb-3">{user.location}</p>
      }
                <p className="text-gray-400 text-sm mb-4 line-clamp-2 min-h-[2.5rem]">
                    {user.bio || 'No bio available.'}
                </p>
                {user.username ?
      <Link to={createPageUrl(`UserProfile?username=${user.username}`)} className="w-full">
                        <Button variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 w-full border-white/20 hover:bg-white/10">
                            View Profile
                        </Button>
                    </Link> :

      <Button variant="outline" disabled className="w-full text-gray-500 border-white/10">
                        Profile Incomplete
                    </Button>
      }
            </div>
        </CardContent>
    </Card>;


const PartnerCard = ({ partner }) =>
<Card className="glass-effect border-white/10 bg-transparent hover:border-cyan-400/50 transition-colors">
        <CardContent className="p-6">
            <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 rounded-full mb-4 bg-white/10 flex items-center justify-center p-1">
                    {partner.logo_url ?
        <img src={partner.logo_url} alt={partner.name} className="w-full h-full object-contain rounded-full" /> :

        partner.partner_type === 'business' ?
        <Briefcase className="w-10 h-10 text-cyan-400" /> :
        <Landmark className="w-10 h-10 text-cyan-400" />
        }
                </div>
                <h3 className="text-xl font-bold text-white">{partner.name}</h3>
                <p className="text-sm text-cyan-300 capitalize mb-2">
                    {partner.partner_type === 'business' ? 'Zoo Vendor' : 'Civic Guardian'}
                </p>
                <p className="text-gray-400 text-sm mb-4 line-clamp-2 min-h-[2.5rem]">
                    {partner.description || 'Official civic partner'}
                </p>
                <Link to={createPageUrl(`CivicPartnerProfile?slug=${partner.partner_name}`)} className="w-full">
                    <Button variant="outline" className="w-full text-white border-white/20 hover:bg-white/10">
                        View Profile
                    </Button>
                </Link>
            </div>
        </CardContent>
    </Card>;


export default function Directory() {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [sortBy, setSortBy] = useState('recent');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState(searchTerm);

  // Debounce search term
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchTerm]);

  const searchProfiles = useCallback(async () => {
    setLoading(true);
    try {
      let userResults = [];
      let partnerResults = [];

      // Load users if needed
      if (filterType === 'all' || filterType === 'user') {
        const allUsers = await User.filter({ is_public: true }, '-created_date', 500);

        // Filter users based on search term
        if (debouncedSearchTerm) {
          userResults = allUsers.filter((user) =>
          user.full_name?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          user.email?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          user.username?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          user.bio?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          user.occupation?.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
          );
        } else {
          userResults = allUsers;
        }
      }

      // Load partners if needed
      if (filterType === 'all' || filterType === 'business' || filterType === 'municipality') {
        const partnerFilter = { status: 'active', is_public: true };
        if (filterType !== 'all') {
          partnerFilter.partner_type = filterType;
        }

        const partners = await CivicPartner.filter(partnerFilter, '-created_date', 500);
        const allPortals = await CivicPartnerPortal.list();
        const portalMap = new Map(allPortals.map((p) => [p.partner_id, p.partner_name]));

        // Filter partners based on search term
        let filteredPartners = partners;
        if (debouncedSearchTerm) {
          filteredPartners = partners.filter((partner) =>
          partner.name?.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
          partner.description?.toLowerCase().includes(debouncedSearchTerm.toLowerCase())
          );
        }

        partnerResults = filteredPartners.map((p) => ({
          ...p,
          type: 'partner',
          partner_name: portalMap.get(p.id) || p.name?.toLowerCase().replace(/\s+/g, '-')
        }));
      }

      let combinedResults = [
      ...userResults.map((u) => ({ ...u, type: 'user' })),
      ...partnerResults];


      // Apply sorting
      if (sortBy === 'xp') {
        combinedResults.sort((a, b) => (b.lifetime_earnings || 0) - (a.lifetime_earnings || 0));
      } else if (sortBy === 'trending') {
        combinedResults.sort((a, b) => {
          const dateA = a.created_date ? new Date(a.created_date).getTime() : 0;
          const dateB = b.created_date ? new Date(b.created_date).getTime() : 0;
          const dateScoreA = dateA / (1000 * 60 * 60 * 24 * 30);
          const dateScoreB = dateB / (1000 * 60 * 60 * 24 * 30);
          const scoreA = dateScoreA + (a.lifetime_earnings || 0);
          const scoreB = dateScoreB + (b.lifetime_earnings || 0);
          return scoreB - scoreA;
        });
      } else {
        combinedResults.sort((a, b) => {
          const dateA = a.created_date ? new Date(a.created_date) : new Date(0);
          const dateB = b.created_date ? new Date(b.created_date) : new Date(0);
          return dateB.getTime() - dateA.getTime();
        });
      }

      setResults(combinedResults.slice(0, 100));
    } catch (error) {
      console.error("Failed to search profiles:", error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, [debouncedSearchTerm, filterType, sortBy]);

  useEffect(() => {
    searchProfiles();
  }, [searchProfiles]);

  return (
    <div className="min-h-screen px-4 sm:px-6 py-12">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12">
                    <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
                        <Globe className="w-10 h-10 sm:w-12 sm:h-12 inline-block mr-4 text-cyan-400" />
                        Public <span className="text-gradient">Directory</span>
                    </h1>
                    <p className="text-base sm:text-lg text-gray-300">
                        Discover the people, businesses, and municipalities powering our community.
                    </p>
                </div>

                {/* Filters */}
                <Card className="glass-effect border-white/10 bg-transparent mb-8">
                    <CardContent className="p-4">
                        <div className="flex flex-col sm:flex-row gap-4">
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                                <Input
                  placeholder="Search by name, bio, or organization..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 glass-effect text-white w-full" />

                            </div>
                            <Select value={filterType} onValueChange={setFilterType}>
                                <SelectTrigger className="glass-effect text-white w-full sm:w-48">
                                    <SelectValue placeholder="Filter by type" />
                                </SelectTrigger>
                                <SelectContent className="bg-slate-800 text-white">
                                    <SelectItem value="all">All Profiles</SelectItem>
                                    <SelectItem value="user">Investors</SelectItem>
                                    <SelectItem value="business">Zoo Vendors</SelectItem>
                                    <SelectItem value="municipality">Civic Guardians</SelectItem>
                                </SelectContent>
                            </Select>
                            <Select value={sortBy} onValueChange={setSortBy}>
                                <SelectTrigger className="glass-effect text-white w-full sm:w-48">
                                    <SelectValue placeholder="Sort by" />
                                </SelectTrigger>
                                <SelectContent className="bg-slate-800 text-white">
                                    <SelectItem value="recent">Most Recent</SelectItem>
                                    <SelectItem value="trending">Trending</SelectItem>
                                    <SelectItem value="xp">Highest XP</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </CardContent>
                </Card>

                {/* Results Count */}
                {!loading &&
        <div className="mb-6">
                        <p className="text-gray-400 text-sm">
                            Showing {results.length} {results.length === 1 ? 'result' : 'results'}
                            {debouncedSearchTerm && ` for "${debouncedSearchTerm}"`}
                        </p>
                    </div>
        }

                {/* Directory Grid */}
                {loading ?
        <div className="flex justify-center items-center py-20">
                        <Loader2 className="w-12 h-12 animate-spin text-cyan-400" />
                    </div> :
        results.length > 0 ?
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {results.map((item) =>
          item.type === 'user' ?
          <UserCard key={`user-${item.id}`} user={item} /> :
          <PartnerCard key={`partner-${item.id}`} partner={item} />
          )}
                    </div> :

        <div className="text-center py-20">
                        <Building className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                        <h3 className="text-2xl font-bold text-white mb-2">No Profiles Found</h3>
                        <p className="text-gray-400">
                            {debouncedSearchTerm ?
            'Try adjusting your search terms or filters.' :
            'Be the first to create a public profile!'}
                        </p>
                    </div>
        }
            </div>
        </div>);

}