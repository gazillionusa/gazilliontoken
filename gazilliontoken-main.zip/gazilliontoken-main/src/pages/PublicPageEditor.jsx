import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { CivicPartnerPortal } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { UploadFile } from '@/api/integrations';
import { Loader2, Save, Eye, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PublicPageEditor() {
    const [portal, setPortal] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const loadPortalData = useCallback(async () => {
        setLoading(true);
        try {
            const user = await User.me();
            if (user && user.partner_id) {
                const portals = await CivicPartnerPortal.filter({ partner_id: user.partner_id });
                if (portals.length > 0) {
                    setPortal(portals[0]);
                }
            }
        } catch (error) {
            toast.error("Failed to load portal data.");
            console.error(error);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        loadPortalData();
    }, [loadPortalData]);

    const handleInputChange = (field, value) => {
        setPortal(prev => ({ ...prev, [field]: value }));
    };

    const handleFileUpload = async (field, file) => {
        if (!file) return;
        setSaving(true);
        try {
            const { file_url } = await UploadFile({ file });
            handleInputChange(field, file_url);
            toast.success(`${field.replace('_', ' ')} uploaded successfully.`);
        } catch (error) {
            toast.error("File upload failed.");
        } finally {
            setSaving(false);
        }
    };

    const handleSave = async () => {
        if (!portal) return;
        setSaving(true);
        try {
            await CivicPartnerPortal.update(portal.id, {
                logo_url: portal.logo_url,
                banner_url: portal.banner_url,
                description: portal.description,
            });
            toast.success("Public page updated successfully!");
        } catch (error) {
            toast.error("Failed to save changes.");
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return <div className="flex justify-center items-center h-screen"><Loader2 className="w-8 h-8 animate-spin text-cyan-400" /></div>;
    }

    if (!portal) {
        return (
            <div className="min-h-screen px-6 py-12 text-center">
                <h2 className="text-2xl font-bold text-white mb-4">Portal Not Found</h2>
                <p className="text-gray-300 mb-6">We couldn't find your partner portal. Please contact support.</p>
                <Link to={createPageUrl("PartnerPortal")}>
                    <Button variant="outline"><ArrowLeft className="w-4 h-4 mr-2" /> Back to Portal</Button>
                </Link>
            </div>
        );
    }
    
    return (
        <div className="min-h-screen px-6 py-8">
            <div className="max-w-4xl mx-auto">
                <div className="flex items-center justify-between mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white">Edit Public Page</h1>
                        <p className="text-gray-400">Customize what the community sees on your partner page.</p>
                    </div>
                    <div className="flex gap-2">
                        <Link to={createPageUrl("PartnerPortal")}>
                            <Button variant="outline"><ArrowLeft className="w-4 h-4 mr-2" /> Back to Portal</Button>
                        </Link>
                        <Button onClick={handleSave} disabled={saving}>
                            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                            <span className="ml-2">Publish Changes</span>
                        </Button>
                    </div>
                </div>

                <div className="space-y-6">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader><CardTitle className="text-white">Branding</CardTitle></CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <Label className="text-white">Logo</Label>
                                <Input type="file" onChange={(e) => handleFileUpload('logo_url', e.target.files[0])} className="glass-effect border-white/20 bg-transparent text-white file:text-white" />
                                {portal.logo_url && <img src={portal.logo_url} alt="Logo Preview" className="w-24 h-24 mt-2 rounded-lg object-cover" />}
                            </div>
                            <div>
                                <Label className="text-white">Banner Image</Label>
                                <Input type="file" onChange={(e) => handleFileUpload('banner_url', e.target.files[0])} className="glass-effect border-white/20 bg-transparent text-white file:text-white" />
                                {portal.banner_url && <img src={portal.banner_url} alt="Banner Preview" className="w-full h-32 mt-2 rounded-lg object-cover" />}
                            </div>
                        </CardContent>
                    </Card>

                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader><CardTitle className="text-white">Business Information</CardTitle></CardHeader>
                        <CardContent>
                            <Label className="text-white">Description / About Section</Label>
                            <Textarea
                                value={portal.description || ''}
                                onChange={(e) => handleInputChange('description', e.target.value)}
                                className="min-h-[150px] glass-effect border-white/20 bg-transparent text-white"
                                placeholder="Tell the community about your organization..."
                            />
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}