import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, Wallet, TrendingUp, ShieldCheck, Check } from "lucide-react";

export default function Invest() {
  const howToSteps = [
    {
      title: "1. Explore Opportunities",
      description: "Browse our marketplace for municipal bonds from counties and cities across Nevada and Arizona.",
      icon: TrendingUp
    },
    {
      title: "2. Connect & Verify",
      description: "Securely connect your wallet and complete a quick verification to get started. It's simple and secure.",
      icon: Wallet
    },
    {
      title: "3. Purchase Your Bond NFT",
      description: "Select your desired bond and purchase the corresponding NFT. You are now an investor in community infrastructure!",
      icon: ShieldCheck
    },
    {
      title: "4. Earn Passive Returns",
      description: "Receive regular yield payments directly to your wallet until the bond matures. Track everything on your dashboard.",
      icon: TrendingUp
    }
  ];

  const nvMunicipalities = ["Clark County", "Washoe County", "City of Las Vegas", "City of Reno", "Henderson", "Douglas County"];
  const azMunicipalities = ["Maricopa County", "Pima County", "City of Phoenix", "City of Tucson", "Scottsdale", "Mesa"];

  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block glass-effect px-6 py-3 rounded-full mb-6">
            <span className="brand-accent text-sm font-medium">Invest in the Southwest</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Invest in the Future of <span className="text-gradient">Nevada & Arizona</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Fund critical infrastructure projects in communities across Nevada and Arizona. Your investment builds schools, roads, and green energy projects while providing you with stable returns.
          </p>
        </div>

        {/* How to Invest Section */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Your <span className="text-gradient">Investment Journey</span>
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {howToSteps.map((step, index) => (
              <Card key={index} className="glass-effect border-white/10 bg-transparent text-center">
                <CardHeader>
                  <div className="w-16 h-16 primary-gradient rounded-full flex items-center justify-center mx-auto mb-4">
                    <step.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-xl text-white">{step.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-400">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Available Regions Section */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Serving Communities Across <span className="text-gradient">NV & AZ</span>
          </h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="glass-effect border-white/10 bg-transparent">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center">
                  <MapPin className="w-6 h-6 mr-3 text-cyan-400" />
                  Nevada Municipalities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {nvMunicipalities.map((item) => (
                    <div key={item} className="flex items-center">
                      <Check className="w-4 h-4 text-green-400 mr-2" />
                      <span className="text-gray-300">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            <Card className="glass-effect border-white/10 bg-transparent">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center">
                  <MapPin className="w-6 h-6 mr-3 text-amber-400" />
                  Arizona Municipalities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {azMunicipalities.map((item) => (
                    <div key={item} className="flex items-center">
                      <Check className="w-4 h-4 text-green-400 mr-2" />
                      <span className="text-gray-300">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <div className="glass-effect p-12 rounded-3xl max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-white mb-6">
              Ready to See <span className="text-gradient">Available Bonds</span>?
            </h2>
            <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
              Explore the live marketplace to find specific bond offerings in Nevada and Arizona that match your investment goals.
            </p>
            <Link to={createPageUrl("BondMarketplace")}>
              <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-8 py-4 text-lg rounded-full transform hover:scale-105 transition-all duration-300">
                Explore Live Bonds
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}