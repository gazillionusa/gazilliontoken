import React from 'react';
import EducationalHub from '@/components/education/EducationalHub';
import MetaTags from '@/components/seo/MetaTags';

export default function EducationHubPage() {
  return (
    <>
      <MetaTags
        title="Educational Hub | Gazillion"
        description="Master municipal bond investing with comprehensive courses, videos, and resources."
        keywords="bond education, investment courses, municipal bonds learning, crypto education"
      />
      <EducationalHub />
    </>
  );
}