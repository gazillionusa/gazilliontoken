
import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from '@/api/entities';
import { Bond } from '@/api/entities';
import { Character } from '@/api/entities';
import { Card } from '@/components/ui/card';
import {
  PawPrint,
  Loader2,
  PersonStanding,
  Turtle,
  LineChart, // Replaced Fox
  Vote, // Replaced Bee
  PiggyBank, // Replaced Elephant
  Bird,
  Leaf, // Replaced Frog
  Wrench, // Replaced Squirrel
  Wallet, // Replaced Wind
  MessageSquare,
  Briefcase, // Added for Civic Partners
  Landmark // Added for Civic Partners
} from 'lucide-react';
import { Tooltip, TooltipProvider, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

const iconComponents = {
  PersonStanding,
  Turtle,
  LineChart,
  Vote,
  PiggyBank,
  Bird,
  Leaf,
  Wrench,
  Wallet,
  PawPrint
};

function CharacterCard({ character, unlocked, details }) {
  let Icon;
  // Map old, invalid icon names to new, valid ones
  switch (character.icon_name) {
    case 'Fox':Icon = iconComponents.LineChart;break;
    case 'Bee':Icon = iconComponents.Vote;break;
    case 'Squirrel':Icon = iconComponents.Wrench;break;
    case 'Wind':Icon = iconComponents.Wallet;break;
    case 'Frog':Icon = iconComponents.Leaf;break; // Added mapping for Frog
    case 'Elephant':Icon = iconComponents.PiggyBank;break; // Added mapping for Elephant
    default:Icon = iconComponents[character.icon_name] || iconComponents.PawPrint;
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className={`glass-effect border rounded-2xl p-6 transition-all duration-300 ${unlocked ? 'border-cyan-400/30 bg-cyan-400/10' : 'border-white/10 opacity-60 grayscale'}`}>
            <div className="flex flex-col items-center text-center">
              <div className={`w-24 h-24 rounded-full flex items-center justify-center mb-4 ${unlocked ? 'bg-gradient-to-br from-cyan-400 to-teal-500' : 'bg-white/10'}`}>
                {character.image_url ?
                <img src={character.image_url} alt={character.name} className="w-20 h-20 object-contain" /> :

                <Icon className={`w-12 h-12 ${unlocked ? 'text-white' : 'text-gray-400'}`} />
                }
              </div>
              <h3 className="text-lg font-bold text-white mb-1">{character.name}</h3>
              <p className={`text-xs ${unlocked ? 'text-cyan-300' : 'text-gray-400'}`}>{character.role}</p>
              {!unlocked &&
              <div className="mt-4 text-xs text-gray-400 text-center">
                  <p className="font-semibold">Unlock by:</p>
                  <p>{character.unlock_condition}</p>
                </div>
              }
               {details &&
              <div className="mt-4 text-sm text-white font-semibold">
                  {details}
                </div>
              }
            </div>
          </div>
        </TooltipTrigger>
        <TooltipContent className="bg-slate-800 border-slate-700 text-white">
          <p>{unlocked ? `You've unlocked ${character.name}!` : `Unlock: ${character.unlock_condition}`}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>);

}

export default function CivicZoo() {
  const [characters, setCharacters] = useState([]);
  const [user, setUser] = useState(null);
  const [userBonds, setUserBonds] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const [charData, userData, bondData] = await Promise.all([
        Character.list('-created_date'),
        User.me(),
        Bond.list() // In a real app, filter by user
        ]);
        setCharacters(charData);
        setUser(userData);
        // This is a placeholder for user's bonds.
        setUserBonds(bondData.filter((b) => b.created_by === userData.email));
      } catch (error) {
        console.error("Failed to load Civic Zoo data:", error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const getUnlockStatus = (characterId) => {
    if (!user || loading) return false;

    const govBondValue = userBonds.
    filter((b) => b.is_government_guaranteed).
    reduce((sum, b) => sum + (b.current_price || 0), 0);

    const greenBondCount = userBonds.
    filter((b) => b.category === 'green_energy' || b.category === 'green_esg').
    length;

    const infraBondCount = userBonds.
    filter((b) => b.category === 'infrastructure').
    length;

    switch (characterId) {
      case 'wizi':return (user.completed_missions || 0) >= 5; // Wizi the Owl - Education & Wisdom
      case 'muni':return govBondValue >= 50; // Muni the Turtle - Government bonds
      case 'fuzi':return user.has_resold_token || false; // Fuzi the Fox - Trading expert
      case 'bitzy':return (user.referral_count || 0) >= 3; // Bitzi the Bee - Community builder
      case 'elphi':return (user.lifetime_earnings || 0) >= 1000; // Elphi the Elephant - High earner
      case 'frizi':return greenBondCount > 0; // Frizi the Frog - Green/ESG investments
      case 'bizi':return infraBondCount >= 3; // Bizi the Beaver - Infrastructure builder
      case 'penny':return user.has_connected_external_wallet || false; // Penny the Pelican - Wallet connection
      case 'zillie':return true; // Zilli the Gator - Platform mascot (always unlocked)
      default:return false;
    }
  };

  const getCharacterDetails = (characterId) => {
    if (!user || loading) return null;

    const govBondValue = userBonds.
    filter((b) => b.is_government_guaranteed).
    reduce((sum, b) => sum + (b.current_price || 0), 0);

    const greenBondCount = userBonds.
    filter((b) => b.category === 'green_energy' || b.category === 'green_esg').
    length;

    const infraBondCount = userBonds.
    filter((b) => b.category === 'infrastructure').
    length;

    switch (characterId) {
      case 'wizi':return `🦉 ${user.completed_missions || 0}/5 missions completed`;
      case 'muni':return `🐢 $${govBondValue.toFixed(2)} in government bonds held`;
      case 'fuzi':return "🦊 Smart trader - Master of the secondary market!";
      case 'bitzy':return `🐝 ${user.referral_count || 0}/3 friends referred - Building the hive!`;
      case 'elphi':return `🐘 $${(user.lifetime_earnings || 0).toFixed(2)} earned - Big returns champion!`;
      case 'frizi':return `🐸 ${greenBondCount} Green Bond(s) - Saving the planet!`;
      case 'bizi':return `🦫 ${infraBondCount}/3 Infrastructure projects - Building communities!`;
      case 'penny':return '🐧 Wallet connected! Ready for payouts.';
      case 'zillie':return "🐊 Your friendly investment guide!";
      default:return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
      </div>);

  }

  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-7xl mx-auto">
        {/* Header with new zoo image */}
        <div className="text-center mb-12">
          <div className="inline-block glass-effect px-6 py-3 rounded-full mb-6">
            <span className="brand-accent text-sm font-medium">Gamified Investing</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Your <span className="text-gradient">Civic Center</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed mb-8">Unlock adorable characters as you invest in real municipal projects! Each character represents your growing impact on communities.</p>

          {/* Three Hub Bubbles */}
          <div className="mb-12 flex flex-col md:flex-row justify-center items-center gap-8">
            {/* Main Gazillion Zoo Bubble */}
            <Link to={createPageUrl("Dashboard")} className="flex flex-col items-center">
              <div className="group relative w-64 h-64 rounded-full primary-gradient p-3 transform transition-transform duration-300 hover:scale-105 shadow-2xl shadow-cyan-500/30">
                <div className="bg-transparent rounded-full w-full h-full flex items-center justify-center overflow-hidden">
                  <img
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/56ae11f47_ChatGPTImageSep22202503_43_36PM.png"
                    alt="All Gazillion Zoo Characters Together"
                    className="w-full h-full object-cover rounded-full" />
                </div>
                <div className="absolute inset-0 rounded-full border-4 border-transparent group-hover:border-cyan-300 transition-all duration-300"></div>
              </div>
              <h3 className="text-2xl font-bold text-white mt-4 text-center">Your Civic Zoo</h3>
              <p className="text-gray-300 text-center mt-2 max-w-xs">Collect characters as you invest in communities</p>
            </Link>

            {/* Civic Partners Hub Bubble - MIDDLE POSITION */}
            <Link to={createPageUrl("ZooVendors")} className="flex flex-col items-center">
              <button className="group relative w-64 h-64 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 p-3 transform transition-transform duration-300 hover:scale-105 shadow-2xl shadow-indigo-500/30">
                <div className="bg-transparent rounded-full w-full h-full flex items-center justify-center overflow-hidden">
                  <img
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/b5ecdd8a2_CivicProfileimage.png"
                    alt="Civic Partners - Businesses & Municipalities"
                    className="w-full h-full object-cover rounded-full" />
                </div>
                 <div className="absolute inset-0 rounded-full border-4 border-transparent group-hover:border-indigo-300 transition-all duration-300"></div>
              </button>
              <h3 className="text-2xl font-bold text-white mt-4 text-center">Civic Partners</h3>
              <p className="text-gray-300 text-center mt-2 max-w-xs">Businesses & Municipalities</p>
            </Link>

            {/* Community Hub Bubble */}
            <Link to={createPageUrl("CommunityFeed")} className="flex flex-col items-center">
              <button className="group relative w-64 h-64 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 p-3 transform transition-transform duration-300 hover:scale-105 shadow-2xl shadow-amber-500/30">
                <div className="bg-transparent rounded-full w-full h-full flex items-center justify-center overflow-hidden">
                  <img
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/8f422aede_SMGAZILLION.png"
                    alt="Join our community"
                    className="w-full h-full object-cover rounded-full" />
                </div>
                <div className="absolute inset-0 rounded-full border-4 border-transparent group-hover:border-amber-300 transition-all duration-300"></div>
              </button>
              <h3 className="text-2xl font-bold text-white mt-4 text-center">Investor Community</h3>
              <p className="text-gray-300 text-center mt-2 max-w-xs">Share progress & connect with fellow investors</p>
            </Link>
          </div>
        </div>

        <div className="grid grid-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {characters.map((character) =>
          <CharacterCard
            key={character.id}
            character={character}
            unlocked={getUnlockStatus(character.character_id)}
            details={getCharacterDetails(character.character_id)} />
          )}
        </div>
      </div>
    </div>
  );
}
