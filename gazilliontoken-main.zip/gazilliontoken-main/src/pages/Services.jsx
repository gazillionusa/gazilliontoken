
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Coins,
  TrendingUp,
  Shield,
  Clock,
  Globe,
  ArrowRight,
  CheckCircle,
  Star,
  Zap,
  UserCheck,
  Building2,
  FileCheck
} from "lucide-react";

export default function Services() {
  const bondTypes = [
    {
      name: "Infrastructure Bonds",
      apy: "7.2%",
      minInvestment: "$1,000",
      duration: "5-10 years",
      riskLevel: "Low",
      description: "Fund roads, bridges, and public transportation projects",
      features: ["Government backed", "Steady returns", "Infrastructure impact"],
      icon: Globe,
      color: "from-cyan-500 to-teal-600"
    },
    {
      name: "Green Energy Bonds",
      apy: "8.9%",
      minInvestment: "$500",
      duration: "3-7 years",
      riskLevel: "Medium",
      description: "Support renewable energy and sustainability initiatives",
      features: ["ESG compliant", "Higher yields", "Climate impact"],
      icon: Zap,
      color: "from-emerald-500 to-green-600"
    },
    {
      name: "Education Bonds",
      apy: "6.8%",
      minInvestment: "$250",
      duration: "10-15 years",
      riskLevel: "Low",
      description: "Invest in schools, universities, and education programs",
      features: ["Social impact", "Long-term stable", "Community benefit"],
      icon: Star,
      color: "from-teal-500 to-cyan-600"
    }
  ];

  const advantages = [
    {
      title: "Blockchain Transparency",
      description: "Every transaction and bond detail is recorded immutably on the blockchain",
      icon: Shield
    },
    {
      title: "Instant Liquidity",
      description: "Trade your bond NFTs on secondary markets anytime",
      icon: Coins
    },
    {
      title: "Fractional Ownership",
      description: "Invest in large municipal projects with smaller amounts",
      icon: TrendingUp
    },
    {
      title: "Global Access",
      description: "Access municipal bonds from cities worldwide",
      icon: Globe
    },
    {
      title: "Real-time Pricing",
      description: "Dynamic pricing based on market conditions and performance",
      icon: Clock
    }
  ];

  const platformServices = [
    {
      title: "Tokenization of Municipal Bonds",
      description: "Convert traditional municipal bonds into blockchain-based NFTs with smart contract automation and full regulatory compliance.",
      icon: Coins,
      color: "from-cyan-500 to-teal-600"
    },
    {
      title: "Investor Marketplace with Liquidity",
      description: "Access a global marketplace of vetted municipal bond NFTs with transparent pricing, instant settlement, and secondary market liquidity.",
      icon: TrendingUp,
      color: "from-blue-500 to-indigo-600"
    },
    {
      title: "Compliance & KYC Integration",
      description: "Built-in regulatory compliance with automated KYC/AML verification, investor accreditation, and SEC reporting.",
      icon: Shield,
      color: "from-green-500 to-emerald-600"
    },
    {
      title: "Issuer Onboarding & Origination Support",
      description: "Streamlined process for municipalities to issue bonds, manage campaigns, engage with investors, and track performance.",
      icon: Building2,
      color: "from-purple-500 to-pink-600"
    }
  ];

  return (
    <div className="min-h-screen px-4 sm:px-6 py-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block mb-6">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/779c793fb_GazillionServicesCharacters.png"
              alt="Gazillion Services Characters"
              className="w-64 h-64 sm:w-80 sm:h-80 rounded-full object-cover mx-auto border-4 border-cyan-400/30 shadow-lg"
            />
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold text-white mb-6 px-4">
            NFT Municipal <span className="text-gradient">Bond Services</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed px-4">
            Transform your investment strategy with blockchain-powered municipal bonds. 
            Earn steady returns while supporting community infrastructure.
          </p>
        </div>

        {/* Platform Services */}
        <div className="mb-20">
          <h2 className="text-2xl sm:text-3xl font-bold text-white text-center mb-12 px-4">
            Comprehensive <span className="text-gradient">Platform Services</span>
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {platformServices.map((service, index) => {
              const Icon = service.icon;
              return (
                <Card key={index} className="glass-effect border-white/10 bg-transparent hover:bg-white/5 transition-all duration-500">
                  <CardContent className="p-6 text-center">
                    <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-white mb-3">{service.title}</h3>
                    <p className="text-sm sm:text-base text-gray-400 leading-relaxed">{service.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* How Gazillion Works - Unified Flow */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            How <span className="text-gradient">Gazillion</span> Works
          </h2>
          
          <div className="glass-effect p-8 rounded-2xl max-w-5xl mx-auto">
            {/* Flow Chart at Top */}
            <div className="text-center mb-12">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/fcd649e78_Howitworksphoto.png"
                alt="Gazillion Network Trust Flow"
                className="w-full max-w-lg mx-auto rounded-lg shadow-lg mb-6"
              />
              <h3 className="text-2xl font-semibold text-white mb-3">Our Trust Network</h3>
              <p className="text-gray-400 max-w-2xl mx-auto">
                Secure ecosystem connecting all stakeholders through blockchain technology
              </p>
            </div>

            {/* Divider */}
            <div className="w-full h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent my-12"></div>

            {/* Blockchain-Powered Bonds with Patent Process */}
            <div className="text-center">
              <div className="w-24 h-24 primary-gradient rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="text-white text-3xl font-bold">NFT</div>
              </div>
              <h3 className="text-2xl font-semibold text-white mb-4">Blockchain-Powered Bonds</h3>
              <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
                Our proprietary technology transforms traditional municipal bonds into secure, tradeable NFT assets
              </p>
              
              {/* Patent Pending Process */}
              <div className="bg-white/5 rounded-lg p-8 border border-cyan-400/20">
                <Badge className="bg-amber-500 text-white mb-6 text-sm px-4 py-2">Patent Pending</Badge>
                <h4 className="text-2xl font-bold text-white mb-8">Gazillion Bond™ Process</h4>
                
                <div className="space-y-6 max-w-3xl mx-auto">
                  <div className="flex flex-col md:flex-row items-center md:items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                      1
                    </div>
                    <div className="text-center md:text-left flex-1">
                      <p className="text-white font-semibold text-lg mb-1">Investor Capital</p>
                      <p className="text-gray-400">Secure investment received</p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <ArrowRight className="w-8 h-8 text-cyan-400 rotate-90 md:rotate-0" />
                  </div>

                  <div className="flex flex-col md:flex-row items-center md:items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                      2
                    </div>
                    <div className="text-center md:text-left flex-1">
                      <p className="text-white font-semibold text-lg mb-1">Escrow (Insured)</p>
                      <p className="text-gray-400">Funds held in insured escrow by Albert Pro Insurance Corp</p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <ArrowRight className="w-8 h-8 text-cyan-400 rotate-90 md:rotate-0" />
                  </div>

                  <div className="flex flex-col md:flex-row items-center md:items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                      3
                    </div>
                    <div className="text-center md:text-left flex-1">
                      <p className="text-white font-semibold text-lg mb-1">NFT Bond (Minted)</p>
                      <p className="text-gray-400">Unique bond NFT created via blockchain development</p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <ArrowRight className="w-8 h-8 text-cyan-400 rotate-90 md:rotate-0" />
                  </div>

                  <div className="flex flex-col md:flex-row items-center md:items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-cyan-500 flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                      4
                    </div>
                    <div className="text-center md:text-left flex-1">
                      <p className="text-white font-semibold text-lg mb-1">Trust (Registered)</p>
                      <p className="text-gray-400">Legal trust established through Staffing Network Trust</p>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <ArrowRight className="w-8 h-8 text-cyan-400 rotate-90 md:rotate-0" />
                  </div>

                  <div className="flex flex-col md:flex-row items-center md:items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                      ✓
                    </div>
                    <div className="text-center md:text-left flex-1">
                      <p className="text-white font-semibold text-lg mb-1">Investor Portfolio</p>
                      <p className="text-gray-400">Gazillion Bond™ delivered to Zilli (investor)</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-cyan-400/10 rounded-lg border border-cyan-400/30">
                  <p className="text-cyan-300 font-semibold text-center">
                    = Gazillion Bond™ in Your Portfolio
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bond Types */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            Available <span className="text-gradient">Bond Categories</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {bondTypes.map((bond, index) => (
              <Card key={index} className="glass-effect border-white/10 bg-transparent group hover:bg-white/5 transition-all duration-500 relative overflow-hidden">
                <div className={`absolute inset-0 bg-gradient-to-br ${bond.color} opacity-5 group-hover:opacity-10 transition-opacity duration-500`}></div>
                
                <CardHeader className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 bg-gradient-to-br ${bond.color} rounded-xl flex items-center justify-center`}>
                      <bond.icon className="w-6 h-6 text-white" />
                    </div>
                    <Badge className={`bg-gradient-to-r ${bond.color} text-white border-none`}>
                      {bond.apy} APY
                    </Badge>
                  </div>
                  <CardTitle className="text-2xl text-white group-hover:text-gradient transition-all duration-300">
                    {bond.name}
                  </CardTitle>
                  <p className="text-gray-400">{bond.description}</p>
                </CardHeader>

                <CardContent className="relative z-10">
                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Minimum Investment</span>
                      <span className="text-white font-medium">{bond.minInvestment}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Duration</span>
                      <span className="text-white font-medium">{bond.duration}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Risk Level</span>
                      <Badge variant={bond.riskLevel === 'Low' ? 'default' : 'secondary'} className="text-xs">
                        {bond.riskLevel}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2 mb-6">
                    {bond.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center text-sm">
                        <CheckCircle className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Link to={createPageUrl("BondMarketplace")} className="block">
                    <Button className="w-full primary-gradient hover:opacity-90 text-white font-semibold rounded-full group-hover:scale-105 transition-all duration-300">
                      Explore Bonds
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Advantages */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-12">
            The <span className="text-gradient">Gazillion</span> Advantage
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {advantages.map((advantage, index) => (
              <Card key={index} className="glass-effect border-white/10 bg-transparent group hover:bg-white/5 transition-all duration-500">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 gold-gradient rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                    <advantage.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-white mb-4">{advantage.title}</h3>
                  <p className="text-gray-400 leading-relaxed">{advantage.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <div className="glass-effect p-12 rounded-3xl max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-white mb-6">
              Start Your <span className="text-gradient">NFT Bond</span> Journey
            </h2>
            <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
              Join the revolution in municipal finance. Earn steady returns while supporting community growth.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={createPageUrl("Dashboard")}>
                <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-8 py-4 text-lg rounded-full transform hover:scale-105 transition-all duration-300">
                  Open Dashboard
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to={createPageUrl("Contact")}>
                <Button variant="outline" className="bg-background text-slate-950 px-8 py-4 text-lg font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/30 hover:bg-white/10 rounded-full backdrop-blur-sm">
                  Schedule Consultation
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
