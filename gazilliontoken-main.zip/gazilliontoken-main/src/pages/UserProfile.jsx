import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Post } from '@/api/entities'; // Import Post entity
import { Bond } from '@/api/entities'; // Import Bond entity
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress"; // For XP meter
import PostCard from '@/components/community/PostCard'; // Reuse PostCard
import { Loader2, Globe, Building, Lock, Twitter, Linkedin, Instagram, Zap, Award } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function UserProfile() {
    const [profile, setProfile] = useState(null);
    const [posts, setPosts] = useState([]);
    const [bonds, setBonds] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const params = new URLSearchParams(window.location.search);
                const username = params.get('username');
                
                if (!username) {
                    setError("No username provided.");
                    setLoading(false);
                    return;
                }

                const users = await User.filter({ username: username });
                if (users.length === 0) {
                    setError("User not found.");
                    setLoading(false);
                    return;
                }

                const userProfile = users[0];
                if (!userProfile.is_public) {
                    setError("This profile is private.");
                    setLoading(false);
                    return;
                }
                
                setProfile(userProfile);

                // Fetch user's posts and bonds
                const [userPosts, userBonds] = await Promise.all([
                    Post.filter({ created_by: userProfile.email }, '-created_date', 5),
                    Bond.filter({ created_by: userProfile.email }, '-created_date', 5) // Simplified logic for "supported bonds"
                ]);
                setPosts(userPosts);
                setBonds(userBonds);

            } catch (err) {
                setError("Failed to load profile.");
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchProfile();
    }, []);

    // ... existing loading and error states ...
    if (loading) {
        return <div className="flex justify-center items-center min-h-screen"><Loader2 className="w-12 h-12 animate-spin text-cyan-400" /></div>;
    }

    if (error) {
        return (
            <div className="min-h-screen flex items-center justify-center text-center px-6">
                <Card className="glass-effect p-8">
                    <CardHeader>
                        <Lock className="w-16 h-16 text-red-400 mx-auto mb-4" />
                        <CardTitle className="text-2xl text-white">{error}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Link to={createPageUrl("Directory")}>
                            <Button variant="outline">Back to Directory</Button>
                        </Link>
                    </CardContent>
                </Card>
            </div>
        );
    }
    
    if (!profile) return null;

    const xp = profile.lifetime_earnings || 0;
    const level = Math.floor(xp / 1000) + 1;
    const xpForNextLevel = level * 1000;
    const xpProgress = (xp % 1000) / 10;


    return (
        <div className="min-h-screen">
            {/* ... existing header ... */}
            <div className="h-48 md:h-64 bg-slate-800 relative">
                {profile.cover_image_url && <img src={profile.cover_image_url} alt="Cover" className="w-full h-full object-cover" />}
                <div className="absolute inset-0 bg-black/30"></div>
            </div>
            <div className="max-w-5xl mx-auto px-6 -mt-20">
                <div className="flex flex-col md:flex-row items-center md:items-end md:space-x-6">
                    <img
                        src={profile.avatar_image_url || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${profile.email}`}
                        alt={profile.full_name}
                        className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-slate-900 bg-slate-700 object-cover"
                    />
                    <div className="text-center md:text-left pt-4 flex-grow">
                        <h1 className="text-3xl md:text-4xl font-bold text-white">{profile.full_name}</h1>
                        <p className="text-lg text-cyan-400">@{profile.username}</p>
                        {profile.occupation && <p className="text-gray-300">{profile.occupation}</p>}
                    </div>
                    <div className="pt-4 flex space-x-2">
                        <Button className="primary-gradient">Follow</Button>
                        <Button variant="outline">Message</Button>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="max-w-5xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
                {/* Left Sidebar */}
                <div className="lg:col-span-1 space-y-6">
                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white">About</CardTitle></CardHeader>
                        <CardContent>
                            <p className="text-gray-300">{profile.bio || "This user hasn't written a bio yet."}</p>
                             <div className="mt-4 space-y-2 text-sm">
                                {profile.location && <p className="flex items-center text-gray-400"><Globe className="w-4 h-4 mr-2" />{profile.location}</p>}
                                {profile.organization_name && <p className="flex items-center text-gray-400"><Building className="w-4 h-4 mr-2" />{profile.organization_name}</p>}
                            </div>
                            <div className="mt-4 flex space-x-3">
                                {profile.social_links?.twitter && <a href={profile.social_links.twitter} target="_blank" rel="noopener noreferrer"><Twitter className="w-5 h-5 text-gray-400 hover:text-white" /></a>}
                                {profile.social_links?.linkedin && <a href={profile.social_links.linkedin} target="_blank" rel="noopener noreferrer"><Linkedin className="w-5 h-5 text-gray-400 hover:text-white" /></a>}
                                {profile.social_links?.instagram && <a href={profile.social_links.instagram} target="_blank" rel="noopener noreferrer"><Instagram className="w-5 h-5 text-gray-400 hover:text-white" /></a>}
                            </div>
                        </CardContent>
                    </Card>
                     <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white">Civic Status</CardTitle></CardHeader>
                        <CardContent>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center text-white">
                                    <span className="font-semibold">Level {level}</span>
                                    <span className="text-sm text-cyan-400">{xp.toLocaleString()} XP</span>
                                </div>
                                <Progress value={xpProgress} className="w-full h-2 [&>div]:bg-cyan-400" />
                                <p className="text-xs text-gray-400 text-right">{(xpForNextLevel - xp).toLocaleString()} XP to Level {level + 1}</p>
                            </div>
                        </CardContent>
                    </Card>
                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white">Badges</CardTitle></CardHeader>
                        <CardContent>
                            <p className="text-gray-400 text-sm">Coming soon: Display of earned badges and achievements.</p>
                        </CardContent>
                    </Card>
                </div>
                {/* Right Content */}
                <div className="lg:col-span-2 space-y-6">
                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white">Supported Bonds</CardTitle></CardHeader>
                        <CardContent>
                            {bonds.length > 0 ? (
                                <div className="space-y-2">
                                {bonds.map(bond => (
                                    <div key={bond.id} className="text-sm text-gray-300 p-2 rounded bg-white/5">{bond.bond_name}</div>
                                ))}
                                </div>
                            ) : (
                                <p className="text-gray-400 text-center py-8">This user has not publicly supported any bonds yet.</p>
                            )}
                        </CardContent>
                    </Card>
                    <Card className="glass-effect">
                        <CardHeader><CardTitle className="text-white">Community Posts</CardTitle></CardHeader>
                        <CardContent className="space-y-4">
                           {posts.length > 0 ? (
                                posts.map(post => <PostCard key={post.id} post={post} currentUser={null} />)
                            ) : (
                                <p className="text-gray-400 text-center py-8">This user hasn't made any posts yet.</p>
                            )}
                        </CardContent>
                    </Card>
                </div>
            </div>
        </div>
    );
}