
import React from 'react';
import { Cpu, Shield, Layers, Globe, Network, FileCheck2, Cog, Lock, Building } from 'lucide-react';
import RwaSection from '@/components/rwa/RwaSection';
import { createPageUrl } from '@/utils';
import MetaTags from '@/components/seo/MetaTags';

const techFeatures = [
{
  icon: <Shield className="w-8 h-8 text-cyan-400" />,
  title: "Bank-Grade Security",
  description: "Utilizing advanced encryption and blockchain immutability to ensure your investments are protected."
},
{
  icon: <Layers className="w-8 h-8 text-green-400" />,
  title: "Proprietary NFT Protocol",
  description: "Our unique protocol for minting bond NFTs ensures compliance, transparency, and seamless integration with financial markets."
},
{
  icon: <Globe className="w-8 h-8 text-purple-400" />,
  title: "Decentralized & Global",
  description: "Built on a decentralized infrastructure, our platform provides 24/7 access to a global pool of investors and opportunities."
}];


const coreInfrastructure = [
{
  icon: <Network className="w-8 h-8 text-cyan-400" />,
  title: "Distributed Ledger Technology (DLT)",
  description: "Built on a high-performance, permissioned DLT, ensuring every transaction is transparent, immutable, and auditable by authorized parties."
},
{
  icon: <FileCheck2 className="w-8 h-8 text-green-400" />,
  title: "ERC-721 NFT Standard",
  description: "Each bond is minted as a unique NFT following the ERC-721 standard, guaranteeing verifiable ownership and enabling seamless trading."
},
{
  icon: <Cog className="w-8 h-8 text-purple-400" />,
  title: "Smart Contract Automation",
  description: "Bond terms, payments, and maturity payouts are encoded into self-executing smart contracts, eliminating intermediaries and reducing overhead."
},
{
  icon: <Lock className="w-8 h-8 text-red-400" />,
  title: "Cryptographic Security",
  description: "Leveraging cryptographic security and a decentralized architecture to provide robust protection against fraud and unauthorized access."
}];


const exampleBonds = [
{ name: "Downtown Light Rail", apy: "6.2% APY", value: "$25M Project", type: "Fixed APY" },
{ name: "Solar Energy Initiative", apy: "4-8% APY", value: "$15M Project", type: "Variable Revenue" },
{ name: "Community Park Expansion", apy: "5.5% APY", value: "$8M Project", type: "Community Bond" }];


export default function TechnologyPage() {
  return (
    <>
      <MetaTags
        title="Technology | Gazillion"
        description="Explore the cutting-edge blockchain technology, proprietary NFT protocol, and decentralized infrastructure that powers the Gazillion platform."
        keywords="blockchain technology, DLT, smart contracts, NFT protocol, decentralized finance"
      />
      <div className="min-h-screen">
            <div className="text-center pt-16 pb-12 px-4">
                <Cpu className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
                <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                    The <span className="text-gradient">Technology</span> Behind Gazillion
                </h1>
                <p className="text-lg text-gray-300 max-w-3xl mx-auto">
                    We leverage cutting-edge blockchain technology to make municipal bond investing more secure, transparent, and accessible than ever before.
                </p>
            </div>

            <div className="max-w-6xl mx-auto px-4 grid md:grid-cols-3 gap-8 mb-20">
                {techFeatures.map((feature) =>
        <div key={feature.title} className="glass-effect p-6 rounded-lg text-center">
                        <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                            {feature.icon}
                        </div>
                        <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                        <p className="text-gray-400">{feature.description}</p>
                    </div>
        )}
            </div>

            <RwaSection />

            <div id="pilot-program" className="py-12 md:py-20 px-4 bg-slate-900/50">
                <div className="max-w-4xl mx-auto text-center">
                    <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Gazillion Pilot Program

          </h2>
                    <p className="text-lg text-gray-300 leading-relaxed mb-8">
                        Gazillion is building the <strong>Robinhood for Bonds</strong> — starting with municipal bonds issued as NFTs on the blockchain. Our <strong>Pilot Program</strong> is designed to help <span className="text-cyan-400 font-bold">cities, nonprofits, and community projects</span> raise funds faster, cheaper, and more transparently.
                    </p>

                    <div className="grid md:grid-cols-2 gap-8 text-left my-12">
                        <div className="glass-effect p-6 rounded-lg">
                            <h3 className="text-2xl font-bold text-white mb-4">Who It's For</h3>
                            <ul className="space-y-3 text-gray-300">
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span>Small and mid-sized <strong>cities</strong> seeking cost-effective financing solutions</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Nonprofits</strong> raising capital for community impact projects</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Universities and schools</strong> funding infrastructure or student initiatives</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Green and ESG projects</strong> including renewable energy, housing, and climate initiatives</span></li>
                            </ul>
                        </div>
                        <div className="glass-effect p-6 rounded-lg">
                            <h3 className="text-2xl font-bold text-white mb-4">Benefits of the Pilot</h3>
                             <ul className="space-y-3 text-gray-300">
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Lower costs</strong> compared to traditional bond underwriting</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Faster funding</strong> through blockchain infrastructure</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Complete transparency</strong> for both investors and communities</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Investment accessibility</strong> — anyone can invest starting with just $100</span></li>
                                <li className="flex items-start"><span className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></span><span><strong>Direct community engagement</strong> — residents can invest directly in local projects</span></li>
                            </ul>
                        </div>
                    </div>

                    <div className="my-12">
                        <h3 className="text-2xl font-bold text-white mb-4">How It Works</h3>
                        <div className="max-w-2xl mx-auto text-left text-gray-300 space-y-4">
                            <p><strong>1. Apply to the Pilot:</strong> Cities, nonprofits, or project leaders submit their funding need (e.g., $1M for a new community center).</p>
                            <p><strong>2. Tokenize the Bond:</strong> Gazillion helps structure the bond as <strong>NFTs</strong> with transparent terms (face value, maturity, coupon rate).</p>
                            <p><strong>3. Launch & Fund:</strong> Investors — local residents or global supporters — purchase the NFT bonds in small, accessible amounts (starting at $100).</p>
                            <p><strong>4. Impact & Redemption:</strong> Funds are delivered to the project, and bondholders earn yield or redemption at maturity, all tracked on-chain.</p>
                        </div>
                    </div>

                    <div className="my-12">
                        <a href={createPageUrl('Contact')} className="inline-block primary-gradient text-white font-bold text-lg px-8 py-4 rounded-lg transition-transform hover:scale-105">
                            Apply for the Pilot Program
                        </a>
                    </div>
                    <p className="text-sm text-gray-500">
                        Together, we can create a new standard for community funding — making bonds accessible, transparent, and built for the digital age. Be among the first to launch an NFT Bond with Gazillion.
                    </p>
                </div>
            </div>

            <div className="max-w-6xl mx-auto px-4 py-16">
                <div className="text-center mb-12">
                    <h2 className="text-3xl md:text-4xl font-bold text-white">Our Core Infrastructure</h2>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {coreInfrastructure.map((item) =>
          <div key={item.title} className="glass-effect p-6 rounded-lg">
                            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                                {item.icon}
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                            <p className="text-gray-400">{item.description}</p>
                        </div>
          )}
                </div>
            </div>

            <div className="max-w-6xl mx-auto px-4 py-16">
                <div className="text-center mb-12">
                    <Building className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                    <h2 className="text-3xl md:text-4xl font-bold text-white">For Municipal Partners</h2>
                    <p className="text-lg text-gray-300 max-w-3xl mx-auto mt-4">
                        Empower your municipality with a fully configurable version of the Gazillion® platform. Offer bonds directly to your community and investors through a portal that reflects your city's identity, powered by our secure DLT backend.
                    </p>
                </div>
                
                <div className="glass-effect rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                    <div className="p-4 bg-slate-900/50 border-b border-white/10">
                        <p className="text-sm text-cyan-300 font-mono">phoenix.gazillionnft.com</p>
                    </div>
                    <div className="p-8">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                            <h3 className="text-3xl font-bold text-white">City of Phoenix <span className="text-gradient">Municipal Bond Portal</span></h3>
                            <div className="flex items-center gap-2 text-sm text-gray-400">
                                Powered by <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/40b4f9049_ChatGPTImageSep22202503_43_36PM.png" alt="Gazillion Logo" className="w-5 h-5" /> Gazillion®
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10 text-center">
                            <div className="glass-effect p-4 rounded-lg">
                                <p className="text-2xl font-bold text-white">$45M</p>
                                <p className="text-sm text-gray-400">Raised</p>
                            </div>
                            <div className="glass-effect p-4 rounded-lg">
                                <p className="text-2xl font-bold text-white">12</p>
                                <p className="text-sm text-gray-400">Active Bonds</p>
                            </div>
                             <div className="glass-effect p-4 rounded-lg">
                                <p className="text-2xl font-bold text-white">5.8%</p>
                                <p className="text-sm text-gray-400">Avg APY</p>
                            </div>
                        </div>

                        <h4 className="text-xl font-semibold text-white mb-6">Available Bond NFTs</h4>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {exampleBonds.map((bond) =>
              <div key={bond.name} className="bg-white/5 p-5 rounded-lg border border-white/10 hover:border-cyan-400/50 transition-colors">
                                    <h5 className="font-bold text-white">{bond.name}</h5>
                                    <p className="text-green-400 font-semibold">{bond.apy}</p>
                                    <p className="text-sm text-gray-400 mt-1">{bond.value}</p>
                                    <p className="text-xs text-cyan-300 mt-2">{bond.type}</p>
                                </div>
              )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>
  );
}
