
import React, { useState, useEffect, useCallback } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Bond } from "@/api/entities";
import { User } from "@/api/entities";
import { UserPurchase } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from "@/utils";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Pencil,
  Save,
  X,
  Globe,
  Building,
  Zap,
  GraduationCap,
  Heart,
  Home,
  Truck,
  Hash,
  Copy,
  Shield,
  FileText,
  ExternalLink,
  DollarSign,
  TrendingUp,
  Users,
  ArrowLeft,
  BadgeCheck,
  BarChart2,
  Calendar,
  Landmark,
  AlertTriangle,
  Percent,
  MapPin,
  Download,
  BookOpen } from
"lucide-react";
import { format } from "date-fns";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import BondPurchaseModal from "@/components/BondPurchaseModal";
import YieldCalculator from "@/components/marketplace/YieldCalculator";
import { generateBondCertificate } from "@/api/functions";
import { getEtherscanData } from "@/api/functions";
import { toast } from "sonner";

export default function BondDetails() {
  const location = useLocation();
  const navigate = useNavigate();
  const [bond, setBond] = useState(null);
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isOwner, setIsOwner] = useState(false);
  const [editedBond, setEditedBond] = useState(null);
  const [isGeneratingCert, setIsGeneratingCert] = useState(false);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [selectedBondForPurchase, setSelectedBondForPurchase] = useState(null);
  const [userHasPurchased, setUserHasPurchased] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);

  const getBondId = useCallback(() => {
    const params = new URLSearchParams(location.search);
    return params.get("id");
  }, [location.search]);

  const loadData = useCallback(async (bondId) => {
    setIsLoading(true);
    try {
      const [bondData, userData] = await Promise.all([
      Bond.get(bondId),
      User.me().catch(() => null)]
      );
      setBond(bondData);
      setEditedBond(bondData);
      setUser(userData);

      // Check if user has purchased this bond
      if (userData && bondData) {
        const purchases = await UserPurchase.filter({
          user_id: userData.id,
          bond_id: bondData.id
        }, null, 1); // Limit to 1, we just need to know if any exist
        setUserHasPurchased(purchases.length > 0);
      }
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const bondId = getBondId();
    if (bondId) {
      loadData(bondId);
    } else {
      setIsLoading(false);
    }
  }, [getBondId, loadData]);

  useEffect(() => {
    if (bond && user) {
      setIsOwner(bond.created_by === user.email);
    } else {
      setIsOwner(false);
    }
  }, [bond, user]);

  const handleEditToggle = () => {
    setIsEditing(!isEditing);
    if (isEditing) {// If was editing, now canceling
      setEditedBond(bond); // Revert changes
    }
  };

  const handleInputChange = (field, value) => {
    setEditedBond((prev) => ({ ...prev, [field]: value }));
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    const { id, ...dataToUpdate } = editedBond;
    // ensure numbers are numbers
    dataToUpdate.face_value = parseFloat(dataToUpdate.face_value);
    dataToUpdate.current_price = parseFloat(dataToUpdate.current_price);
    dataToUpdate.apy = parseFloat(dataToUpdate.apy);

    // Some fields like 'municipality' might need specific handling if 'issuing_municipality' is the primary editable field
    if (dataToUpdate.issuing_municipality !== undefined) {
      dataToUpdate.municipality = dataToUpdate.issuing_municipality;
    }

    try {
      await Bond.update(id, dataToUpdate);
      setBond(editedBond); // Update the displayed bond with edited data
      toast.success("Bond updated successfully!");
    } catch (error) {
      console.error("Error updating bond:", error);
      toast.error("Failed to update bond. Please try again.");
    } finally {
      setIsEditing(false);
    }
  };

  const handlePurchase = (bond) => {
    setSelectedBondForPurchase(bond);
    setShowPurchaseModal(true);
  };

  const handlePurchaseComplete = (bond, mintedData) => {
    setShowPurchaseModal(false);
    setUserHasPurchased(true); // Mark that the user has now purchased this bond
    toast.success(`Successfully purchased ${bond.bond_name}!`);
    console.log("Minted Data:", mintedData);
    // Optionally, refresh bond data here if needed
  };

  const handleDownloadCertificate = async () => {
    if (!bond) return;

    setIsGeneratingCert(true);
    toast.info("Generating your bond certificate...");

    try {
      const response = await generateBondCertificate({ bondId: bond.id });

      if (response.status === 200) {
        const blob = await response.data; // Assuming response.data is the blob
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Gazillion_Bond_Certificate_${bond.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        toast.success("Certificate downloaded successfully!");
      } else {
        toast.error("Failed to generate certificate. Please try again.");
      }
    } catch (error) {
      console.error("Certificate generation failed:", error);
      toast.error("An error occurred while generating the certificate.");
    } finally {
      setIsGeneratingCert(false);
    }
  };

  const handleVerifyOnChain = async () => {
    if (!user || !userHasPurchased || !bond) return;

    setIsVerifying(true);
    toast.info("Verifying purchase on the blockchain...");

    try {
      const purchases = await UserPurchase.filter({ user_id: user.id, bond_id: bond.id }, '-purchase_timestamp', 1);
      if (purchases.length === 0) {
        throw new Error("No purchase record found for this user and bond.");
      }
      const purchase = purchases[0];

      if (!purchase.transaction_hash) {
        throw new Error("Transaction hash not found in purchase record.");
      }

      const response = await getEtherscanData({
        module: 'proxy',
        action: 'eth_getTransactionByHash',
        txhash: purchase.transaction_hash
      });

      if (response.data?.result) {
        const tx = response.data.result;
        toast.success("Verification Successful!", {
          description: `Transaction found in block #${parseInt(tx.blockNumber, 16)}.`
        });
      } else {
        throw new Error(response.data?.message || "Could not retrieve transaction details.");
      }

    } catch (error) {
      console.error("On-chain verification failed:", error);
      toast.error("Verification Failed", {
        description: error.message || "Could not verify the transaction on Etherscan."
      });
    } finally {
      setIsVerifying(false);
    }
  };


  const categoryIcons = {
    infrastructure: Building, green_energy: Zap, education: GraduationCap,
    healthcare: Heart, housing: Home, transportation: Truck
  };

  const categoryColors = {
    infrastructure: 'from-blue-500 to-blue-700',
    green_energy: 'from-green-500 to-green-700',
    education: 'from-purple-500 to-purple-700',
    healthcare: 'from-red-500 to-red-700',
    housing: 'from-yellow-500 to-yellow-700',
    transportation: 'from-orange-500 to-orange-700',
    default: 'from-gray-500 to-gray-700'
  };

  // Determine CategoryIcon here based on bond value
  const CategoryIcon = bond ? categoryIcons[bond.category] || Globe : Globe;

  // New bond class configuration
  const bondClassConfig = {
    fixed: { label: 'Fixed APY Bond', color: 'text-blue-400', icon: DollarSign },
    variable: { label: 'Variable Revenue Bond', color: 'text-yellow-400', icon: TrendingUp },
    community: { label: 'Community Participation Bond', color: 'text-purple-400', icon: Users }
  };
  const classConfig = bond ? bondClassConfig[bond.bond_class] : null;

  const riskStyles = {
    low: "text-green-400 border-green-400/20",
    medium: "text-yellow-400 border-yellow-400/20",
    high: "text-red-400 border-red-400/20"
  };

  const DetailItem = ({ icon, label, value, children }) =>
  <div className="flex items-start gap-4">
      <div className="flex-shrink-0 w-8 h-8 rounded-lg primary-gradient flex items-center justify-center">
        {React.createElement(icon, { className: "w-5 h-5 text-white" })}
      </div>
      <div>
        <p className="text-sm text-gray-400">{label}</p>
        {value && <p className="text-lg font-semibold text-white">{value}</p>}
        {children}
      </div>
    </div>;


  if (isLoading) {
    return <div className="text-center text-white p-12">Loading Bond Details...</div>;
  }

  if (!bond) {
    return <div className="text-center text-white p-12">Bond not found.</div>;
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Back to Marketplace link - Removed as it was not in original and outline did not specify to add */}

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column - Main Details & Purchase */}
            <div className="lg:col-span-2 space-y-8">
              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader className="flex flex-row justify-between items-start pb-0">
                    <div className="flex flex-col sm:flex-row gap-6 mb-8 w-full">
                        <div className={`w-24 h-24 bg-gradient-to-br ${categoryColors[bond.category] || categoryColors.default} rounded-2xl flex items-center justify-center flex-shrink-0`}>
                            <CategoryIcon className="w-12 h-12 text-white" />
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between items-start w-full">
                                <div className="flex flex-col">
                                    <Badge className="bg-cyan-400/10 text-cyan-300 border-cyan-400/30 mb-2">
                                        {bond.category.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase())}
                                    </Badge>
                                    {bond.is_government_guaranteed &&
                          <Tooltip>
                                        <TooltipTrigger asChild>
                                            <Badge className="bg-green-500/20 text-green-300 border-green-500/40 flex items-center gap-1 cursor-help mt-1">
                                                <Shield className="w-3 h-3" /> Gov't Backed
                                            </Badge>
                                        </TooltipTrigger>
                                        <TooltipContent><p>This bond is guaranteed by the issuing municipality.</p></TooltipContent>
                                    </Tooltip>
                          }
                                </div>
                                {isOwner &&
                        <div className="flex gap-2">
                                        {!isEditing ?
                          <Button onClick={handleEditToggle} variant="outline" className="glass-effect text-white hover:bg-white/10">
                                                <Pencil className="w-4 h-4 mr-2" /> Edit
                                            </Button> :

                          <>
                                                <Button onClick={handleUpdate} className="primary-gradient text-white hover:opacity-90">
                                                    <Save className="w-4 h-4 mr-2" /> Save
                                                </Button>
                                                <Button onClick={handleEditToggle} variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                    <X className="w-5 h-5" />
                                                </Button>
                                            </>
                          }
                                    </div>
                        }
                            </div>
                            {!isEditing ?
                      <>
                                    <h1 className="text-3xl font-bold text-white mb-2">{bond.bond_name}</h1>
                                    <div className="flex items-center gap-2 text-gray-400">
                                        <MapPin className="w-4 h-4" />
                                        <span>{bond.issuing_municipality || bond.municipality}</span>
                                    </div>
                                </> :

                      <>
                                    <Label htmlFor="bond_name_edit" className="sr-only">Bond Name</Label>
                                    <Input id="bond_name_edit" value={editedBond.bond_name} onChange={(e) => handleInputChange('bond_name', e.target.value)} className="text-3xl font-bold glass-effect border-white/20 bg-transparent text-white mb-2" />
                                    <Label htmlFor="municipality_edit" className="sr-only">Municipality</Label>
                                    <Input id="municipality_edit" value={editedBond.issuing_municipality || editedBond.municipality} onChange={(e) => handleInputChange('issuing_municipality', e.target.value)} className="text-lg glass-effect border-white/20 bg-transparent text-gray-400" />
                                </>
                      }
                        </div>
                    </div>
                </CardHeader>
                <CardContent className="p-8 pt-0">
                  {/* Key Stats */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 py-6 border-y border-white/10 my-6">
                    <DetailItem icon={DollarSign} label="Face Value" value={`$${bond.face_value?.toLocaleString()}`} />
                    <DetailItem icon={TrendingUp} label="Current Price" value={`$${bond.current_price?.toLocaleString()}`} />
                    <DetailItem icon={BarChart2} label={`${bond.bond_class === 'fixed' ? 'Fixed' : 'Est.'} APY`} value={`${bond.apy}%`} />
                    <DetailItem icon={Calendar} label="Maturity Date" value={format(new Date(bond.maturity_date), "MMMM d, yyyy")} />
                    <DetailItem icon={AlertTriangle} label="Risk Level">
                      <Badge variant="outline" className={`capitalize ${riskStyles[bond.risk_level] || riskStyles.medium}`}>
                        {bond.risk_level}
                      </Badge>
                    </DetailItem>
                    <DetailItem icon={Landmark} label="Category">
                      <Badge variant="secondary" className="capitalize text-sm">{bond.category?.replace(/_/g, ' ')}</Badge>
                    </DetailItem>
                    {bond.royalty_percentage > 0 &&
                    <DetailItem icon={Percent} label="Issuer Royalty" value={`${bond.royalty_percentage}%`} />
                    }
                  </div>
                  
                  {/* Description */}
                  <div className="mt-8">
                    <h2 className="text-xl font-semibold text-white mb-3">Project Description</h2>
                    {!isEditing ?
                    <p className="text-gray-300 leading-relaxed">{bond.description}</p> :

                    <Textarea value={editedBond.description} onChange={(e) => handleInputChange('description', e.target.value)} className="glass-effect border-white/20 bg-transparent text-white min-h-[120px]" />
                    }
                  </div>

                   {/* Action Buttons */}
                  <div className="mt-8 flex flex-wrap gap-4">
                    <Button
                      onClick={() => handlePurchase(bond)}
                      className="primary-gradient hover:opacity-90 text-white font-semibold rounded-full px-8 py-6 text-lg">

                      Buy Bond NFT
                    </Button>
                    {userHasPurchased &&
                    <>
                      <Button
                        onClick={handleDownloadCertificate}
                        variant="outline" className="bg-background text-slate-950 px-8 py-6 text-lg font-medium justify-center whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10 rounded-full flex items-center gap-2"
                        disabled={isGeneratingCert}>

                        <Download className={`w-5 h-5 ${isGeneratingCert ? 'animate-spin' : ''}`} />
                        {isGeneratingCert ? 'Generating...' : 'Certificate'}
                      </Button>
                      <Button
                        onClick={handleVerifyOnChain}
                        variant="outline"
                        className="bg-background text-slate-950 px-8 py-6 text-lg font-medium justify-center whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10 rounded-full flex items-center gap-2"
                        disabled={isVerifying}>
                        <BadgeCheck className={`w-5 h-5 ${isVerifying ? 'animate-spin' : ''}`} />
                        {isVerifying ? 'Verifying...' : 'Verify on Blockchain'}
                      </Button>
                    </>
                    }
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon" className="bg-background text-slate-950 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground border-white/20 hover:bg-white/10 rounded-full w-12 h-12"

                          onClick={() => bond.nft_token_id && window.open(`https://etherscan.io/token/${bond.nft_token_id}`, '_blank')}
                          disabled={!bond.nft_token_id}>

                          <ExternalLink className="w-5 h-5" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>View on Etherscan</p></TooltipContent>
                    </Tooltip>
                  </div>
                </CardContent>
              </Card>

              {/* Details & Legal Info Card (adapted from original additional sections) */}
              <Card className="glass-effect border-white/10 bg-transparent p-6 space-y-6">
                <CardTitle className="text-2xl text-white">Additional Bond Details</CardTitle>
                {/* Government Guarantee Section */}
                {bond.is_government_guaranteed &&
                <div className="glass-effect p-6 rounded-xl border border-green-400/20 bg-green-400/5">
                    <div className="flex items-center gap-3 mb-4">
                      <Shield className="w-6 h-6 text-green-400" />
                      <h3 className="text-green-300 font-semibold text-lg">Government Guarantee</h3>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-gray-400 text-sm mb-1">Guarantee Type</p>
                        <p className="text-white font-semibold capitalize">
                          {bond.guarantee_type?.replace('_', ' ')}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm mb-1">Issuing Authority</p>
                        <p className="text-white font-semibold">{bond.issuing_municipality}</p>
                      </div>
                    </div>

                    {/* Government Seal */}
                    {bond.government_seal_url &&
                  <div className="mb-4">
                        <p className="text-gray-400 text-sm mb-2">Official Seal</p>
                        <img
                      src={bond.government_seal_url}
                      alt="Government Seal"
                      className="h-16 w-16 object-contain" />

                      </div>
                  }

                    {/* Legal Documents */}
                    <div className="space-y-3">
                      <h4 className="text-white font-medium">Legal Documents</h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        {bond.mou_document_url &&
                      <a
                        href={bond.mou_document_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 glass-effect p-4 rounded-lg hover:bg-white/5 transition-all duration-300">

                            <FileText className="w-5 h-5 text-cyan-400" />
                            <div>
                              <p className="text-white font-medium">MOU Agreement</p>
                              <p className="text-gray-400 text-sm">View signed memorandum</p>
                            </div>
                            <ExternalLink className="w-4 h-4 text-gray-400 ml-auto" />
                          </a>
                      }
                        
                        {bond.legal_contract_url &&
                      <a
                        href={bond.legal_contract_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 glass-effect p-4 rounded-lg hover:bg-white/5 transition-all duration-300">

                            <FileText className="w-5 h-5 text-amber-400" />
                            <div>
                              <p className="text-white font-medium">Legal Contract</p>
                              <p className="text-gray-400 text-sm">View full agreement</p>
                            </div>
                            <ExternalLink className="w-4 h-4 text-gray-400 ml-auto" />
                          </a>
                      }
                      </div>
                    </div>
                  </div>
                }

                {/* Variable Revenue Details */}
                {bond.bond_class === 'variable' &&
                <div className="glass-effect p-6 rounded-xl border border-yellow-400/20 bg-yellow-400/5">
                    <div className="flex items-center gap-3 mb-4">
                      <TrendingUp className="w-6 h-6 text-yellow-400" />
                      <h3 className="text-yellow-300 font-semibold text-lg">Variable Revenue Details</h3>
                    </div>
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div className="glass-effect p-4 rounded-lg">
                        <p className="text-gray-400 mb-1">Estimated APY Range</p>
                        <p className="text-white font-semibold">{bond.apy_range || 'N/A'}</p>
                      </div>
                       <div className="glass-effect p-4 rounded-lg">
                        <p className="text-gray-400 mb-1">SPV Name</p>
                        <p className="text-white font-semibold">{bond.spv_name || 'N/A'}</p>
                      </div>
                      <div className="glass-effect p-4 rounded-lg col-span-2">
                        <p className="text-gray-400 mb-1">Revenue Source</p>
                        <p className="text-white font-semibold">{bond.revenue_source || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                }
                
                {/* Community Participation Details */}
                {bond.bond_class === 'community' &&
                <div className="glass-effect p-6 rounded-xl border border-purple-400/20 bg-purple-400/5">
                    <div className="flex items-center gap-3 mb-4">
                      <Users className="w-6 h-6 text-purple-400" />
                      <h3 className="text-purple-300 font-semibold text-lg">Community Participation Details</h3>
                    </div>
                    <div className="space-y-4 text-sm">
                      <div className="glass-effect p-4 rounded-lg">
                        <p className="text-gray-400 mb-1">Rewards</p>
                        <p className="text-white font-semibold">{bond.reward_description || 'N/A'}</p>
                      </div>
                      {bond.milestones &&
                    <div className="glass-effect p-4 rounded-lg">
                          <p className="text-gray-400 mb-1">Project Milestones</p>
                          <pre className="text-white font-mono text-xs whitespace-pre-wrap bg-black/20 p-2 rounded-md">
                            {(() => {
                          try {
                            return JSON.stringify(JSON.parse(bond.milestones), null, 2);
                          } catch (e) {
                            return bond.milestones; // If not valid JSON, display as-is
                          }
                        })()}
                          </pre>
                        </div>
                    }
                    </div>
                  </div>
                }

                {/* NFT Token Information */}
                <div className="glass-effect p-4 rounded-lg border border-cyan-400/20 bg-cyan-400/5">
                  <h4 className="text-cyan-300 font-semibold mb-2 flex items-center">
                    <Hash className="w-4 h-4 mr-2" />
                    NFT Token Information
                  </h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <p className="text-gray-300 text-sm font-mono break-all">{bond.nft_token_id || 'N/A'}</p>
                      {bond.nft_token_id &&
                      <Button variant="ghost" size="icon" onClick={() => navigator.clipboard.writeText(bond.nft_token_id)}>
                          <Copy className="w-4 h-4 text-gray-400" />
                        </Button>
                      }
                    </div>
                    {bond.is_government_guaranteed &&
                    <div className="text-xs text-green-400 mt-2">
                        ✅ Government guarantee metadata included in smart contract
                      </div>
                    }
                  </div>
                </div>
              </Card>

            </div>

            {/* Right Column - Yield Calculator & Related */}
            <div className="space-y-8">
              <YieldCalculator bond={bond} />
              
              <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <CardTitle className="text-white text-xl flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-cyan-400" />
                    Learn More
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                   <Link to={createPageUrl("EducationHub")} className="block">
                    <Button variant="ghost" className="w-full justify-start text-white hover:bg-white/10">What are NFT Bonds?</Button>
                  </Link>
                  <Link to={createPageUrl("riskdisclosure")} className="block">
                     <Button variant="ghost" className="w-full justify-start text-white hover:bg-white/10">Understand the Risks</Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {selectedBondForPurchase &&
        <BondPurchaseModal
          isOpen={showPurchaseModal}
          onClose={() => setShowPurchaseModal(false)}
          bond={selectedBondForPurchase}
          onPurchaseComplete={handlePurchaseComplete} />

        }
      </div>
    </TooltipProvider>);

}
