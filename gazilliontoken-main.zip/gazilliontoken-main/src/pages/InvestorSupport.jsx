
import React, { useState, useEffect, useRef, useCallback } from "react";
import { User } from "@/api/entities";
import { agentSDK } from "@/agents";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Send, Bot, Loader2, AlertTriangle, RefreshCw } from "lucide-react";
import MessageBubble from "@/components/agent/MessageBubble";

export default function InvestorSupport() {
  const [user, setUser] = useState(null);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const initializeSupport = useCallback(async () => {
    setIsInitializing(true);
    setError(null);
    
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Try to create a new conversation
      const conv = await agentSDK.createConversation({
        agent_name: "GazillionInvestorAssistant",
        metadata: { 
          name: `Investment Support for ${currentUser.email}`,
          created_at: new Date().toISOString()
        }
      });
      
      setConversation(conv);
      setMessages(conv.messages || []);
      
      // Add a welcome message if no existing messages
      if (!conv.messages || conv.messages.length === 0) {
        setMessages([{
          id: 'welcome',
          role: 'assistant',
          content: `Hello ${currentUser.full_name || currentUser.email}! 👋\n\nI'm your Gazillion Investment Assistant. I can help you with:\n\n• Information about available municipal bonds\n• Understanding APY calculations and risks\n• Government guarantees and bond security\n• General investment guidance\n\nWhat would you like to know about today?`,
          created_at: new Date().toISOString()
        }]);
      }
      
    } catch (error) {
      console.error("Failed to initialize support:", error);
      
      if (error.message?.includes("not authenticated")) {
        try {
          await User.login();
          // Retry after login
          setTimeout(() => initializeSupport(), 1000);
          return;
        } catch (loginError) {
          setError("Please log in to access investor support.");
        }
      } else {
        setError(`Connection failed: ${error.message}`);
      }
    } finally {
      setIsInitializing(false);
    }
  }, []); // Empty dependency array ensures this runs only once

  useEffect(() => {
    initializeSupport();
  }, [initializeSupport]); // initializeSupport is now a stable function thanks to useCallback

  useEffect(() => {
    if (conversation) {
      const unsubscribe = agentSDK.subscribeToConversation(conversation.id, (data) => {
        setMessages(data.messages || []);
        setIsSending(false);
      });
      return () => unsubscribe();
    }
  }, [conversation]);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || isSending) return;

    const userMessage = {
      id: Date.now().toString(),
      role: "user",
      content: newMessage.trim(),
      created_at: new Date().toISOString()
    };

    // Add user message immediately
    setMessages(prev => [...prev, userMessage]);
    setIsSending(true);
    setError(null);
    const messageContent = newMessage;
    setNewMessage("");

    try {
      if (conversation) {
        await agentSDK.addMessage(conversation, { 
          role: "user", 
          content: messageContent 
        });
      } else {
        // Fallback: simulate a response if no conversation
        setTimeout(() => {
          const botResponse = {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: `I understand you're asking about: "${messageContent}"\n\nI'm currently having trouble connecting to the full agent system, but here are some quick answers:\n\n• **Available Bonds**: Check the Bond Marketplace for current offerings\n• **Government Guarantees**: Look for bonds with the green "Gov't Guaranteed" badge\n• **APY Information**: Each bond shows its annual percentage yield prominently\n• **Risk Levels**: Bonds are classified as Low, Medium, or High risk\n\nFor detailed information, please visit the Bond Marketplace or try refreshing this chat.`,
            created_at: new Date().toISOString()
          };
          setMessages(prev => [...prev, botResponse]);
          setIsSending(false);
        }, 2000);
      }
    } catch (error) {
      console.error("Failed to send message:", error);
      setError(`Message failed: ${error.message}`);
      
      // Add fallback response
      const fallbackResponse = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `I apologize, but I'm having trouble processing your message right now. However, I can provide some general guidance:\n\n**For Bond Information**: Visit our Bond Marketplace to see all available municipal bonds with detailed information about APY, risk levels, and government guarantees.\n\n**For Technical Support**: Please try refreshing the page or contact our support team.\n\n**Quick Answers**:\n• Government-guaranteed bonds have a green shield badge\n• APY ranges from 4-9% depending on risk level\n• All bonds are backed by municipal authorities\n\nIs there something specific I can help clarify?`,
        created_at: new Date().toISOString()
      };
      
      setTimeout(() => {
        setMessages(prev => [...prev, fallbackResponse]);
        setIsSending(false);
      }, 1500);
    }
  };

  const quickActions = [
    "Show me all available bonds",
    "What bonds have government guarantees?", 
    "Help me understand APY calculations",
    "Explain bond risk levels"
  ];

  const handleRetry = () => {
    setError(null);
    initializeSupport();
  };

  const ChatInterface = () => {
    if (isInitializing) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <Loader2 className="w-12 h-12 text-cyan-400 mx-auto mb-4 animate-spin" />
          <p className="text-gray-400">Connecting to Assistant...</p>
        </div>
      );
    }
    
    return (
      <div className="flex-1 flex flex-col min-h-0">
        {error && (
          <div className="p-4 mb-4 bg-red-900/20 border border-red-500/30 rounded-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <AlertTriangle className="w-5 h-5 text-red-400 mr-2" />
                <span className="text-red-300 text-sm">{error}</span>
              </div>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={handleRetry}
                className="text-red-300 border-red-500/30 hover:bg-red-900/30"
              >
                <RefreshCw className="w-4 h-4 mr-1" />
                Retry
              </Button>
            </div>
          </div>
        )}
        
        <div className="flex-1 overflow-y-auto pr-4 -mr-4 space-y-4">
          {messages.map((message) => <MessageBubble key={message.id} message={message} />)}
          
          {isSending && (
            <div className="flex gap-3 my-4 justify-start">
               <div className="h-8 w-8 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot className="w-5 h-5 text-cyan-400" />
               </div>
               <div className="max-w-[85%] flex flex-col items-start">
                  <div className="rounded-2xl px-4 py-2.5 bg-slate-700/50 border border-slate-600 text-gray-200 rounded-bl-lg">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                        <span className="text-sm">Thinking...</span>
                      </div>
                  </div>
               </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        
        <form onSubmit={sendMessage} className="flex gap-2 pt-4 border-t border-white/10">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Ask about bonds, investments, or yields..."
            className="flex-1 glass-effect border-white/20 bg-transparent text-white"
            disabled={isSending}
          />
          <Button 
            type="submit" 
            disabled={isSending || !newMessage.trim()} 
            className="primary-gradient text-white"
          >
            {isSending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      </div>
    );
  };

  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-block glass-effect px-6 py-3 rounded-full mb-6">
            <span className="brand-accent text-sm font-medium">AI Investment Assistant</span>
          </div>
          <h1 className="text-4xl font-bold text-white mb-6">
            <span className="text-gradient">Investor Support</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Get assistance with your municipal bond NFT investments
          </p>
        </div>

        {/* Chat Interface */}
        <Card className="glass-effect border-white/10 bg-transparent h-[60vh] flex flex-col">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Bot className="w-5 h-5 mr-2 text-cyan-400" />
              Gazillion Investor Assistant
              <Badge className={`ml-auto ${error ? 'bg-red-600' : 'bg-green-600'} text-white`}>
                {error ? 'Limited Mode' : 'Online'}
              </Badge>
            </CardTitle>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col min-h-0">
             <ChatInterface />
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-white mb-4">Quick Questions</h3>
          <div className="grid md:grid-cols-2 gap-3">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                variant="outline"
                onClick={() => setNewMessage(action)}
                className="glass-effect text-white hover:bg-white/10 justify-start"
                disabled={isSending}
              >
                {action}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
