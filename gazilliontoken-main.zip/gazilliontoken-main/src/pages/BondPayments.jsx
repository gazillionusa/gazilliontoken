import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, HandCoins, ExternalLink } from 'lucide-react';
import { format } from 'date-fns';

export default function BondPayments() {
    const { data: payments, isLoading } = useQuery({
        queryKey: ['paymentTransactions'],
        queryFn: () => base44.entities.PaymentTransaction.list('-payment_date')
    });
    
    return (
        <Card className="bg-gray-800/50 border-teal-500/20">
            <CardHeader>
                <CardTitle className="text-2xl text-gradient">Bond Payments History</CardTitle>
                <p className="text-gray-400">Real-time record of coupon payments and principal redemptions from escrow.</p>
            </CardHeader>
            <CardContent>
                {isLoading ? (
                    <div className="flex justify-center items-center h-64">
                        <Loader2 className="w-8 h-8 animate-spin text-teal-400" />
                    </div>
                ) : (
                    <Table>
                        <TableHeader>
                            <TableRow className="border-gray-700">
                                <TableHead className="text-white">Bond ID</TableHead>
                                <TableHead className="text-white">Payment Type</TableHead>
                                <TableHead className="text-white text-right">Amount</TableHead>
                                <TableHead className="text-white">Payment Date</TableHead>
                                <TableHead className="text-white">Status</TableHead>
                                <TableHead className="text-white">Transaction</TableHead>
                                <TableHead className="text-white text-center">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {payments?.map(p => (
                                <TableRow key={p.id} className="border-gray-800">
                                    <TableCell className="font-medium text-teal-300">{p.bond_id}</TableCell>
                                    <TableCell>
                                        <Badge variant="outline" className={p.payment_type === 'coupon' ? 'border-yellow-400 text-yellow-400' : 'border-green-400 text-green-400'}>
                                            {p.payment_type}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-right">${p.amount.toLocaleString()}</TableCell>
                                    <TableCell>{format(new Date(p.payment_date), 'PPpp')}</TableCell>
                                    <TableCell>
                                        <Badge className={p.status === 'completed' ? 'bg-green-600' : 'bg-yellow-600'}>{p.status}</Badge>
                                    </TableCell>
                                    <TableCell>
                                        <a href="#" className="flex items-center text-blue-400 hover:underline">
                                            {p.tx_hash.substring(0, 6)}...{p.tx_hash.substring(p.tx_hash.length - 4)}
                                            <ExternalLink className="w-3 h-3 ml-1" />
                                        </a>
                                    </TableCell>
                                    <TableCell className="text-center">
                                        <Button variant="ghost" size="sm">
                                            <HandCoins className="w-4 h-4 mr-2" />
                                            Withdraw
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                )}
            </CardContent>
        </Card>
    );
}