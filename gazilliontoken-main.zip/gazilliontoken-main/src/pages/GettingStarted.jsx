import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookOpen, FileDown, Rocket } from "lucide-react";
import MetaTags from "@/components/seo/MetaTags";

const guideSteps = [
{
  title: "Step 1: Create Your Account",
  image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/f59984dff_step_01.png",
  points: [
  "Click Sign Up on the top-right of the homepage.",
  "Choose to sign up with your Email/Password or directly with a crypto wallet.",
  "Agree to the Terms of Service and Privacy Policy.",
  "Confirm your email address by clicking the link sent to your inbox."],

  tip: "Need help? The Help Center link is always available in the footer."
},
{
  title: "Step 2: Verify Your Identity (KYC)",
  image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/5066cd29e_step_02.png",
  points: [
  "Start the verification process through our secure partner (e.g., SumSub/Alloy).",
  "Upload a clear photo of your government-issued ID (e.g., Driver's License, Passport).",
  "Take a live selfie to match your ID photo.",
  "Confirm your personal details are correct."],

  tip: "Verification is a crucial security step and usually takes only a few minutes to complete."
},
{
  title: "Step 3: Connect Wallet or Add Payment",
  image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/b01e9f7f9_step_03.png",
  points: [
  "Connect a non-custodial wallet like MetaMask, WalletConnect, or Coinbase Wallet.",
  "Alternatively, use our secure Custodial Wallet, which is great for beginners.",
  "Fund your account with crypto (USDC, ETH) or link a bank account for ACH transfers.",
  "Set your payout preference for when you receive bond yields (USDC or Bank)."],

  tip: "For enhanced security, enable Two-Factor Authentication (2FA) in your account settings."
},
{
  title: "Step 4: Explore the Marketplace",
  image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/577755d07_step_04.png",
  points: [
  "Use the filters to sort bonds by APY, maturity date, risk level, and category.",
  "Click on any bond to see its detailed information page.",
  "Look for the verification badge to ensure the issuer is legitimate.",
  "Review the on-chain contract details via the Etherscan link for full transparency."],

  tip: "When you're ready, press the 'Buy Bond NFT' button to start the purchase process."
},
{
  title: "Step 5: Review & Purchase",
  image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/2771db7ba_step_05.png",
  points: [
  "Review all critical details: Issuer, Yield, Maturity, and Face Value.",
  "See a preview of your unique NFT bond certificate.",
  "Access and review all associated audit, legal, and risk disclosure documents (PDFs).",
  "Confirm the purchase amount and review the estimated network (gas) fees."],

  tip: "Confirm the transaction in your wallet or via our custodial checkout to complete the purchase."
}];


export default function GettingStartedPage() {
  return (
    <>
      <MetaTags
        title="Getting Started | Gazillion"
        description="Your step-by-step guide to creating an account, verifying your identity, and purchasing your first NFT municipal bond on Gazillion."
        keywords="how to buy bonds, getting started, user guide, KYC, connect wallet, NFT bonds" />

      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <Rocket className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Getting Started with <span className="text-gradient">Gazillion</span>
            </h1>
            <p className="text-lg text-gray-300 max-w-3xl mx-auto">
              Welcome! This guide will walk you through every step of your journey, from creating an account to becoming a municipal bond investor.
            </p>
          </div>

          {/* Guide Steps */}
          <div className="space-y-16">
            {guideSteps.map((step, index) =>
            <Card key={index} className="glass-effect border-white/10 bg-transparent overflow-hidden">
                <CardHeader>
                  <CardTitle className="text-3xl font-bold text-white mb-4">{step.title}</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-8 items-center">
                  <div className="space-y-4">
                    <ul className="space-y-3">
                      {step.points.map((point, pIndex) =>
                    <li key={pIndex} className="flex items-start">
                          <div className="w-6 h-6 rounded-full bg-cyan-400/20 text-cyan-300 flex items-center justify-center font-bold text-sm flex-shrink-0 mr-4 mt-1">
                            {pIndex + 1}
                          </div>
                          <span className="text-gray-300 text-lg">{point}</span>
                        </li>
                    )}
                    </ul>
                    {step.tip &&
                  <div className="bg-slate-800/50 p-4 rounded-lg border border-white/10 mt-6">
                        <p className="text-sm text-cyan-200"><span className="font-bold">Pro Tip:</span> {step.tip}</p>
                      </div>
                  }
                  </div>
                  <div>
                    <img
                    src={step.image}
                    alt={step.title}
                    className="rounded-lg shadow-2xl w-full border-2 border-white/10" />

                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Downloadable Guides */}
          <div className="mt-20 text-center">
            <div className="glass-effect p-10 rounded-2xl max-w-3xl mx-auto">
              <BookOpen className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-white mb-4">Download Full Guides</h2>
              <p className="text-gray-400 mb-8">
                For a complete overview and technical details, download our comprehensive user manuals.
              </p>
              <div className="flex flex-col sm:flex-row justify-center gap-4">
                <a href="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/72afc087c_GazillionUSA_Beginner_Guide.pdf" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="bg-background text-slate-950 px-6 py-3 text-base font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 w-full sm:w-auto border-white/20 hover:bg-white/10">
                    <FileDown className="w-4 h-4 mr-2" />
                    Beginner's Guide (PDF)
                  </Button>
                </a>
                <a href="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/16eebb7d7_GazillionUSA_User_Manual1.pdf" target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="bg-background text-slate-950 px-6 py-3 text-base font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 w-full sm:w-auto border-white/20 hover:bg-white/10">
                    <FileDown className="w-4 h-4 mr-2" />
                    Full User Manual (PDF)
                  </Button>
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </>);

}