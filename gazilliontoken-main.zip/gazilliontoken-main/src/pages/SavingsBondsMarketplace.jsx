import React, { useState, useEffect } from 'react';
import { SavingsBond } from '@/api/entities';
import { purchaseSavingsBond } from '@/api/functions';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, TrendingUp, Calendar, Shield, ShoppingCart, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function SavingsBondsMarketplace() {
  const [bondSeries, setBondSeries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isPurchasing, setIsPurchasing] = useState(null);

  useEffect(() => {
    fetchBondSeries();
  }, []);

  const fetchBondSeries = async () => {
    setIsLoading(true);
    try {
      const series = await SavingsBond.filter({ is_active: true });
      setBondSeries(series);
    } catch (error) {
      toast.error("Failed to load bond series.", { description: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePurchase = async (bondId) => {
    setIsPurchasing(bondId);
    try {
      await purchaseSavingsBond({ savingsBondId: bondId });
      toast.success("Purchase Successful!", {
        description: "Your new Savings Bond has been added to your portfolio.",
        action: {
          label: 'View Portfolio',
          onClick: () => window.location.href = createPageUrl('Dashboard')
        }
      });
    } catch (error) {
      toast.error("Purchase Failed", { description: error.message || "An unexpected error occurred." });
    } finally {
      setIsPurchasing(null);
    }
  };

  const denominationColors = {
    25: "border-blue-400/50 hover:border-blue-400",
    50: "border-green-400/50 hover:border-green-400",
    100: "border-amber-400/50 hover:border-amber-400"
  };

  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen"><Loader2 className="w-12 h-12 animate-spin text-cyan-400" /></div>;
  }

  return (
    <div className="min-h-screen px-6 py-12">
            <div className="max-w-6xl mx-auto">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-bold text-white mb-4">
                        Gazillion <span className="text-gradient">Savings Bond</span>
                    </h1>
                    <p className="text-gray-300 text-lg max-w-3xl mx-auto">
                        A secure way to save and earn fixed interest. Simple, reliable, and backed by the Gazillion ecosystem.
                    </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {bondSeries.map((bond) =>
          <Card key={bond.id} className={`glass-effect bg-transparent flex flex-col transition-all duration-300 ${denominationColors[bond.denomination]}`}>
                            <CardHeader>
                                <div className="flex justify-between items-start">
                                    <div>
                                        <CardTitle className="text-white text-2xl mb-1">{bond.name}</CardTitle>
                                        <p className="text-gray-400">Fixed-Rate Savings Bond</p>
                                    </div>
                                    <div className="text-4xl font-bold text-gradient">${bond.denomination}</div>
                                </div>
                            </CardHeader>
                            <CardContent className="flex-grow flex flex-col justify-between">
                                <div className="space-y-4 mb-6">
                                    <div className="flex items-center gap-4">
                                        <TrendingUp className="w-6 h-6 text-cyan-400" />
                                        <div>
                                            <p className="text-gray-400 text-sm">Interest Rate</p>
                                            <p className="text-white font-semibold">{bond.interest_rate}% APR</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <Calendar className="w-6 h-6 text-cyan-400" />
                                        <div>
                                            <p className="text-gray-400 text-sm">Maturity</p>
                                            <p className="text-white font-semibold">{bond.maturity_duration_days / 365} Year(s)</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <Shield className="w-6 h-6 text-cyan-400" />
                                        <div>
                                            <p className="text-gray-400 text-sm">Issuer</p>
                                            <p className="text-white font-semibold">{bond.issuer}</p>
                                        </div>
                                    </div>
                                </div>
                                <Button
                onClick={() => handlePurchase(bond.id)}
                disabled={isPurchasing === bond.id}
                className="w-full primary-gradient text-white font-bold text-lg rounded-full py-6">

                                    {isPurchasing === bond.id ?
                <Loader2 className="w-6 h-6 animate-spin" /> :

                <div className="flex items-center gap-2">
                                            <ShoppingCart className="w-5 h-5" />
                                            Buy Now for ${bond.denomination}
                                        </div>
                }
                                </Button>
                            </CardContent>
                        </Card>
          )}
                </div>

                 <div className="text-center mt-12 text-gray-500 text-sm glass-effect max-w-3xl mx-auto p-4 rounded-lg">
                    <p><strong>Disclaimer:</strong> Gazillion Savings Bonds are not FDIC insured and are not guaranteed by any government agency. They are backed by the issuer, Gazillion Bonds NFT LLC, and are subject to platform <Link to={createPageUrl("terms")} className="underline hover:text-gray-300">terms and conditions</Link>. Investment involves risk, including the potential loss of principal.</p>
                </div>
            </div>
        </div>);

}