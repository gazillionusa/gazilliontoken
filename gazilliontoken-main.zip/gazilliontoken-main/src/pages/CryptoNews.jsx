import React from 'react';
import YouTubeLiveStream from '@/components/crypto/YouTubeLiveStream';
import { TrendingUp, Newspaper, Video, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import MetaTags from "@/components/seo/MetaTags";

export default function CryptoNews() {
  const newsFeeds = [
    {
      title: "CoinDesk",
      description: "Leading source for cryptocurrency news and information",
      url: "https://www.coindesk.com",
      icon: Newspaper
    },
    {
      title: "CoinTelegraph",
      description: "Latest news in blockchain and cryptocurrency",
      url: "https://cointelegraph.com",
      icon: Newspaper
    },
    {
      title: "The Block",
      description: "Research and analysis on digital assets",
      url: "https://www.theblock.co",
      icon: TrendingUp
    }
  ];

  return (
    <>
      <MetaTags
        title="Crypto News & Live Streams | Gazillion"
        description="Stay updated with live cryptocurrency news, market analysis, and blockchain developments from Gazillon."
        keywords="crypto news, blockchain news, cryptocurrency live stream, market updates, gazillon"
      />
      
      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <Video className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Crypto <span className="text-gradient">News & Live Streams</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Stay informed with live cryptocurrency news, market analysis, and blockchain developments from Gazillon
            </p>
          </div>

          {/* Gazillon Channel CTA */}
          <Card className="glass-effect border-cyan-400/30 bg-cyan-400/5 mb-12">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-teal-600 flex items-center justify-center flex-shrink-0">
                    <Video className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white mb-1">Gazillon Official Channel</h2>
                    <p className="text-gray-300">Expert crypto insights, market analysis, and NFT bond updates</p>
                  </div>
                </div>
                <a 
                  href="https://www.youtube.com/@gazillon" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  <Button className="primary-gradient text-white font-semibold px-6 py-3 gap-2 whitespace-nowrap">
                    <ExternalLink className="w-5 h-5" />
                    Subscribe Now
                  </Button>
                </a>
              </div>
            </CardContent>
          </Card>

          {/* Live Stream Section */}
          <div className="mb-12">
            <YouTubeLiveStream />
          </div>

          {/* News Sources */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-white mb-6 text-center">
              Recommended News Sources
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {newsFeeds.map((feed, index) => {
                const Icon = feed.icon;
                return (
                  <Card key={index} className="glass-effect border-white/10 bg-transparent hover:bg-white/5 transition-all duration-300">
                    <CardHeader>
                      <div className="w-12 h-12 bg-cyan-500/20 rounded-lg flex items-center justify-center mb-4">
                        <Icon className="w-6 h-6 text-cyan-400" />
                      </div>
                      <CardTitle className="text-white text-xl">{feed.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-400 mb-4">{feed.description}</p>
                      <a
                        href={feed.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-cyan-400 hover:text-cyan-300 font-medium inline-flex items-center gap-2"
                      >
                        Visit Site
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}