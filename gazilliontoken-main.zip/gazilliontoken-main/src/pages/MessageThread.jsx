import React, { useState, useEffect, useRef } from 'react';
import { Message } from '@/api/entities';
import { MessageThread as ThreadEntity } from '@/api/entities';
import { User } from '@/api/entities';
import { sendMessage } from '@/api/functions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowLeft, 
  Send, 
  Shield, 
  Paperclip,
  Loader2,
  MessageSquare
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from "sonner";

export default function MessageThreadPage() {
    const [messages, setMessages] = useState([]);
    const [thread, setThread] = useState(null);
    const [currentUser, setCurrentUser] = useState(null);
    const [newMessage, setNewMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const [sending, setSending] = useState(false);
    const messagesEndRef = useRef(null);
    const [otherParticipant, setOtherParticipant] = useState(null);

    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const threadId = urlParams.get('id') || urlParams.get('thread');
        if (threadId) {
            loadThread(threadId);
        } else {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    const loadThread = async (threadId) => {
        try {
            const [user, threadData, threadMessages] = await Promise.all([
                User.me(),
                ThreadEntity.get(threadId),
                Message.filter({ thread_id: threadId }, 'created_date')
            ]);

            setCurrentUser(user);
            setThread(threadData);
            setMessages(threadMessages);

            // Find the other participant
            if (threadData.participants) {
                const otherUserId = threadData.participants.find(id => id !== user.id);
                if (otherUserId) {
                    const otherUserIndex = threadData.participants.indexOf(otherUserId);
                    setOtherParticipant({
                        id: otherUserId,
                        name: threadData.participant_names?.[otherUserIndex] || 'Unknown User',
                        avatar: threadData.participant_avatars?.[otherUserIndex]
                    });
                }
            }
            
        } catch (error) {
            console.error("Failed to load thread:", error);
            toast.error("Failed to load conversation.");
        } finally {
            setLoading(false);
        }
    };

    const handleSendMessage = async (e) => {
        e.preventDefault();
        if (!newMessage.trim() || !otherParticipant) return;

        setSending(true);
        try {
            const response = await sendMessage({
                recipientId: otherParticipant.id,
                content: newMessage.trim(),
                messageType: 'text'
            });

            if (response.data.success) {
                // Add the message optimistically to the UI
                const optimisticMessage = {
                    id: `temp-${Date.now()}`,
                    sender_id: currentUser.id,
                    sender_name: currentUser.full_name,
                    sender_avatar: currentUser.avatar_image_url,
                    content: newMessage.trim(),
                    message_type: 'text',
                    created_date: new Date().toISOString(),
                    is_admin_message: false
                };

                setMessages(prev => [...prev, optimisticMessage]);
                setNewMessage('');
                
                // Reload messages after a short delay to get the actual message
                setTimeout(() => {
                    const urlParams = new URLSearchParams(window.location.search);
                    const threadId = urlParams.get('id') || urlParams.get('thread');
                    if (threadId) {
                        Message.filter({ thread_id: threadId }, 'created_date')
                            .then(setMessages)
                            .catch(console.error);
                    }
                }, 1000);
            } else {
                toast.error("Failed to send message.");
            }

        } catch (error) {
            console.error("Failed to send message:", error);
            toast.error("Failed to send message. Please try again.");
        } finally {
            setSending(false);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    if (!thread) {
        return (
            <div className="min-h-screen px-6 py-12">
                <div className="max-w-4xl mx-auto text-center">
                    <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h2 className="text-2xl font-bold text-white mb-2">Conversation Not Found</h2>
                    <p className="text-gray-400 mb-6">This conversation may have been deleted or you don't have access to it.</p>
                    <Link to={createPageUrl("Messages")}>
                        <Button className="primary-gradient text-white">
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Back to Messages
                        </Button>
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen px-4 sm:px-6 py-12">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-4">
                        <Link to={createPageUrl("Messages")}>
                            <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                                <ArrowLeft className="w-4 h-4" />
                            </Button>
                        </Link>
                        
                        <div className="flex items-center gap-3">
                            <div className="relative">
                                <Avatar className="w-12 h-12 border-2 border-cyan-400/30">
                                    <AvatarImage src={otherParticipant?.avatar} />
                                    <AvatarFallback>
                                        {otherParticipant?.name?.charAt(0) || 'U'}
                                    </AvatarFallback>
                                </Avatar>
                                {thread.is_admin_thread && (
                                    <div className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-1">
                                        <Shield className="w-3 h-3 text-white" />
                                    </div>
                                )}
                            </div>
                            <div>
                                <h1 className="text-xl font-bold text-white">
                                    {thread.is_admin_thread ? 'Gazillion HQ' : otherParticipant?.name || 'Unknown User'}
                                </h1>
                                <p className="text-gray-400 text-sm">
                                    {thread.is_admin_thread ? 'Official Support' : 'Civic ZooKeeper'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Messages Container */}
                <Card className="glass-effect border-white/10 bg-transparent mb-6" style={{ height: '60vh' }}>
                    <div className="p-6 h-full flex flex-col">
                        {/* Messages List */}
                        <div className="flex-1 overflow-y-auto space-y-4 mb-6">
                            {messages.length === 0 ? (
                                <div className="text-center text-gray-400 py-8">
                                    <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
                                    <p>Start the conversation!</p>
                                </div>
                            ) : (
                                messages.map((message) => (
                                    <div
                                        key={message.id}
                                        className={`flex gap-3 ${
                                            message.sender_id === currentUser?.id ? 'justify-end' : 'justify-start'
                                        }`}
                                    >
                                        {message.sender_id !== currentUser?.id && (
                                            <Avatar className="w-8 h-8 border border-cyan-400/30 flex-shrink-0">
                                                <AvatarImage src={message.sender_avatar} />
                                                <AvatarFallback className="text-xs">
                                                    {message.sender_name?.charAt(0) || 'U'}
                                                </AvatarFallback>
                                            </Avatar>
                                        )}
                                        
                                        <div className={`max-w-[70%] ${message.sender_id === currentUser?.id ? 'order-first' : ''}`}>
                                            <div
                                                className={`rounded-2xl px-4 py-3 ${
                                                    message.sender_id === currentUser?.id
                                                        ? 'bg-cyan-600 text-white ml-auto'
                                                        : message.is_admin_message
                                                        ? 'bg-amber-500/20 border border-amber-500/30 text-white'
                                                        : 'glass-effect border-white/20 text-white'
                                                }`}
                                            >
                                                {message.is_admin_message && (
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <Shield className="w-4 h-4 text-amber-400" />
                                                        <Badge className="bg-amber-500 text-white text-xs">
                                                            {message.admin_badge_text || 'Gazillion HQ'}
                                                        </Badge>
                                                    </div>
                                                )}
                                                
                                                <p className="text-sm leading-relaxed">{message.content}</p>
                                                
                                                {message.attachment_url && (
                                                    <div className="mt-2">
                                                        <a 
                                                            href={message.attachment_url} 
                                                            target="_blank" 
                                                            rel="noopener noreferrer"
                                                            className="flex items-center gap-2 text-xs text-cyan-300 hover:text-cyan-200"
                                                        >
                                                            <Paperclip className="w-3 h-3" />
                                                            Attachment
                                                        </a>
                                                    </div>
                                                )}
                                            </div>
                                            
                                            <p className="text-xs text-gray-500 mt-1 px-2">
                                                {formatDistanceToNow(new Date(message.created_date), { addSuffix: true })}
                                            </p>
                                        </div>
                                        
                                        {message.sender_id === currentUser?.id && (
                                            <Avatar className="w-8 h-8 border border-cyan-400/30 flex-shrink-0">
                                                <AvatarImage src={message.sender_avatar} />
                                                <AvatarFallback className="text-xs">
                                                    {message.sender_name?.charAt(0) || 'M'}
                                                </AvatarFallback>
                                            </Avatar>
                                        )}
                                    </div>
                                ))
                            )}
                            <div ref={messagesEndRef} />
                        </div>
                        
                        {/* Message Input */}
                        <form onSubmit={handleSendMessage} className="flex gap-3">
                            <Input
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                placeholder="Type your message..."
                                className="flex-1 glass-effect border-white/20 bg-transparent text-white placeholder-gray-400"
                                disabled={sending}
                            />
                            <Button 
                                type="submit" 
                                disabled={sending || !newMessage.trim()}
                                className="primary-gradient text-white"
                            >
                                {sending ? (
                                    <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                    <Send className="w-4 h-4" />
                                )}
                            </Button>
                        </form>
                    </div>
                </Card>
            </div>
        </div>
    );
}