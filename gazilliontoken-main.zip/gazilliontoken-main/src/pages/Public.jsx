import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Loader2, Users, Building, Landmark } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function Public() {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const [user, setUser] = useState(null);
    const [checkingAuth, setCheckingAuth] = useState(true);

    useEffect(() => {
        const checkUser = async () => {
            try {
                const userData = await User.me();
                setUser(userData);
                // If user is logged in, redirect to appropriate page
                if (userData.partner_id) {
                    navigate(createPageUrl("PartnerPortal"));
                } else if (userData.username) {
                    navigate(createPageUrl(`UserProfile?username=${userData.username}`));
                } else {
                    navigate(createPageUrl("Onboarding"));
                }
            } catch (error) {
                // Not logged in, stay on public page
                setUser(null);
            } finally {
                setCheckingAuth(false);
            }
        };
        checkUser();
    }, [navigate]);

    const handleLogin = async () => {
        setLoading(true);
        try {
            await User.login();
            // After successful login, check user status again
            const userData = await User.me();
            if (userData.partner_id) {
                navigate(createPageUrl("PartnerPortal"));
            } else if (userData.username) {
                navigate(createPageUrl(`UserProfile?username=${userData.username}`));
            } else {
                navigate(createPageUrl("Onboarding"));
            }
        } catch (error) {
            console.error("Login failed:", error);
            toast.error("Login failed. Please try again.");
            setLoading(false);
        }
    };

    if (checkingAuth) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-teal-600 animate-spin" />
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
            <style>{`
                .teal-gradient {
                    background: linear-gradient(135deg, #008080, #00a0a0);
                }
                .teal-hover:hover {
                    background: linear-gradient(135deg, #006666, #008888);
                }
            `}</style>
            
            <div className="w-full max-w-md">
                {/* Header */}
                <div className="text-center mb-8">
                    <img
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/40b4f9049_ChatGPTImageSep22202503_43_36PM.png"
                        alt="Gazillion Logo"
                        className="w-20 h-20 mx-auto mb-4"
                    />
                    <h1 className="text-4xl font-bold text-slate-800">Sign in to Gazillion</h1>
                    <p className="text-slate-600 mt-2 text-lg">Connect with investors and the world around you.</p>
                </div>
                
                {/* Login Card */}
                <Card className="bg-white shadow-xl border-gray-200 rounded-lg">
                    <CardContent className="p-8 space-y-6">
                        {/* Primary Login Button */}
                        <Button 
                            onClick={handleLogin}
                            disabled={loading}
                            className="w-full teal-gradient teal-hover text-white font-semibold py-3 text-base rounded-md transition-all duration-200"
                        >
                            {loading ? (
                                <>
                                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                                    Connecting...
                                </>
                            ) : (
                                "Log In"
                            )}
                        </Button>

                        {/* Separator */}
                        <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <Separator className="w-full border-gray-300" />
                            </div>
                            <div className="relative flex justify-center text-xs uppercase">
                                <span className="bg-white px-2 text-gray-500 font-medium">Or continue with</span>
                            </div>
                        </div>

                        {/* Social Login Buttons */}
                        <div className="grid grid-cols-2 gap-4">
                            <Button 
                                variant="outline" 
                                className="w-full border-gray-300 hover:bg-gray-50" 
                                onClick={handleLogin}
                                disabled={loading}
                            >
                                <svg role="img" viewBox="0 0 24 24" className="mr-2 h-4 w-4">
                                    <path fill="currentColor" d="M12.48 10.92v3.28h7.84c-.24 1.84-.85 3.18-1.73 4.1-1.02 1.08-2.58 1.9-5.24 1.9-4.56 0-8.3-3.67-8.3-8.17s3.74-8.17 8.3-8.17c2.62 0 4.37 1.04 5.4 2.02l2.6-2.6C18.4 1.53 15.7.02 12.48.02c-6.6 0-11.95 5.36-11.95 11.98s5.35 11.98 11.95 11.98c3.22 0 6.02-1.08 8.03-3.04 2.05-2.01 2.6-5.02 2.6-7.32 0-.6-.05-1.18-.15-1.72h-10.4z"/>
                                </svg>
                                Google
                            </Button>
                            <Button 
                                variant="outline" 
                                className="w-full border-gray-300 hover:bg-gray-50" 
                                onClick={handleLogin}
                                disabled={loading}
                            >
                                <svg role="img" viewBox="0 0 24 24" className="mr-2 h-4 w-4">
                                    <path fill="currentColor" d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.174-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.097.118.112.221.085.341-.09.381-.293 1.199-.334 1.363-.053.225-.172.271-.402.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.357-.629-2.754-1.378l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z"/>
                                </svg>
                                Apple
                            </Button>
                        </div>
                        
                        {/* Forgot Password */}
                        <div className="text-center text-sm">
                            <a href="#" className="text-slate-600 hover:text-teal-600 font-medium underline">
                                Forgot password?
                            </a>
                        </div>
                    </CardContent>
                </Card>

                {/* Create Account Section */}
                <div className="text-center mt-8 space-y-4">
                    <p className="text-slate-600 text-sm">
                        Don't have an account? Signing in will create one automatically.
                    </p>
                    
                    {/* Profile Type Options */}
                    <div className="bg-white rounded-lg p-6 shadow-md">
                        <p className="text-slate-700 font-semibold mb-4">
                            Create a Page for a Person, Municipality, or Business
                        </p>
                        <div className="grid grid-cols-3 gap-3">
                            <div className="text-center">
                                <Users className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                                <p className="text-xs text-slate-600">Person</p>
                            </div>
                            <div className="text-center">
                                <Landmark className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                                <p className="text-xs text-slate-600">Municipality</p>
                            </div>
                            <div className="text-center">
                                <Building className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                                <p className="text-xs text-slate-600">Business</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Footer */}
                <div className="text-center mt-8 text-xs text-slate-500">
                    <p>&copy; {new Date().getFullYear()} Gazillion. All rights reserved.</p>
                    <div className="flex justify-center space-x-4 mt-2">
                        <Link to={createPageUrl("Terms")} className="hover:text-teal-600">Terms</Link>
                        <Link to={createPageUrl("Privacy")} className="hover:text-teal-600">Privacy</Link>
                        <Link to={createPageUrl("Contact")} className="hover:text-teal-600">Contact</Link>
                    </div>
                </div>
            </div>
        </div>
    );
}