
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { CivicPartner } from '@/api/entities';
import { CivicPartnerPortal } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from '@/components/ui/textarea';
import { UploadFile } from '@/api/integrations';
import { Loader2, ArrowRight, ArrowLeft, Briefcase, User as UserIcon, Landmark, CheckCircle, PartyPopper } from 'lucide-react';
import { toast } from 'sonner';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';

const StepIndicator = ({ currentStep, totalSteps }) => (
    <div className="flex items-center justify-center space-x-2 my-8">
        {Array.from({ length: totalSteps }).map((_, index) => (
            <div
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                    index < currentStep ? 'bg-cyan-400' : 'bg-gray-600'
                }`}
            />
        ))}
    </div>
);

export default function Onboarding() {
    const navigate = useNavigate();
    const [step, setStep] = useState(0); // 0: Role, 1: Details, 2: Complete
    const [selectedRole, setSelectedRole] = useState('');
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [user, setUser] = useState(null);

    const [formData, setFormData] = useState({
        // Common
        username: '',
        bio: '',
        location: '',
        avatar_image_url: '',
        // Partner specific
        organization_name: '',
        position_title: '',
        website: '',
        logo_url: ''
    });

    useEffect(() => {
        const checkUser = async () => {
            try {
                const userData = await User.me();
                setUser(userData);
                // If user is already set up, redirect
                if (userData.partner_id) navigate(createPageUrl("PartnerPortal"));
                else if (userData.username) navigate(createPageUrl(`UserProfile?username=${userData.username}`));
            } catch (error) {
                // Not logged in, stay on page to show login prompt
            } finally {
                setLoading(false);
            }
        };
        checkUser();
    }, [navigate]);

    const handleRoleSelect = async (role) => {
        setSelectedRole(role);
        try {
            const userData = await User.me();
            setUser(userData);
            setStep(1);
        } catch {
            // If not logged in, trigger login and redirect back here to continue.
            await User.loginWithRedirect(window.location.href);
        }
    };

    const handleInputChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleFileUpload = async (field, file) => {
        if (!file) return;
        setSubmitting(true);
        try {
            const { file_url } = await UploadFile({ file });
            handleInputChange(field, file_url);
            toast.success("Image uploaded successfully!");
        } catch (error) {
            toast.error("File upload failed.");
        } finally {
            setSubmitting(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!user) {
            toast.error("You must be logged in to complete onboarding.");
            return;
        }
        setSubmitting(true);
        try {
            if (selectedRole === 'user') {
                await User.update(user.id, {
                    username: formData.username,
                    is_public: true, // ALWAYS set to true for directory visibility
                    bio: formData.bio,
                    location: formData.location,
                    avatar_image_url: formData.avatar_image_url,
                });
                toast.success("Profile created! Welcome to the community.");
                setStep(2);
                setTimeout(() => navigate(createPageUrl(`UserProfile?username=${formData.username}`)), 3000);

            } else { // Business or Municipality
                const partnerType = selectedRole;
                const newPartner = await CivicPartner.create({
                    name: formData.organization_name,
                    partner_type: partnerType,
                    website: formData.website,
                    logo_url: formData.logo_url,
                    status: 'active'
                });

                const portalName = formData.organization_name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
                await CivicPartnerPortal.create({
                    partner_id: newPartner.id,
                    partner_name: portalName,
                    portal_url: `/partners/${portalName}`,
                    logo_url: formData.logo_url,
                    onboarding_completed: true,
                    is_public: true, // ALWAYS set to true for directory visibility
                    is_active: true,
                });

                await User.update(user.id, {
                    partner_id: newPartner.id,
                    partner_role: 'admin',
                    organization_name: formData.organization_name,
                    organization_type: partnerType,
                    position_title: formData.position_title,
                    is_public: true, // Ensure user is also public
                });

                toast.success("Partner portal created successfully!");
                setStep(2);
                setTimeout(() => navigate(createPageUrl("PartnerPortal")), 3000);
            }
        } catch (error) {
            console.error("Onboarding failed:", error);
            toast.error("An error occurred. Please ensure your username is unique.");
        } finally {
            setSubmitting(false);
        }
    };

    const RoleSelection = () => (
        <div className="text-center">
            <h2 className="text-3xl font-bold text-white mb-3">Join the Community</h2>
            <p className="text-gray-300 mb-8">First, choose your role. This will help us tailor your experience.</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card onClick={() => handleRoleSelect('user')} className="glass-effect p-6 text-center hover:border-cyan-400/50 cursor-pointer transition-all">
                    <UserIcon className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-white">Investor</h3>
                    <p className="text-gray-400 text-sm">Join as an individual to invest in bonds and earn rewards.</p>
                </Card>
                <Card onClick={() => handleRoleSelect('business')} className="glass-effect p-6 text-center hover:border-cyan-400/50 cursor-pointer transition-all">
                    <Briefcase className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-white">Zoo Vendor</h3>
                    <p className="text-gray-400 text-sm">Businesses can create campaigns and offer perks to investors.</p>
                </Card>
                <Card onClick={() => handleRoleSelect('municipality')} className="glass-effect p-6 text-center hover:border-cyan-400/50 cursor-pointer transition-all">
                    <Landmark className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-white">Civic Guardian</h3>
                    <p className="text-gray-400 text-sm">Municipalities can issue bonds and manage public projects.</p>
                </Card>
            </div>
             <div className="mt-12">
                <p className="text-gray-400">Already have an account? <Button variant="link" onClick={() => User.login()} className="text-cyan-400 p-0">Sign In</Button></p>
            </div>
        </div>
    );

    const DetailsForm = () => (
        <form onSubmit={handleSubmit}>
            <h2 className="text-3xl font-bold text-white mb-2">Create Your Public Profile</h2>
            <p className="text-gray-300 mb-6">This information will be visible to the community.</p>
            <div className="space-y-4">
                {selectedRole === 'user' ? (
                    <>
                        <div className="space-y-2">
                            <Label htmlFor="username" className="text-white">Public Username *</Label>
                            <Input id="username" placeholder="e.g., CivicInvestor25" value={formData.username} onChange={e => handleInputChange('username', e.target.value)} required className="glass-effect" />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="bio" className="text-white">Bio</Label>
                            <Textarea id="bio" placeholder="Tell us about yourself..." value={formData.bio} onChange={e => handleInputChange('bio', e.target.value)} className="glass-effect" />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="avatar" className="text-white">Avatar</Label>
                            <Input id="avatar" type="file" onChange={(e) => handleFileUpload('avatar_image_url', e.target.files[0])} className="glass-effect file:text-white" />
                        </div>
                    </>
                ) : (
                     <>
                        <div className="space-y-2">
                            <Label htmlFor="organization_name" className="text-white">Organization Name *</Label>
                            <Input id="organization_name" value={formData.organization_name} onChange={e => handleInputChange('organization_name', e.target.value)} required className="glass-effect" />
                        </div>
                         <div className="space-y-2">
                            <Label htmlFor="position_title" className="text-white">Your Title *</Label>
                            <Input id="position_title" value={formData.position_title} onChange={e => handleInputChange('position_title', e.target.value)} required className="glass-effect" />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="logo" className="text-white">Logo</Label>
                            <Input id="logo" type="file" onChange={(e) => handleFileUpload('logo_url', e.target.files[0])} className="glass-effect file:text-white" />
                        </div>
                    </>
                )}
            </div>
            <div className="mt-8 flex justify-between items-center">
                 <Button type="button" variant="outline" onClick={() => setStep(0)}>
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back
                </Button>
                <Button type="submit" disabled={submitting} className="primary-gradient text-white">
                    {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Complete Onboarding <ArrowRight className="w-4 h-4 ml-2" /></>}
                </Button>
            </div>
        </form>
    );

    const CompletionScreen = () => (
        <div className="text-center space-y-6">
            <PartyPopper className="w-20 h-20 text-green-400 mx-auto" />
            <h2 className="text-3xl font-bold text-white">Welcome Aboard!</h2>
            <p className="text-gray-300">Your profile is live. You will be redirected shortly...</p>
        </div>
    );

    const renderContent = () => {
        if (!user && step === 0) {
            return <RoleSelection />
        }
        
        switch (step) {
            case 0: return <RoleSelection />;
            case 1: return <DetailsForm />;
            case 2: return <CompletionScreen />;
            default: return <RoleSelection />;
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center px-6 py-12">
            <div className="max-w-3xl w-full">
                {loading ? (
                    <div className="flex justify-center items-center"><Loader2 className="w-12 h-12 text-cyan-400 animate-spin" /></div>
                ) : (
                    <Card className="glass-effect border-white/10 bg-transparent p-4 sm:p-8">
                        <CardContent className="p-0">
                            {step === 1 && <StepIndicator currentStep={2} totalSteps={3} />}
                            {renderContent()}
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
