import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  Building,
  TrendingUp,
  Users,
  CheckCircle,
  ArrowRight,
  Quote } from
'lucide-react';
import { CaseStudy } from "@/api/entities";
import MetaTags from "@/components/seo/MetaTags";

export default function CaseStudies() {
  const [caseStudies, setCaseStudies] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadCaseStudies();
  }, []);

  const loadCaseStudies = async () => {
    try {
      const studies = await CaseStudy.filter({ is_published: true }, '-created_date', 10);
      setCaseStudies(studies);
    } catch (error) {
      console.error("Error loading case studies:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const projectTypeColors = {
    infrastructure: "bg-blue-500",
    green_energy: "bg-green-500",
    education: "bg-purple-500",
    healthcare: "bg-red-500",
    housing: "bg-orange-500",
    transportation: "bg-teal-500"
  };

  return (
    <>
      <MetaTags
        title="Case Studies | Gazillion"
        description="Success stories from municipalities using Gazillion to fund infrastructure projects through tokenized municipal bonds."
        keywords="case studies, success stories, municipal bonds, infrastructure funding" />

      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Success <span className="text-gradient">Stories</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              See how municipalities across America are leveraging Gazillion to fund critical infrastructure projects and engage their communities.
            </p>
          </div>

          {/* Case Studies Grid */}
          {isLoading ?
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) =>
            <div key={i} className="animate-pulse">
                  <div className="glass-effect h-96 rounded-2xl"></div>
                </div>
            )}
            </div> :
          caseStudies.length > 0 ?
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {caseStudies.map((study) =>
            <Card key={study.id} className="glass-effect border-white/10 bg-transparent hover:bg-white/5 transition-all duration-300 group">
                  <CardHeader>
                    {study.featured_image_url &&
                <div className="w-full h-48 rounded-lg overflow-hidden mb-4">
                        <img
                    src={study.featured_image_url}
                    alt={study.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />

                      </div>
                }
                    <div className="flex items-center justify-between mb-3">
                      <Badge className={`${projectTypeColors[study.project_type]} text-white`}>
                        {study.project_type.replace('_', ' ')}
                      </Badge>
                      {study.amount_raised &&
                  <span className="text-green-400 font-semibold">
                          ${(study.amount_raised / 1000000).toFixed(1)}M raised
                        </span>
                  }
                    </div>
                    <CardTitle className="text-white text-2xl group-hover:text-gradient transition-all duration-300">
                      {study.title}
                    </CardTitle>
                    <p className="text-cyan-300 font-medium">{study.municipality_name}</p>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300 mb-4 line-clamp-3">{study.summary}</p>
                    
                    {study.testimonial &&
                <div className="bg-white/5 p-4 rounded-lg border border-white/10 mb-4">
                        <Quote className="w-6 h-6 text-cyan-400 mb-2" />
                        <p className="text-gray-300 text-sm italic mb-2">"{study.testimonial}"</p>
                        <p className="text-gray-400 text-xs">— {study.testimonial_author}</p>
                      </div>
                }
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm text-gray-400">
                        <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
                        <span>Challenge: {study.challenge?.substring(0, 60)}...</span>
                      </div>
                      <div className="flex items-center text-sm text-gray-400">
                        <TrendingUp className="w-4 h-4 text-cyan-400 mr-2" />
                        <span>Timeline: {study.timeline}</span>
                      </div>
                    </div>
                    
                    <Button variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 w-full border-white/20 hover:bg-white/10 group">
                      Read Full Case Study
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
            )}
            </div> :

          <div className="text-center py-16">
              <Building className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-2xl font-semibold text-white mb-2">Case Studies Coming Soon</h3>
              <p className="text-gray-400 mb-8">We're currently documenting success stories from our pilot programs.</p>
              <Link to={createPageUrl("Contact")}>
                <Button className="primary-gradient text-white">
                  Become a Case Study
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          }

          {/* CTA */}
          <Card className="glass-effect border-white/10 bg-transparent mt-16">
            <CardContent className="p-12 text-center">
              <Users className="w-16 h-16 text-cyan-400 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">
                Want to Be Featured?
              </h2>
              <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
                If you're a municipality interested in pioneering tokenized municipal bonds, we'd love to work with you and share your story.
              </p>
              <Link to={createPageUrl("Contact")}>
                <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-8 py-4 text-lg rounded-full">
                  Partner With Us
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </>);

}