import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Phone } from 'lucide-react';

export default function ContactPage() {
  return (
    <div className="space-y-8">
        <div className="mb-8 p-6 rounded-lg bg-gray-800/30 text-center">
            <h1 className="text-3xl font-bold text-gradient">Contact Us</h1>
            <p className="text-gray-400 mt-2">Get in touch with the Gazillion team.</p>
        </div>

        <Card className="bg-gray-800/50 border-teal-500/20">
            <CardHeader>
                <CardTitle className="flex items-center text-2xl">
                    <Phone className="w-6 h-6 mr-3 text-teal-400" />
                    Coming Soon
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-gray-300">Our contact page is being built. Soon you'll be able to reach out for support, partnerships, and general inquiries.</p>
            </CardContent>
        </Card>
    </div>
  );
}