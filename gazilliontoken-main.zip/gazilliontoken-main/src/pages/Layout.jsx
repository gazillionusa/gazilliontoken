

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Plus, ShoppingCart, Coins, BarChart3, Users, Info, Phone, Landmark, Wallet, Menu, X, Bell, CircleUser, Loader2, ArrowLeft, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from "@/components/ui/dropdown-menu";
import { User } from "@/api/entities"; // Assuming User entity is defined
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import AntiPhishingBanner from './components/AntiPhishingBanner';
import CryptoTicker from './components/crypto/CryptoTicker';

// Placeholder for a real WalletConnect component - now only for logged-out state
const LoggedOutWalletConnect = () => {
  return (
    <Button variant="outline" className="border-teal-300 text-teal-300 hover:bg-teal-900/50 hover:text-white">
      <Wallet className="w-4 h-4 mr-2" />
      Connect Wallet
    </Button>
  );
};


export default function Layout({ children, currentPageName }) {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const queryClient = useQueryClient();

    // Use React Query to fetch user data
    const { data: user, isLoading: isLoadingUser } = useQuery({
        queryKey: ['currentUser'],
        queryFn: async () => {
             // Simulating a fetched user for demonstration. In a real app, this would be `base44.auth.me()`.
            await new Promise(resolve => setTimeout(resolve, 500));
            // Simulate a user that hasn't connected a wallet yet initially
            return { id: 'user123', full_name: 'John Doe', email: 'john@example.com', role: 'issuer', has_connected_external_wallet: false, wallet_address: null };
        },
        staleTime: Infinity, // Avoid refetching user data automatically
    });

    const connectWalletMutation = useMutation({
        mutationFn: (walletData) => base44.functions.invoke('connectWallet', walletData),
        onSuccess: () => {
            toast.success("Wallet connected successfully!");
            queryClient.invalidateQueries({ queryKey: ['currentUser'] });
        },
        onError: (error) => {
            toast.error("Failed to connect wallet", { description: error.message });
        }
    });

    const handleConnectWallet = () => {
        // In a real app, you'd get this from MetaMask or another provider.
        const simulatedWalletAddress = '0x1A2b3C4d5E6f7A8b9C0d1E2F3a4B5c6D7e8F9g0H';
        connectWalletMutation.mutate({ walletAddress: simulatedWalletAddress });
    };

    const navItems = [
        { name: "Create Token", path: "CreateToken", icon: Plus, allowedRoles: ["admin", "issuer"] },
        { name: "Marketplace", path: "BondMarketplace", icon: ShoppingCart },
        { name: "Minter", path: "Minter", icon: Coins }, // Changed: Removed allowedRoles, now visible to all
        { name: "Dashboard", path: "Dashboard", icon: BarChart3 },
    ];

    const filteredNavItems = navItems.filter(item => {
        if (!item.allowedRoles) return true;
        return user && item.allowedRoles.includes(user.role);
    });
    
    const truncateAddress = (address) => {
        if (!address) return '';
        return `${address.slice(0, 6)}...${address.slice(-4)}`;
    };

    return (
        <div className="min-h-screen bg-gray-900 text-white flex flex-col">
            <style>{`
                :root {
                    --background: 222.2 84% 4.9%;
                    --foreground: 210 40% 98%;
                    --card: 222.2 84% 4.9%;
                    --card-foreground: 210 40% 98%;
                    --popover: 222.2 84% 4.9%;
                    --popover-foreground: 210 40% 98%;
                    --primary: 166, 70%, 40%;
                    --primary-foreground: 210 40% 98%;
                    --secondary: 217.2 32.6% 17.5%;
                    --secondary-foreground: 210 40% 98%;
                    --muted: 217.2 32.6% 17.5%;
                    --muted-foreground: 215 20.2% 65.1%;
                    --accent: 166, 70%, 50%;
                    --accent-foreground: 210 40% 98%;
                    --destructive: 0 62.8% 30.6%;
                    --destructive-foreground: 210 40% 98%;
                    --border: 166, 50%, 25%;
                    --input: 166, 50%, 25%;
                    --ring: 166, 70%, 60%;
                    --radius: 0.5rem;
                    --gazillion-primary: #14B8A6; /* Teal-500 */
                    --ticker-up: #22c55e; /* green-500 */
                    --ticker-down: #ef4444; /* red-500 */
                    --ticker-neutral: #a1a1aa; /* zinc-400 */
                }
                .primary-gradient {
                    background: linear-gradient(135deg, #14B8A6, #0D9488);
                }
                .text-gradient {
                    background: linear-gradient(135deg, #A7F3D0, #5EEAD4);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                }
                .flex-grow { flex-grow: 1; }

                @keyframes scroll-left {
                  from { transform: translateX(0); }
                  to { transform: translateX(-50%); }
                }
                .animate-scroll-left {
                  animation: scroll-left 120s linear infinite;
                }
                @media (prefers-reduced-motion: reduce) {
                  .animate-scroll-left {
                    animation: none;
                  }
                }
            `}</style>
            <header className="sticky top-0 z-50">
              <AntiPhishingBanner />
              <CryptoTicker />
              <nav className="bg-gray-900/80 backdrop-blur-lg border-b border-teal-500/20">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                      <div className="flex items-center justify-between h-16 relative"> {/* Added 'relative' to allow absolute positioning of children */}
                          {/* Logo - Left aligned */}
                          <div className="flex items-center">
                              <Link to={createPageUrl('Home')} className="flex-shrink-0 flex items-center space-x-2">
                                  <Landmark className="h-8 w-8 text-teal-400" />
                                  <span className="font-bold text-lg">Gazillion Bond Exchange</span>
                              </Link>
                          </div>
                          
                          {/* Navigation Links - Centered. Use absolute positioning for perfect centering */}
                          <div className="hidden md:block absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
                              <div className="flex items-baseline space-x-4">
                                  {filteredNavItems.map((item) => (
                                      <Link
                                          key={item.name}
                                          to={createPageUrl(item.path)}
                                          className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition ${
                                              currentPageName === item.path
                                                  ? 'bg-teal-900 text-white'
                                                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                                          }`}
                                      >
                                          <item.icon className="h-4 w-4 mr-2" />
                                          {item.name}
                                      </Link>
                                  ))}
                              </div>
                          </div>

                          {/* User Actions & Mobile Menu - Right aligned */}
                          <div className="flex items-center">
                              <div className="hidden md:flex items-center space-x-4">
                                 {user && <Bell className="h-6 w-6 text-gray-400 hover:text-white" />}
                                  {isLoadingUser ? (
                                      <Loader2 className="h-6 w-6 animate-spin" />
                                  ) : user ? (
                                      <DropdownMenu>
                                          <DropdownMenuTrigger asChild>
                                              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                                                  <CircleUser className="h-8 w-8 text-teal-400" />
                                              </Button>
                                          </DropdownMenuTrigger>
                                          <DropdownMenuContent className="w-56" align="end" forceMount>
                                              <div className="flex flex-col space-y-1 p-2">
                                                  <p className="text-sm font-medium leading-none">{user.full_name}</p>
                                                  <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                                              </div>
                                              <DropdownMenuSeparator />
                                              <DropdownMenuItem asChild>
                                                  <Link to={createPageUrl('Profile')}>
                                                      Profile
                                                  </Link>
                                              </DropdownMenuItem>
                                              {user.has_connected_external_wallet ? (
                                                  <DropdownMenuItem disabled>
                                                      <Wallet className="mr-2 h-4 w-4" />
                                                      <span>{truncateAddress(user.wallet_address)}</span>
                                                  </DropdownMenuItem>
                                              ) : (
                                                  <DropdownMenuItem onClick={handleConnectWallet} disabled={connectWalletMutation.isPending}>
                                                      {connectWalletMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : <Wallet className="mr-2 h-4 w-4" />}
                                                      Connect Wallet
                                                  </DropdownMenuItem>
                                              )}
                                              <DropdownMenuItem asChild>
                                                  <Link to={createPageUrl('Settings')}>
                                                      Settings
                                                  </Link>
                                              </DropdownMenuItem>
                                              <DropdownMenuSeparator />
                                              <DropdownMenuItem>Log out</DropdownMenuItem>
                                          </DropdownMenuContent>
                                      </DropdownMenu>
                                  ) : (
                                      <LoggedOutWalletConnect />
                                  )}
                              </div>
                              <div className="-mr-2 flex md:hidden">
                                  <Button
                                      variant="ghost"
                                      onClick={() => setIsMenuOpen(!isMenuOpen)}
                                      className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
                                  >
                                      {isMenuOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
                                  </Button>
                              </div>
                          </div>
                      </div>
                  </div>
                  {isMenuOpen && (
                      <div className="md:hidden">
                          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                              {filteredNavItems.map((item) => (
                                  <Link
                                      key={item.name}
                                      to={createPageUrl(item.path)}
                                      onClick={() => setIsMenuOpen(false)}
                                      className={`flex items-center px-3 py-2 rounded-md text-base font-medium ${
                                          currentPageName === item.path ? 'bg-teal-900 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                                      }`}
                                  >
                                      <item.icon className="h-5 w-5 mr-3" />
                                      {item.name}
                                    </Link>
                              ))}
                          </div>
                           <div className="pt-4 pb-3 border-t border-gray-700 px-5 flex items-center space-x-4">
                              {isLoadingUser ? (
                                  <Loader2 className="h-6 w-6 animate-spin" />
                              ) : user ? (
                                  <div className="flex items-center space-x-2">
                                    <CircleUser className="h-8 w-8 text-teal-400" />
                                    <div>
                                      <p className="text-base font-medium leading-none">{user.full_name}</p>
                                      <p className="text-sm leading-none text-gray-400">{user.email}</p>
                                    </div>
                                  </div>
                              ) : (
                                  <LoggedOutWalletConnect />
                              )}
                          </div>
                      </div>
                  )}
              </nav>
            </header>
            <main className="flex-grow">
                <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
                    {children}
                </div>
            </main>
            <footer className="bg-gray-900/80 border-t border-teal-500/20 mt-12 py-8">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-400">
                    <div className="flex justify-center items-center mb-6">
                        <a 
                            href="https://gazillionusa.com" 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-teal-300 hover:text-white transition-colors duration-300 flex items-center gap-2 text-lg font-semibold"
                        >
                            <ArrowLeft className="w-5 h-5" />
                            Visit GazillionUSA.com
                        </a>
                    </div>
                    <div className="flex justify-center gap-x-6 gap-y-2 flex-wrap mb-4 text-sm">
                        <Link to={createPageUrl('terms')} className="hover:text-white">Terms of Service</Link>
                        <Link to={createPageUrl('privacy')} className="hover:text-white">Privacy Policy</Link>
                        <Link to={createPageUrl('riskdisclosure')} className="hover:text-white">Risk Disclosure</Link>
                        <Link to={createPageUrl('InvestorSupport')} className="hover:text-white">Support</Link>
                    </div>
                    <p className="text-xs">&copy; {new Date().getFullYear()} Gazillion, Inc. All rights reserved.</p>
                </div>
            </footer>
        </div>
    );
}

