import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function LegalNotice() {
    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-4xl mx-auto">
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-3xl text-white">Legal Notice & Regulatory Information</CardTitle>
                        <p className="text-gray-400">Last Updated: September 21, 2025</p>
                    </CardHeader>
                    <CardContent className="space-y-6 text-gray-300">
                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">Corporate Information</h2>
                            <p>Gazillion Bonds NFT LLC is a registered limited liability company organized under the laws of the State of Delaware. Our operational headquarters are located in Phoenix, Arizona.</p>
                        </section>
                        
                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">Regulatory Compliance</h2>
                            <p>Gazillion Bonds NFT LLC is a registered broker-dealer and member of the Financial Industry Regulatory Authority (FINRA) and the Securities Investor Protection Corporation (SIPC). All investment offerings made available through our platform are done so in compliance with applicable U.S. federal and state securities laws, including the Securities Act of 1933 and the Securities Exchange Act of 1934.</p>
                            <p className="mt-2">Our services and offerings may be subject to jurisdictional limitations. Please review our <Link to={createPageUrl("terms")} className="underline hover-primary">Terms of Service</Link> for details on eligibility.</p>
                        </section>

                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">No Offer or Solicitation</h2>
                            <p>The information provided on this website does not constitute an offer to sell or a solicitation of an offer to buy any securities, financial instruments, or services. Offers to sell or solicitations of offers to buy are made only through definitive offering documents, which should be read in their entirety. The content herein is for informational purposes only and should not be construed as investment, legal, tax, or financial advice.</p>
                        </section>

                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">Investment Risks</h2>
                            <p>Investing in municipal bonds, including those tokenized as NFTs, involves significant risks, including but not limited to market risk, credit risk, liquidity risk, and technology risk. There is no assurance that any investment will achieve its objectives or that an investor will receive a return of their capital. Past performance is not indicative of future results. Please read our full <Link to={createPageUrl("riskdisclosure")} className="underline hover-primary">Risk Disclosure</Link> before investing.</p>
                        </section>

                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">Intellectual Property</h2>
                            <p>“Gazillion,” “Gazillion Bonds,” and the Gazillion logo are trademarks of Gazillion Bonds NFT LLC. All content on this site, including text, graphics, logos, and software, is the property of Gazillion and is protected by U.S. and international copyright and trademark laws. Unauthorized use is strictly prohibited.</p>
                        </section>

                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">Forward-Looking Statements</h2>
                            <p>This website may contain forward-looking statements that are based on our current expectations, assumptions, estimates, and projections. These statements are not guarantees of future performance and are subject to risks, uncertainties, and other factors, some of which are beyond our control and are difficult to predict. We undertake no obligation to update any forward-looking statements.</p>
                        </section>

                        <section>
                            <h2 className="text-xl text-white font-semibold mb-3">Contact</h2>
                            <p>For legal or compliance inquiries, please contact our legal department:</p>
                            <p>Email: legal@gazillionusa.com</p>
                        </section>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}