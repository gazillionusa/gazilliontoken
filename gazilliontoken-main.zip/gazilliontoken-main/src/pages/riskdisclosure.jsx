import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from 'lucide-react';

export default function RiskDisclosure() {
  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <Card className="glass-effect border-white/10 bg-transparent">
          <CardHeader>
            <div className="flex items-center gap-4 mb-4">
              <AlertTriangle className="w-12 h-12 text-amber-400" />
              <div>
                <CardTitle className="text-3xl text-white">Risk Disclosure</CardTitle>
                <p className="text-gray-400">Important Information for Investors</p>
              </div>
            </div>
            <p className="text-gray-400">Last Updated: January 2025</p>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-300">
            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Investment Risks</h2>
              <p className="mb-4">Investment in municipal bond NFTs carries risks, including but not limited to:</p>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Market Risk:</strong> The value of bond NFTs may fluctuate based on market conditions, interest rates, and secondary market demand.</li>
                <li><strong>Credit Risk:</strong> While many bonds are government-backed, there remains a risk that the issuing municipality may default on payments.</li>
                <li><strong>Liquidity Risk:</strong> NFT bonds may not always have active buyers in secondary markets, potentially limiting your ability to sell.</li>
                <li><strong>Technology Risk:</strong> Smart contract vulnerabilities, blockchain network issues, or platform technical failures could impact your investment.</li>
                <li><strong>Regulatory Risk:</strong> Changes in securities laws, blockchain regulations, or tax policies could affect the value and legality of these investments.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Blockchain-Specific Risks</h2>
              <ul className="list-disc list-inside space-y-2">
                <li><strong>Private Key Security:</strong> Loss of your private keys means permanent loss of access to your bond NFTs.</li>
                <li><strong>Smart Contract Risk:</strong> Despite audits, smart contracts may contain undiscovered vulnerabilities.</li>
                <li><strong>Network Congestion:</strong> High gas fees or network delays may impact transaction timing and costs.</li>
                <li><strong>Irreversible Transactions:</strong> Blockchain transactions cannot be reversed once confirmed.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Tax Implications</h2>
              <p>Municipal bond NFTs may have different tax treatment than traditional municipal bonds. Consult with a tax professional to understand:</p>
              <ul className="list-disc list-inside space-y-2 mt-2">
                <li>Capital gains taxes on secondary market sales</li>
                <li>Treatment of interest income</li>
                <li>State and local tax implications</li>
                <li>Cryptocurrency taxation rules</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">No Guarantees</h2>
              <p>Gazillion does not guarantee:</p>
              <ul className="list-disc list-inside space-y-2 mt-2">
                <li>Return of principal investment</li>
                <li>Consistent interest payments</li>
                <li>Liquidity or ability to sell on secondary markets</li>
                <li>Protection against market volatility</li>
                <li>Compensation for losses due to technology failures</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Investor Eligibility</h2>
              <p>Certain investments may only be available to accredited investors as defined by SEC regulations. Non-accredited investors should carefully consider their risk tolerance and financial situation before investing.</p>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Due Diligence</h2>
              <p>Investors should:</p>
              <ul className="list-disc list-inside space-y-2 mt-2">
                <li>Read all offering documents carefully</li>
                <li>Understand the specific terms of each bond</li>
                <li>Research the issuing municipality's financial health</li>
                <li>Consult with financial, legal, and tax advisors</li>
                <li>Only invest amounts they can afford to lose</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl text-white font-semibold mb-3">Contact</h2>
              <p>For questions about investment risks:</p>
              <p>Email: risk@gazillionusa.com</p>
            </section>

            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-6 mt-8">
              <p className="text-amber-200 font-semibold">
                By using the Gazillion platform, you acknowledge that you have read, understood, and accepted these risk disclosures. Past performance does not guarantee future results.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}