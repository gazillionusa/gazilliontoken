
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, BarChart3, ShoppingCart, Coins, Wallet, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import MetaTags from "@/components/seo/MetaTags";

export default function Home() {
  const features = [
  {
    icon: BarChart3,
    title: "Investor Dashboard",
    description: "Track your portfolio performance, view your holdings, and monitor accrued interest in real-time."
  },
  {
    icon: ShoppingCart,
    title: "Bond Marketplace",
    description: "Browse, analyze, and invest in a curated selection of government-backed municipal bond NFTs."
  },
  {
    icon: Coins,
    title: "Secure Token Minter",
    description: "Authorized issuers can create, configure, and mint new bond tokens with our compliant and secure tools."
  },
  {
    icon: Wallet,
    title: "Seamless Wallet Integration",
    description: "Connect your digital wallet to securely manage your assets and interact with the bond exchange."
  }];


  const stats = [
  { label: "Total Value Locked", value: "$2.4B", change: "+127%" },
  { label: "Active Bonds", value: "234", change: "+89%" },
  { label: "Active Investors", value: "12,500", change: "+156%" },
  { label: "Average Yield (APY)", value: "8.7%", change: "+2.3%" }];


  const trustedPartners = [
  { name: "City of Phoenix", logo: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/phoenix-logo.png" },
  { name: "Miami-Dade County", logo: "https://qtrypzzcjebvfciynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/miami-logo.png" },
  { name: "State of Delaware", logo: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/delaware-logo.png" },
  { name: "Austin Metro", logo: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/austin-logo.png" }];


  return (
    <>
      <MetaTags
        title="Gazillion Tokenization Portal | Manage Your Bond NFTs"
        description="The official portal for Gazillion Bond Exchange. Access your dashboard, explore the marketplace, and manage your tokenized assets."
        keywords="tokenization portal, NFT bonds, blockchain investment, manage bond nfts, Gazillion" />

      <div className="relative overflow-hidden">
        {/* Background Banner */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          <div className="absolute inset-0 opacity-[0.02] mix-blend-soft-light">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full">
              <div className="flex w-max animate-scroll-left -rotate-12 scale-125">
                <div className="flex-shrink-0 flex items-center">
                  {[...Array(20)].map((_, i) =>
                  <img key={i} src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/ced043f0e_Gazillionlogo.png" className="w-auto h-28 mx-12" alt="" />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div> {/* closing div for background banner */}

        {/* Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6">
          {/* Background Effects */}
          <div className="absolute inset-0">
            <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/20 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-20 right-10 w-96 h-96 bg-teal-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          </div>

          <div className="relative z-10 max-w-7xl mx-auto text-center">
            <div className="mb-8">
              <div className="w-64 h-64 sm:w-80 sm:h-80 rounded-full mx-auto mb-6 border-4 border-cyan-400/30 shadow-lg flex items-center justify-center overflow-hidden bg-transparent">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68eb532d139bc4039895b91e/136522864_GazillionTokengold.png"
                  alt="Gazillion Token" className="opacity-100 w-full h-full object-contain" />

              </div>


              <h1 className="text-slate-50 mb-6 px-4 text-4xl font-bold sm:text-4xl md:text-5xl lg:text-7xl leading-tight">
                Gazillion Tokenization Portal
              </h1>
              <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-8 px-4">
                The official platform for issuers and investors to manage, mint, and trade tokenized municipal bonds.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12 px-4">
              <Link to={createPageUrl("Dashboard")}>
                <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-6 sm:px-8 py-4 text-base sm:text-lg rounded-full transform hover:scale-105 transition-all duration-300 shadow-2xl w-full sm:w-auto">
                  Go to Dashboard
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to={createPageUrl("BondMarketplace")}>
                <Button variant="outline" className="bg-background text-slate-50 px-6 py-4 text-base font-medium rounded-full [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 sm:px-8 sm:text-lg inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border hover:text-accent-foreground h-auto border-white/30 hover:bg-white/10 backdrop-blur-sm w-full sm:w-auto">
                  Explore Marketplace
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 max-w-4xl mx-auto px-4">
              {stats.map((stat, index) =>
              <div key={index} className="glass-effect p-4 sm:p-6 rounded-2xl transform hover:scale-105 transition-all duration-300">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">{stat.value}</div>
                  <div className="text-gray-400 text-xs sm:text-sm mb-2">{stat.label}</div>
                  <div className="text-green-400 text-xs font-medium">{stat.change}</div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Trusted Partners Section */}
        <section className="py-16 px-6">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold text-white text-center mb-12">
              Bonds Issued By <span className="text-gradient">Leading Municipalities</span>
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center">
              {trustedPartners.map((partner, index) =>
              <div key={index} className="glass-effect p-6 rounded-xl flex items-center justify-center hover:bg-white/10 transition-all duration-300">
                  <img
                  src={partner.logo}
                  alt={partner.name}
                  className="max-h-16 w-auto opacity-70 hover:opacity-100 transition-opacity"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.parentElement.innerHTML = `<span class="text-gray-400 text-sm">${partner.name}</span>`;
                  }} />

                </div>
              )}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-6">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Portal <span className="text-gradient">Features</span>
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                A complete suite of tools for both investors and authorized bond issuers.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) =>
              <Card key={index} className="glass-effect border-white/10 bg-transparent group hover:bg-white/5 transition-all duration-500">
                  <CardContent className="p-8">
                    <div className="w-14 h-14 primary-gradient rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                      <feature.icon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
                    <p className="text-gray-400 leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 px-6">
          <div className="max-w-4xl mx-auto text-center">
            <div className="glass-effect p-12 rounded-3xl">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                Access Your <span className="text-gradient">Digital Wallet</span>
              </h2>
              <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
                Connect your wallet to access your dashboard or explore the marketplace for new investment opportunities.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to={createPageUrl("Dashboard")}>
                  <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-8 py-4 text-lg rounded-full transform hover:scale-105 transition-all duration-300 shadow-2xl">
                    Open Dashboard
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to={createPageUrl("BondMarketplace")}>
                  <Button variant="outline" className="bg-slate-950 text-slate-50 px-8 py-4 text-lg font-medium rounded-full inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/30 hover:bg-white/10 backdrop-blur-sm">
                    Explore Marketplace
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>);

}
