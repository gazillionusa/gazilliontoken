import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import {
  BookOpen,
  Search,
  Clock,
  ArrowRight,
  TrendingUp,
  User } from
'lucide-react';
import { Insight } from "@/api/entities";
import { format } from 'date-fns';
import MetaTags from "@/components/seo/MetaTags";

export default function Insights() {
  const [insights, setInsights] = useState([]);
  const [filteredInsights, setFilteredInsights] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    loadInsights();
  }, []);

  const filterInsights = useCallback(() => {
    let filtered = [...insights];

    if (searchTerm) {
      filtered = filtered.filter((insight) =>
      insight.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      insight.excerpt.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((insight) => insight.category === selectedCategory);
    }

    setFilteredInsights(filtered);
  }, [insights, searchTerm, selectedCategory]); // Dependencies for useCallback

  useEffect(() => {
    filterInsights();
  }, [filterInsights]); // useEffect now depends on the memoized filterInsights

  const loadInsights = async () => {
    try {
      const articles = await Insight.filter({ is_published: true }, '-publish_date', 50);
      setInsights(articles);
    } catch (error) {
      console.error("Error loading insights:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const categoryColors = {
    blockchain: "bg-purple-500",
    municipal_bonds: "bg-blue-500",
    investment: "bg-green-500",
    regulation: "bg-red-500",
    technology: "bg-cyan-500",
    case_study: "bg-amber-500"
  };

  return (
    <>
      <MetaTags
        title="Insights & Blog | Gazillion"
        description="Expert insights on tokenized municipal bonds, blockchain technology, and the future of infrastructure investment."
        keywords="blog, insights, tokenized bonds, blockchain, municipal finance, investment guide" />

      <div className="min-h-screen px-4 sm:px-6 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              <BookOpen className="w-12 h-12 inline-block mr-4 text-cyan-400" />
              Insights & <span className="text-gradient">Analysis</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Expert perspectives on the intersection of blockchain, municipal finance, and infrastructure investment.
            </p>
          </div>

          {/* Search & Filter */}
          <Card className="glass-effect border-white/10 bg-transparent mb-12">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search articles..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 glass-effect text-white" />

                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="glass-effect text-white w-full sm:w-64">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 text-white">
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="blockchain">Blockchain</SelectItem>
                    <SelectItem value="municipal_bonds">Municipal Bonds</SelectItem>
                    <SelectItem value="investment">Investment</SelectItem>
                    <SelectItem value="regulation">Regulation</SelectItem>
                    <SelectItem value="technology">Technology</SelectItem>
                    <SelectItem value="case_study">Case Studies</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Articles Grid */}
          {isLoading ?
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) =>
            <div key={i} className="animate-pulse">
                  <div className="glass-effect h-96 rounded-2xl"></div>
                </div>
            )}
            </div> :
          filteredInsights.length > 0 ?
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredInsights.map((insight) =>
            <Card key={insight.id} className="glass-effect border-white/10 bg-transparent hover:bg-white/5 transition-all duration-300 group">
                  <CardHeader>
                    {insight.featured_image_url &&
                <div className="w-full h-48 rounded-lg overflow-hidden mb-4">
                        <img
                    src={insight.featured_image_url}
                    alt={insight.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />

                      </div>
                }
                    <Badge className={`${categoryColors[insight.category]} text-white mb-3 w-fit`}>
                      {insight.category.replace('_', ' ')}
                    </Badge>
                    <CardTitle className="text-white text-xl group-hover:text-gradient transition-all duration-300 line-clamp-2">
                      {insight.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300 mb-4 line-clamp-3">{insight.excerpt}</p>
                    
                    <div className="flex items-center justify-between text-sm text-gray-400 mb-4">
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        <span>{insight.author_name || 'Gazillion Team'}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        <span>{insight.read_time_minutes || 5} min read</span>
                      </div>
                    </div>

                    {insight.publish_date &&
                <p className="text-xs text-gray-500 mb-4">
                        {format(new Date(insight.publish_date), 'MMMM d, yyyy')}
                      </p>
                }
                    
                    <Link to={createPageUrl(`insightdetails?slug=${insight.slug}`)}>
                      <Button variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 w-full border-white/20 hover:bg-white/10 group">
                        Read Article
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
            )}
            </div> :

          <div className="text-center py-16">
              <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-2xl font-semibold text-white mb-2">No Articles Found</h3>
              <p className="text-gray-400">Try adjusting your search or filters.</p>
            </div>
          }

          {/* Newsletter CTA */}
          <Card className="glass-effect border-white/10 bg-transparent mt-16">
            <CardContent className="p-12 text-center">
              <TrendingUp className="w-16 h-16 text-cyan-400 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-white mb-4">
                Stay Informed
              </h2>
              <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
                Subscribe to our newsletter for weekly insights on tokenized municipal bonds and blockchain innovation.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-xl mx-auto">
                <Input
                  placeholder="Enter your email"
                  type="email"
                  className="glass-effect text-white flex-1" />

                <Button className="primary-gradient hover:opacity-90 text-white font-semibold px-8">
                  Subscribe
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>);

}