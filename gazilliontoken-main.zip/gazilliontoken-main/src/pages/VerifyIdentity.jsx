import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function VerifyIdentity() {
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        // Simulate API call to Persona
        toast.info('Submitting information for verification...');
        setTimeout(() => {
            toast.success('Identity verified successfully! Redirecting to marketplace...');
            // In a real app, you'd update user's KYC status here.
            navigate(createPageUrl('BondMarketplace'));
        }, 2000);
    };

    return (
        <div className="max-w-md mx-auto">
            <Card className="bg-gray-800/50 border-teal-500/20">
                <CardHeader>
                    <CardTitle className="flex items-center text-2xl">
                        <ShieldCheck className="w-6 h-6 mr-3 text-teal-400" />
                        Verify Your Identity
                    </CardTitle>
                    <p className="text-sm text-gray-400 pt-2">Investor verification is required for regulatory compliance (Reg D/S). Your information is encrypted and securely processed.</p>
                </CardHeader>
                <form onSubmit={handleSubmit}>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="full_name">Full Legal Name</Label>
                            <Input id="full_name" placeholder="John M. Doe" required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="ssn">SSN or Tax ID</Label>
                            <Input id="ssn" placeholder="***-**-****" required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="address">Residential Address</Label>
                            <Input id="address" placeholder="123 Main St, Anytown, USA" required />
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="id_upload">Government ID Upload</Label>
                            <Input id="id_upload" type="file" required className="file:text-white" />
                            <p className="text-xs text-gray-500">Please upload a clear image of your driver's license or passport.</p>
                        </div>
                    </CardContent>
                    <CardFooter>
                        <Button type="submit" className="w-full primary-gradient">
                            Submit for Verification
                        </Button>
                    </CardFooter>
                </form>
            </Card>
        </div>
    );
}