import React, { useState, useEffect } from 'react';
import { Application } from '@/api/entities';
import { Job } from '@/api/entities';
import { User } from '@/api/entities';
import { CreateFileSignedUrl } from '@/api/integrations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
    FileText, Download, Mail, Calendar, User as UserIcon, 
    Briefcase, Clock, CheckCircle, XCircle, Eye, Loader2 
} from 'lucide-react';
import { toast } from "sonner";
import { formatDistanceToNow } from 'date-fns';

export default function ApplicationsPage() {
    const [applications, setApplications] = useState([]);
    const [jobs, setJobs] = useState({});
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [selectedStatus, setSelectedStatus] = useState('all');

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        try {
            const [applicationsData, jobsData, userData] = await Promise.all([
                Application.list('-created_date'),
                Job.list(),
                User.me()
            ]);

            const jobsMap = jobsData.reduce((acc, job) => {
                acc[job.id] = job;
                return acc;
            }, {});

            setApplications(applicationsData);
            setJobs(jobsMap);
            setUser(userData);
        } catch (error) {
            console.error("Failed to load applications:", error);
            toast.error("Failed to load applications.");
        } finally {
            setLoading(false);
        }
    };

    const downloadResume = async (application) => {
        try {
            const { signed_url } = await CreateFileSignedUrl({ file_uri: application.resume_uri });
            window.open(signed_url, '_blank');
        } catch (error) {
            console.error("Failed to download resume:", error);
            toast.error("Failed to download resume.");
        }
    };

    const updateApplicationStatus = async (applicationId, newStatus) => {
        try {
            await Application.update(applicationId, { status: newStatus });
            toast.success(`Application status updated to ${newStatus}`);
            fetchData(); // Refresh the data
        } catch (error) {
            console.error("Failed to update application status:", error);
            toast.error("Failed to update application status.");
        }
    };

    const getStatusColor = (status) => {
        const colors = {
            'Submitted': 'bg-blue-100 text-blue-800',
            'In Review': 'bg-yellow-100 text-yellow-800',
            'Interviewing': 'bg-purple-100 text-purple-800',
            'Offered': 'bg-green-100 text-green-800',
            'Rejected': 'bg-red-100 text-red-800',
            'Withdrawn': 'bg-gray-100 text-gray-800'
        };
        return colors[status] || 'bg-gray-100 text-gray-800';
    };

    const filteredApplications = selectedStatus === 'all' 
        ? applications 
        : applications.filter(app => app.status === selectedStatus);

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
            </div>
        );
    }

    // Check if user is admin (you might want to add an admin role check here)
    if (!user || user.role !== 'admin') {
        return (
            <div className="flex items-center justify-center min-h-screen text-white">
                <div className="text-center">
                    <h2 className="text-2xl font-bold mb-4">Access Restricted</h2>
                    <p className="text-gray-400">This page is only accessible to administrators.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-7xl mx-auto">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold text-white mb-2">Job Applications</h1>
                        <p className="text-gray-400">Review and manage candidate applications</p>
                    </div>
                </div>

                {/* Status Filter Tabs */}
                <Tabs value={selectedStatus} onValueChange={setSelectedStatus} className="mb-8">
                    <TabsList className="glass-effect bg-transparent border-white/10">
                        <TabsTrigger value="all" className="data-[state=active]:bg-white/10">
                            All ({applications.length})
                        </TabsTrigger>
                        <TabsTrigger value="Submitted" className="data-[state=active]:bg-white/10">
                            New ({applications.filter(a => a.status === 'Submitted').length})
                        </TabsTrigger>
                        <TabsTrigger value="In Review" className="data-[state=active]:bg-white/10">
                            In Review ({applications.filter(a => a.status === 'In Review').length})
                        </TabsTrigger>
                        <TabsTrigger value="Interviewing" className="data-[state=active]:bg-white/10">
                            Interviewing ({applications.filter(a => a.status === 'Interviewing').length})
                        </TabsTrigger>
                    </TabsList>
                </Tabs>

                {/* Applications Grid */}
                <div className="space-y-6">
                    {filteredApplications.length === 0 ? (
                        <div className="text-center py-20 glass-effect rounded-2xl">
                            <FileText className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                            <h3 className="text-2xl font-bold text-white">No Applications</h3>
                            <p className="text-gray-400 mt-2">No applications found for the selected filter.</p>
                        </div>
                    ) : (
                        filteredApplications.map(application => {
                            const job = jobs[application.job_id];
                            return (
                                <Card key={application.id} className="glass-effect border-white/10 bg-transparent">
                                    <CardContent className="p-6">
                                        <div className="grid lg:grid-cols-4 gap-6 items-start">
                                            {/* Applicant Info */}
                                            <div className="lg:col-span-2">
                                                <div className="flex items-start gap-4 mb-4">
                                                    {application.selected_character_image_url ? (
                                                        <img 
                                                            src={application.selected_character_image_url} 
                                                            alt="Avatar" 
                                                            className="w-16 h-16 rounded-full object-cover border-2 border-cyan-400/30"
                                                        />
                                                    ) : (
                                                        <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center border-2 border-cyan-400/30">
                                                            <UserIcon className="w-8 h-8 text-gray-400" />
                                                        </div>
                                                    )}
                                                    <div className="flex-1">
                                                        <h3 className="text-xl font-bold text-white">{application.applicant_name}</h3>
                                                        <p className="text-gray-400 flex items-center gap-1">
                                                            <Mail className="w-4 h-4" />
                                                            {application.applicant_email}
                                                        </p>
                                                        <p className="text-gray-400 flex items-center gap-1 mt-1">
                                                            <Calendar className="w-4 h-4" />
                                                            Applied {formatDistanceToNow(new Date(application.created_date), { addSuffix: true })}
                                                        </p>
                                                    </div>
                                                </div>

                                                {/* Job Info */}
                                                <div className="glass-effect p-4 rounded-lg">
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <Briefcase className="w-4 h-4 text-cyan-400" />
                                                        <span className="text-white font-semibold">{application.job_title}</span>
                                                    </div>
                                                    {job && (
                                                        <div className="text-sm text-gray-400">
                                                            {job.department} • {job.location} • {job.job_type}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>

                                            {/* Cover Letter & Resume */}
                                            <div>
                                                <div className="space-y-4">
                                                    <Button
                                                        onClick={() => downloadResume(application)}
                                                        variant="outline"
                                                        className="w-full glass-effect border-white/20 text-white hover:bg-white/10"
                                                    >
                                                        <Download className="w-4 h-4 mr-2" />
                                                        Download Resume
                                                    </Button>

                                                    {application.cover_letter && (
                                                        <div className="glass-effect p-3 rounded-lg">
                                                            <p className="text-sm text-gray-400 mb-1">Cover Letter:</p>
                                                            <p className="text-white text-sm line-clamp-3">
                                                                {application.cover_letter}
                                                            </p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>

                                            {/* Status & Actions */}
                                            <div className="space-y-4">
                                                <Badge className={getStatusColor(application.status)}>
                                                    {application.status}
                                                </Badge>

                                                <div className="flex flex-wrap gap-2">
                                                    <Button
                                                        onClick={() => updateApplicationStatus(application.id, 'In Review')}
                                                        size="sm"
                                                        className="primary-gradient text-white"
                                                        disabled={application.status === 'In Review'}
                                                    >
                                                        <Eye className="w-4 h-4 mr-1" />
                                                        Review
                                                    </Button>
                                                    <Button
                                                        onClick={() => updateApplicationStatus(application.id, 'Interviewing')}
                                                        size="sm"
                                                        variant="outline"
                                                        className="border-green-500/50 text-green-400 hover:bg-green-500/10"
                                                        disabled={application.status === 'Interviewing'}
                                                    >
                                                        <CheckCircle className="w-4 h-4 mr-1" />
                                                        Interview
                                                    </Button>
                                                    <Button
                                                        onClick={() => updateApplicationStatus(application.id, 'Rejected')}
                                                        size="sm"
                                                        variant="outline"
                                                        className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                                                        disabled={application.status === 'Rejected'}
                                                    >
                                                        <XCircle className="w-4 h-4 mr-1" />
                                                        Reject
                                                    </Button>
                                                </div>
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>
                            );
                        })
                    )}
                </div>
            </div>
        </div>
    );
}