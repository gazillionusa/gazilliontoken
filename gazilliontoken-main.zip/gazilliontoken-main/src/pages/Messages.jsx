import React from 'react';
import MessageInbox from '@/components/messaging/MessageInbox';

export default function MessagesPage() {
    return <MessageInbox />;
}