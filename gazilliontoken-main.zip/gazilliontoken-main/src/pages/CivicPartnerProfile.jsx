import React, { useState, useEffect } from 'react';
import { CivicPartner } from '@/api/entities';
import { CivicPartnerPortal } from '@/api/entities';
import { CivicCampaign } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2,
  Globe,
  Building,
  Lock,
  Twitter,
  Linkedin,
  Instagram,
  Briefcase,
  Landmark,
  Gift,
  FileText,
  Phone,
  Mail,
  MapPin,
  ExternalLink } from
'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function CivicPartnerProfile() {
  const [partner, setPartner] = useState(null);
  const [portal, setPortal] = useState(null);
  const [campaigns, setCampaigns] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const slug = params.get('slug');

        if (!slug) {
          setError("No profile specified.");
          setLoading(false);
          return;
        }

        // Find portal by partner_name (slug)
        const portals = await CivicPartnerPortal.filter({ partner_name: slug });
        if (portals.length === 0) {
          setError("Profile not found.");
          setLoading(false);
          return;
        }

        const portalData = portals[0];

        // Check if portal is public
        if (!portalData.is_public) {
          setError("This profile is private.");
          setLoading(false);
          return;
        }

        // Get partner data
        const partnerData = await CivicPartner.get(portalData.partner_id);

        // Get active campaigns
        const campaignData = await CivicCampaign.filter({
          partner_id: portalData.partner_id,
          status: 'active'
        }, '-created_date', 10);

        setPortal(portalData);
        setPartner(partnerData);
        setCampaigns(campaignData);

      } catch (err) {
        console.error("Error loading profile:", err);
        setError("Failed to load profile.");
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
                <Loader2 className="w-12 h-12 animate-spin text-cyan-400" />
            </div>);

  }

  if (error || !partner || !portal) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
                <Card className="glass-effect border-white/10 bg-transparent p-8 text-center">
                    <CardHeader>
                        <Lock className="w-16 h-16 text-red-400 mx-auto mb-4" />
                        <CardTitle className="text-2xl text-white mb-4">
                            {error || "Profile Not Found"}
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-gray-300 mb-6">
                            This profile may be private or no longer available.
                        </p>
                        <Link to={createPageUrl("Directory")}>
                            <Button variant="outline" className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10">
                                Back to Directory
                            </Button>
                        </Link>
                    </CardContent>
                </Card>
            </div>);

  }

  const PartnerIcon = partner.partner_type === 'business' ? Briefcase : Landmark;
  const partnerTypeLabel = partner.partner_type === 'business' ? 'Zoo Vendor' : 'Civic Guardian';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-gray-900">
            {/* Header/Banner Section */}
            <div className="relative">
                <div className="h-64 md:h-80 bg-gradient-to-br from-cyan-600 to-teal-700 relative overflow-hidden">
                    {portal.banner_url &&
          <>
                            <img
              src={portal.banner_url}
              alt="Cover"
              className="w-full h-full object-cover" />

                            <div className="absolute inset-0 bg-black/30"></div>
                        </>
          }
                </div>
                
                <div className="max-w-6xl mx-auto px-6 -mt-24 relative z-10">
                    <div className="flex flex-col md:flex-row items-center md:items-end space-y-4 md:space-y-0 md:space-x-8">
                        {/* Logo/Avatar */}
                        <div className="w-32 h-32 md:w-48 md:h-48 rounded-2xl bg-white border-4 border-white shadow-lg overflow-hidden flex-shrink-0">
                            {portal.logo_url ?
              <img
                src={portal.logo_url}
                alt={partner.name}
                className="w-full h-full object-contain p-2" /> :


              <div className="w-full h-full flex items-center justify-center bg-gray-100">
                                    <PartnerIcon className="w-16 h-16 md:w-24 md:h-24 text-cyan-600" />
                                </div>
              }
                        </div>
                        
                        {/* Name and Badge */}
                        <div className="text-center md:text-left flex-grow">
                            <h1 className="text-3xl md:text-5xl font-bold text-white mb-3">
                                {partner.name}
                            </h1>
                            <div className="flex flex-wrap justify-center md:justify-start gap-3">
                                <Badge className="bg-cyan-600 text-white border-none px-4 py-2 text-lg">
                                    {partnerTypeLabel}
                                </Badge>
                                <Badge variant="outline" className="text-green-400 border-green-400 px-4 py-2 text-lg">
                                    Active Partner
                                </Badge>
                            </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex gap-3">
                            <Button className="bg-cyan-600 hover:bg-cyan-700 text-white px-6 py-3">
                                Follow
                            </Button>
                            <Button variant="outline" className="text-white border-white/30 hover:bg-white/10 px-6 py-3">
                                Contact
                            </Button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Main Content */}
            <div className="max-w-6xl mx-auto px-6 py-12">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                    {/* Left Sidebar - About */}
                    <div className="lg:col-span-1 space-y-8">
                        <Card className="glass-effect border-white/10 bg-transparent">
                            <CardHeader>
                                <CardTitle className="text-white text-xl flex items-center">
                                    <Building className="w-5 h-5 mr-2" />
                                    About {partner.name}
                                </CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-6">
                                <p className="text-gray-300 leading-relaxed">
                                    {portal.description || partner.description || "No description available."}
                                </p>
                                
                                {/* Contact Information */}
                                {portal.contact_info &&
                <div className="space-y-3">
                                        {portal.contact_info.website &&
                  <a
                    href={portal.contact_info.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center text-cyan-400 hover:text-cyan-300 transition-colors">

                                                <Globe className="w-4 h-4 mr-3" />
                                                Visit Website
                                                <ExternalLink className="w-3 h-3 ml-1" />
                                            </a>
                  }
                                        {portal.contact_info.email &&
                  <a
                    href={`mailto:${portal.contact_info.email}`}
                    className="flex items-center text-gray-400 hover:text-white transition-colors">

                                                <Mail className="w-4 h-4 mr-3" />
                                                {portal.contact_info.email}
                                            </a>
                  }
                                        {portal.contact_info.phone &&
                  <a
                    href={`tel:${portal.contact_info.phone}`}
                    className="flex items-center text-gray-400 hover:text-white transition-colors">

                                                <Phone className="w-4 h-4 mr-3" />
                                                {portal.contact_info.phone}
                                            </a>
                  }
                                        {portal.contact_info.address &&
                  <div className="flex items-start text-gray-400">
                                                <MapPin className="w-4 h-4 mr-3 mt-0.5 flex-shrink-0" />
                                                <span>{portal.contact_info.address}</span>
                                            </div>
                  }
                                    </div>
                }

                                {/* Social Links */}
                                {portal.social_links && Object.values(portal.social_links).some((link) => link) &&
                <div className="pt-4 border-t border-white/10">
                                        <h4 className="text-white font-semibold mb-3">Follow Us</h4>
                                        <div className="flex space-x-4">
                                            {portal.social_links.twitter &&
                    <a
                      href={portal.social_links.twitter}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-blue-400 transition-colors">

                                                    <Twitter className="w-6 h-6" />
                                                </a>
                    }
                                            {portal.social_links.linkedin &&
                    <a
                      href={portal.social_links.linkedin}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-blue-600 transition-colors">

                                                    <Linkedin className="w-6 h-6" />
                                                </a>
                    }
                                            {portal.social_links.instagram &&
                    <a
                      href={portal.social_links.instagram}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-400 hover:text-pink-400 transition-colors">

                                                    <Instagram className="w-6 h-6" />
                                                </a>
                    }
                                        </div>
                                    </div>
                }
                            </CardContent>
                        </Card>
                    </div>
                    
                    {/* Right Content - Tabs */}
                    <div className="lg:col-span-2">
                        <Tabs defaultValue="campaigns" className="w-full">
                            <TabsList className="glass-effect bg-transparent border-white/20 w-full">
                                <TabsTrigger
                  value="campaigns"
                  className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600 flex-1">

                                    <Gift className="w-4 h-4 mr-2" />
                                    Offers & Rewards
                                </TabsTrigger>
                                <TabsTrigger
                  value="updates"
                  className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600 flex-1">

                                    <FileText className="w-4 h-4 mr-2" />
                                    Updates
                                </TabsTrigger>
                            </TabsList>
                            
                            <TabsContent value="campaigns" className="mt-8">
                                <Card className="glass-effect border-white/10 bg-transparent">
                                    <CardHeader>
                                        <CardTitle className="text-white">
                                            Active Campaigns & Bond Perks
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        {campaigns.length > 0 ?
                    <div className="space-y-6">
                                                {campaigns.map((campaign) =>
                      <div
                        key={campaign.id}
                        className="p-6 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors">

                                                        {campaign.image_url &&
                        <img
                          src={campaign.image_url}
                          alt={campaign.campaign_name}
                          className="w-full h-48 object-cover rounded-lg mb-4" />

                        }
                                                        <div className="flex justify-between items-start mb-3">
                                                            <h4 className="text-xl font-semibold text-white">
                                                                {campaign.campaign_name}
                                                            </h4>
                                                            <Badge className="bg-green-600 text-white">
                                                                {campaign.reward_amount} {campaign.reward_type.toUpperCase()}
                                                            </Badge>
                                                        </div>
                                                        <p className="text-gray-300 mb-4">
                                                            {campaign.description}
                                                        </p>
                                                        {campaign.requirement_description &&
                        <div className="bg-cyan-600/10 border border-cyan-600/30 rounded-lg p-4">
                                                                <h5 className="text-cyan-400 font-medium mb-2">How to Participate:</h5>
                                                                <p className="text-gray-300 text-sm">
                                                                    {campaign.requirement_description}
                                                                </p>
                                                            </div>
                        }
                                                    </div>
                      )}
                                            </div> :

                    <div className="text-center py-16">
                                                <Gift className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                                                <h3 className="text-xl font-semibold text-white mb-2">
                                                    No Active Campaigns
                                                </h3>
                                                <p className="text-gray-400">
                                                    This partner doesn't have any active campaigns or bond perks at the moment.
                                                </p>
                                            </div>
                    }
                                    </CardContent>
                                </Card>
                            </TabsContent>
                            
                            <TabsContent value="updates" className="mt-8">
                                <Card className="glass-effect border-white/10 bg-transparent">
                                    <CardHeader>
                                        <CardTitle className="text-white">Community Updates</CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <div className="text-center py-16">
                                            <FileText className="w-16 h-16 text-gray-500 mx-auto mb-4" />
                                            <h3 className="text-xl font-semibold text-white mb-2">
                                                No Updates Yet
                                            </h3>
                                            <p className="text-gray-400">
                                                Community updates and project news will appear here.
                                            </p>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>
                        </Tabs>
                    </div>
                </div>
            </div>
        </div>);

}