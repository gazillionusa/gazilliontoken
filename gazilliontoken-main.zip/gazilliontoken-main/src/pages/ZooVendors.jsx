import React from 'react';
import { Briefcase } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ZooVendorsPage() {
    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-4xl mx-auto">
                <div className="text-center mb-8">
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        <Briefcase className="w-12 h-12 inline-block mr-4 text-cyan-400" />
                        Zoo <span className="text-gradient">Vendors</span>
                    </h1>
                    <p className="text-lg text-gray-300">
                        Businesses empowering the community through perks, sponsorships, and engagement.
                    </p>
                </div>

                <div className="text-center mb-12">
                    <h3 className="text-2xl font-bold text-white">Ready to Engage the Community?</h3>
                    <p className="text-gray-400 mt-2 max-w-2xl mx-auto">
                        Create your own portal to launch campaigns, offer rewards, and connect with citizen investors.
                    </p>
                </div>
                
                <div className="mb-12 max-w-xl mx-auto">
                    <Link to={createPageUrl("Onboarding")}>
                        <div className="text-center bg-cyan-500 hover:bg-cyan-600 transition-colors duration-300 p-6 rounded-2xl cursor-pointer shadow-lg hover:shadow-xl">
                            <img 
                                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/9742c6d37_SignupBusinessImageGazillion2.png"
                                alt="Welcome, Zoo Partner!" 
                                className="max-w-full h-auto rounded-lg shadow-md hover:scale-105 transition-transform duration-300"
                            />
                        </div>
                    </Link>
                </div>

            </div>
        </div>
    );
}