import React from 'react';
import MintWidget from '@/components/minting/MintWidget';

// !! IMPORTANT !!
// Replace these with your actual deployed contract addresses.
const STABLECOIN_ADDRESS = "0xYourStablecoinContractAddressHere";
const BOND_NFT_ADDRESS = "0xYourBondNftContractAddressHere";
const CHAIN_ID = 8453; // Example: Base Mainnet

export default function MinterPage() {
    const handleMintSuccess = (payload) => {
        console.log("Mint successful:", payload);
        // You can add logic here to show a confirmation message or redirect the user
    };

    return (
        <div className="container mx-auto py-12 px-4">
            <h1 className="text-4xl font-bold text-center text-gradient mb-4">
                Token Minter
            </h1>
            <p className="text-xl text-gray-400 text-center max-w-2xl mx-auto mb-12">
                Use this portal to mint GUSD stablecoins via an authorized deposit or to purchase official Gazillion Bond NFTs.
            </p>

            <MintWidget
                stablecoinAddress={STABLECOIN_ADDRESS}
                bondAddress={BOND_NFT_ADDRESS}
                chainId={CHAIN_ID}
                onSuccess={handleMintSuccess}
                theme="dark"
            />
        </div>
    );
}