import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from 'react-router-dom';
import { 
  DollarSign, 
  TrendingUp, 
  Shield, 
  AlertTriangle, 
  Clock, 
  FileText,
  Users,
  Building,
  Calculator,
  CheckCircle,
  XCircle,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  PieChart,
  Calendar,
  Bell,
  Send,
  Plus,
  CreditCard
} from 'lucide-react';
import { Bond } from "@/api/entities";
import { User } from "@/api/entities";
import { BondToken } from "@/api/entities";
import { LoanAgreement } from "@/api/entities";
import { BorrowerCompany } from "@/api/entities";
import { Investor } from "@/api/entities";
import { PaymentSchedule } from "@/api/entities";
import { DefaultEvent } from "@/api/entities";
import { lendingOperations } from "@/api/functions";
import MetaTags from "@/components/seo/MetaTags";
import CreditPullModal from "@/components/lending/CreditPullModal";

export default function LendingPage() {
  const [activeTab, setActiveTab] = useState("borrow");
  const [user, setUser] = useState(null);
  const [userBonds, setUserBonds] = useState([]);
  const [loanApplication, setLoanApplication] = useState({
    requestedAmount: '',
    termMonths: '12',
    purpose: '',
    collateralDescription: '',
    monthlyIncome: '',
    expenses: ''
  });
  const [bondTokens, setBondTokens] = useState([]);
  const [loanAgreements, setLoanAgreements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCreditModal, setShowCreditModal] = useState(false);
  const [creditResults, setCreditResults] = useState(null);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Load user's bonds for collateral calculation
      const bonds = await Bond.list();
      const userBondPurchases = bonds.filter(bond => bond.created_by === currentUser.email);
      setUserBonds(userBondPurchases);
      
      // Load existing data
      const [tokens, loans] = await Promise.all([
        BondToken.list(),
        LoanAgreement.list()
      ]);
      
      setBondTokens(tokens);
      setLoanAgreements(loans);
    } catch (error) {
      console.error("Error loading user data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateCollateralValue = () => {
    return userBonds.reduce((sum, bond) => sum + (bond.current_price || bond.face_value || 0), 0);
  };

  const calculateMaxLoanAmount = () => {
    const collateralValue = calculateCollateralValue();
    return Math.floor(collateralValue * 0.7); // 70% LTV ratio
  };

  const handleCreditPulled = (results) => {
    setCreditResults(results);
    // Auto-populate loan application with approved amounts
    if (results.decision.decision === 'approved' || results.decision.decision === 'conditional') {
      setLoanApplication(prev => ({
        ...prev,
        requestedAmount: results.decision.max_loan_amount.toString(),
        termMonths: results.decision.max_term_months.toString()
      }));
    }
  };

  const handleLoanApplication = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      // Create borrower company record if needed
      let borrower = await BorrowerCompany.filter({ company_name: user.full_name });
      
      if (borrower.length === 0) {
        borrower = await BorrowerCompany.create({
          company_name: user.full_name,
          company_type: "external",
          annual_revenue: parseFloat(loanApplication.monthlyIncome) * 12,
          monthly_cash_flow: parseFloat(loanApplication.monthlyIncome) - parseFloat(loanApplication.expenses),
          credit_score: creditResults?.credit_summary?.average_score || 700,
          debt_to_equity_ratio: 0.3,
          collateral_value: calculateCollateralValue()
        });
      } else {
        borrower = borrower[0];
      }

      // Submit for underwriting
      const response = await lendingOperations({
        operation: 'underwrite_borrower',
        data: {
          borrowerId: borrower.id,
          requestedAmount: parseFloat(loanApplication.requestedAmount),
          termMonths: parseInt(loanApplication.termMonths),
          creditResults: creditResults
        }
      });

      if (response.data.approved) {
        alert(`Congratulations! Your loan has been pre-approved for up to $${response.data.maxLoanAmount.toLocaleString()} at ${response.data.interestRate}% APY`);
        
        // Create loan agreement
        await LoanAgreement.create({
          borrower_id: borrower.id,
          principal_amount: Math.min(parseFloat(loanApplication.requestedAmount), response.data.maxLoanAmount),
          interest_rate: response.data.interestRate,
          term_months: parseInt(loanApplication.termMonths),
          disbursement_date: new Date().toISOString().split('T')[0],
          maturity_date: new Date(Date.now() + parseInt(loanApplication.termMonths) * 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          outstanding_balance: Math.min(parseFloat(loanApplication.requestedAmount), response.data.maxLoanAmount),
          status: 'active'
        });
        
        // Reset form
        setLoanApplication({
          requestedAmount: '',
          termMonths: '12',
          purpose: '',
          collateralDescription: '',
          monthlyIncome: '',
          expenses: ''
        });
        setCreditResults(null);
        
        loadUserData();
      } else {
        alert('Unfortunately, your loan application was not approved at this time. Please improve your financial profile and try again.');
      }
    } catch (error) {
      console.error("Error submitting loan application:", error);
      alert('There was an error processing your application. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const createPageUrl = (path) => {
    return `/app/${path}`;
  };

  const LoanApplicationForm = () => (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <CardTitle className="text-white text-xl sm:text-2xl flex items-center flex-wrap gap-2">
          <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-cyan-400 flex-shrink-0" />
          <span>Apply for Bond-Backed Loan</span>
        </CardTitle>
        <p className="text-gray-400 text-sm sm:text-base mt-2">Use your bond holdings as collateral to access capital</p>
      </CardHeader>
      <CardContent className="px-4 sm:px-6">
        {/* Credit Pull Section */}
        <div className="mb-6 sm:mb-8 p-4 bg-cyan-400/5 border border-cyan-400/20 rounded-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
            <div>
              <h3 className="text-white font-semibold mb-1 text-sm sm:text-base">Credit Report Required</h3>
              <p className="text-gray-400 text-xs sm:text-sm">We need to pull your credit report for underwriting</p>
            </div>
            {!creditResults ? (
              <Button 
                onClick={() => setShowCreditModal(true)}
                className="bg-cyan-600 hover:bg-cyan-700 text-white w-full sm:w-auto whitespace-nowrap"
                size="sm"
              >
                <Shield className="w-4 h-4 mr-2" />
                Pull Credit Report
              </Button>
            ) : (
              <div className="text-left sm:text-right w-full sm:w-auto">
                <div className="text-green-400 font-semibold flex items-center sm:justify-end text-sm">
                  <CheckCircle className="w-4 h-4 mr-1"/> Credit Approved
                </div>
                <div className="text-xs sm:text-sm text-gray-400">Score: {creditResults.credit_summary?.average_score}</div>
              </div>
            )}
          </div>
          
          {creditResults && (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-center text-xs sm:text-sm">
              <div>
                <div className="text-white font-semibold">{creditResults.decision.risk_grade}</div>
                <div className="text-gray-400">Risk Grade</div>
              </div>
              <div>
                <div className="text-green-400 font-semibold">
                  ${creditResults.decision.max_loan_amount?.toLocaleString()}
                </div>
                <div className="text-gray-400">Max Approved</div>
              </div>
              <div>
                <div className="text-cyan-400 font-semibold">{creditResults.decision.interest_rate}%</div>
                <div className="text-gray-400">Interest Rate</div>
              </div>
              <div>
                <div className="text-white font-semibold">{creditResults.decision.max_term_months}mo</div>
                <div className="text-gray-400">Max Term</div>
              </div>
            </div>
          )}
        </div>

        <form onSubmit={handleLoanApplication} className="space-y-4 sm:space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <div className="space-y-2">
              <Label className="text-white text-sm">Requested Loan Amount</Label>
              <Input
                type="number"
                placeholder="50000"
                value={loanApplication.requestedAmount}
                onChange={(e) => setLoanApplication({...loanApplication, requestedAmount: e.target.value})}
                className="glass-effect border-white/20 bg-transparent text-white"
                required
                max={creditResults?.decision.max_loan_amount || calculateMaxLoanAmount()}
              />
              <p className="text-xs sm:text-sm text-gray-400">
                Maximum available: ${calculateMaxLoanAmount().toLocaleString()} (70% of bond value)
                {creditResults && ` (Credit Max: $${creditResults.decision.max_loan_amount.toLocaleString()})`}
              </p>
            </div>
            
            <div className="space-y-2">
              <Label className="text-white text-sm">Loan Term</Label>
              <Select 
                value={loanApplication.termMonths} 
                onValueChange={(value) => setLoanApplication({...loanApplication, termMonths: value})}
              >
                <SelectTrigger className="glass-effect border-white/20 bg-transparent text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-white/20">
                  <SelectItem value="6">6 months</SelectItem>
                  <SelectItem value="12">12 months</SelectItem>
                  <SelectItem value="24">24 months</SelectItem>
                  <SelectItem value="36">36 months</SelectItem>
                </SelectContent>
              </Select>
              {creditResults && (
                <p className="text-xs sm:text-sm text-gray-400">Max Term based on credit: {creditResults.decision.max_term_months} months</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-white text-sm">Loan Purpose</Label>
            <Textarea
              placeholder="Describe what you'll use the funds for..."
              value={loanApplication.purpose}
              onChange={(e) => setLoanApplication({...loanApplication, purpose: e.target.value})}
              className="glass-effect border-white/20 bg-transparent text-white min-h-[80px]"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
            <div className="space-y-2">
              <Label className="text-white text-sm">Monthly Income</Label>
              <Input
                type="number"
                placeholder="10000"
                value={loanApplication.monthlyIncome}
                onChange={(e) => setLoanApplication({...loanApplication, monthlyIncome: e.target.value})}
                className="glass-effect border-white/20 bg-transparent text-white"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-white text-sm">Monthly Expenses</Label>
              <Input
                type="number"
                placeholder="5000"
                value={loanApplication.expenses}
                onChange={(e) => setLoanApplication({...loanApplication, expenses: e.target.value})}
                className="glass-effect border-white/20 bg-transparent text-white"
                required
              />
            </div>
          </div>

          {/* Collateral Summary */}
          <Card className="glass-effect border-cyan-400/30 bg-cyan-400/5">
            <CardContent className="p-4 sm:p-6">
              <h3 className="text-white font-semibold mb-4 text-sm sm:text-base">Your Bond Collateral</h3>
              <div className="grid grid-cols-3 gap-3 sm:gap-4 text-center">
                <div>
                  <p className="text-xl sm:text-2xl font-bold text-white">{userBonds.length}</p>
                  <p className="text-gray-400 text-xs sm:text-sm">Bonds Owned</p>
                </div>
                <div>
                  <p className="text-xl sm:text-2xl font-bold text-cyan-400">${calculateCollateralValue().toLocaleString()}</p>
                  <p className="text-gray-400 text-xs sm:text-sm">Total Value</p>
                </div>
                <div>
                  <p className="text-xl sm:text-2xl font-bold text-green-400">${calculateMaxLoanAmount().toLocaleString()}</p>
                  <p className="text-gray-400 text-xs sm:text-sm">Max Loan (70% LTV)</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Button 
            type="submit" 
            disabled={isSubmitting || !creditResults || calculateCollateralValue() === 0}
            className="w-full primary-gradient hover:opacity-90 text-white font-semibold py-3 sm:py-4 text-base sm:text-lg rounded-full"
          >
            {isSubmitting ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Processing Application...
              </div>
            ) : (
              <>
                <Send className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                Submit Loan Application
              </>
            )}
          </Button>
          
          {!creditResults && (
            <p className="text-orange-400 text-center text-xs sm:text-sm">
              Please complete credit authorization before submitting your loan application.
            </p>
          )}

          {calculateCollateralValue() === 0 && (
            <p className="text-orange-400 text-center text-xs sm:text-sm">
              You need to own bonds to use as collateral. Visit the marketplace to purchase bonds first.
            </p>
          )}
        </form>
      </CardContent>
    </Card>
  );

  const InvestmentPortal = () => (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <CardTitle className="text-white text-xl sm:text-2xl flex items-center flex-wrap gap-2">
          <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-green-400 flex-shrink-0" />
          <span>Investment Opportunities</span>
        </CardTitle>
        <p className="text-gray-400 text-sm sm:text-base mt-2">Invest in bond-backed lending pools</p>
      </CardHeader>
      <CardContent className="px-4 sm:px-6">
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            <Card className="glass-effect border-green-400/30 bg-green-400/5">
              <CardContent className="p-4 sm:p-6 text-center">
                <Shield className="w-10 h-10 sm:w-12 sm:h-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg sm:text-xl font-bold text-white mb-2">Senior Lending Pool</h3>
                <p className="text-green-400 text-2xl sm:text-3xl font-bold mb-2">8.5% APY</p>
                <p className="text-gray-400 text-xs sm:text-sm mb-4">Low risk, government-backed collateral</p>
                <Link to={createPageUrl("InvestmentPool?pool=senior")}>
                  <Button className="w-full bg-green-600 hover:bg-green-700 text-white text-sm sm:text-base">
                    Invest Now
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="glass-effect border-amber-400/30 bg-amber-400/5">
              <CardContent className="p-4 sm:p-6 text-center">
                <TrendingUp className="w-10 h-10 sm:w-12 sm:h-12 text-amber-400 mx-auto mb-4" />
                <h3 className="text-lg sm:text-xl font-bold text-white mb-2">Growth Lending Pool</h3>
                <p className="text-amber-400 text-2xl sm:text-3xl font-bold mb-2">12.3% APY</p>
                <p className="text-gray-400 text-xs sm:text-sm mb-4">Higher yield, diversified portfolio</p>
                <Link to={createPageUrl("InvestmentPool?pool=growth")}>
                  <Button className="w-full bg-amber-600 hover:bg-amber-700 text-white text-sm sm:text-base">
                    Invest Now
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <p className="text-gray-400 mb-4 text-xs sm:text-sm">
              Minimum investment: $1,000 • Lock-up period: 6-24 months
            </p>
            <Link to={createPageUrl("InvestmentPool?pool=senior")}>
              <Button variant="outline" className="border-white/30 hover:bg-white/10 text-sm sm:text-base">
                Learn More About Lending Pools
              </Button>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="min-h-screen px-4 sm:px-6 py-8 sm:py-12 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
      </div>
    );
  }

  return (
    <>
      <MetaTags
        title="Lending - Bond-Backed Loans & Investment | Gazillion"
        description="Access capital using your bond holdings as collateral, or invest in lending pools for attractive returns."
        keywords="bond-backed loans, lending platform, investment opportunities, collateralized lending"
      />
      <div className="min-h-screen px-4 sm:px-6 py-8 sm:py-12">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8 sm:mb-12">
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Gazillion <span className="text-gradient">Lending</span>
            </h1>
            <p className="text-gray-300 text-base sm:text-lg max-w-3xl mx-auto px-4">
              Unlock liquidity from your bond portfolio or invest in bond-backed lending opportunities
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="glass-effect bg-transparent border-white/10 w-full grid grid-cols-2 gap-2 p-1">
              <TabsTrigger 
                value="borrow" 
                className="data-[state=active]:bg-white/10 data-[state=active]:text-white text-sm sm:text-base"
              >
                Borrow Against Bonds
              </TabsTrigger>
              <TabsTrigger 
                value="invest" 
                className="data-[state=active]:bg-white/10 data-[state=active]:text-white text-sm sm:text-base"
              >
                Invest in Lending
              </TabsTrigger>
            </TabsList>

            <TabsContent value="borrow">
              <LoanApplicationForm />
            </TabsContent>

            <TabsContent value="invest">
              <InvestmentPortal />
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      <CreditPullModal
        isOpen={showCreditModal}
        onClose={() => setShowCreditModal(false)}
        borrowerId={user?.id || "temp_borrower_id"}
        onCreditPulled={handleCreditPulled}
      />
    </>
  );
}