
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { CivicPartner } from '@/api/entities';
import { CivicPartnerPortal } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Building,
  Settings,
  Users,
  Calendar,
  MessageSquare,
  BarChart3,
  Plus,
  Zap,
  Gift,
  CreditCard,
  Briefcase,
  Landmark,
  ArrowLeft,
  Loader2,
  Eye,
  TrendingUp,
  FileText,
  Globe } from
'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import PortalDashboard from '@/components/civic-portal/PortalDashboard';
import CampaignsManager from '@/components/civic-portal/CampaignsManager';
import EventsManager from '@/components/civic-portal/EventsManager';
import StaffManager from '@/components/civic-portal/StaffManager';
import MessagingHub from '@/components/civic-portal/MessagingHub';
import CRMDashboard from '@/components/civic-portal/CRMDashboard';
import PortalSettings from '@/components/civic-portal/PortalSettings';
import BondManager from '@/components/civic-portal/BondManager';
import ReportsAnalytics from '@/components/civic-portal/ReportsAnalytics';

export default function PartnerPortal() {
  const [user, setUser] = useState(null);
  const [partner, setPartner] = useState(null);
  const [portal, setPortal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadPortalData();
  }, []);

  const loadPortalData = async () => {
    try {
      const userData = await User.me();
      setUser(userData);

      if (userData.partner_id) {
        const [partnerData, portalData] = await Promise.all([
        CivicPartner.get(userData.partner_id),
        CivicPartnerPortal.filter({ partner_id: userData.partner_id })]
        );

        setPartner(partnerData);
        setPortal(portalData[0] || null);
      }
    } catch (error) {
      console.error("Failed to load portal data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
            </div>);

  }

  if (!user?.partner_id) {
    return (
      <div className="min-h-screen px-6 py-12">
                <div className="max-w-4xl mx-auto text-center">
                    <div className="glass-effect p-8 rounded-2xl border border-white/10">
                        <Building className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
                        <h2 className="text-2xl font-bold text-white mb-4">Access Denied</h2>
                        <p className="text-gray-300 mb-6">
                            You need to be associated with a Civic Partner organization to access this portal.
                        </p>
                        <Link to={createPageUrl("Contact")}>
                            <Button className="primary-gradient text-white">
                                Contact Support
                            </Button>
                        </Link>
                    </div>
                </div>
            </div>);

  }

  const getPartnerIcon = () => {
    return partner?.partner_type === 'business' ? <Briefcase className="w-6 h-6" /> : <Landmark className="w-6 h-6" />;
  };

  const getPartnerTypeLabel = () => {
    return partner?.partner_type === 'business' ? 'Zoo Vendor' : 'Civic Guardian';
  };

  return (
    <div className="min-h-screen px-6 py-8">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center space-x-4">
                        <Link to={createPageUrl("Dashboard")}>
                            <Button variant="ghost" className="text-gray-400 hover:text-white">
                                <ArrowLeft className="w-4 h-4 mr-2" />
                                Back to Dashboard
                            </Button>
                        </Link>
                        <div className="h-8 w-px bg-white/20"></div>
                        <div className="flex items-center space-x-3">
                            {getPartnerIcon()}
                            <div>
                                <h1 className="text-2xl font-bold text-white">
                                    {partner?.name || 'Partner Portal'}
                                </h1>
                                <div className="flex items-center space-x-2">
                                    <Badge className="bg-cyan-600 text-white">
                                        {getPartnerTypeLabel()}
                                    </Badge>
                                    {!portal?.onboarding_completed &&
                  <Badge variant="outline" className="text-amber-400 border-amber-400">
                                            Setup Required
                                        </Badge>
                  }
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                        {portal?.partner_name &&
            <Link to={createPageUrl(`CivicPartnerProfile?slug=${portal.partner_name}`)}>
                                <Button variant="outline" className="text-cyan-400 border-cyan-400 hover:bg-cyan-400/10">
                                    <Eye className="w-4 h-4 mr-2" />
                                    View Public Page
                                </Button>
                            </Link>
            }
                        <Link to={createPageUrl("PublicPageEditor")}>
                            <Button variant="outline" className="bg-background text-slate-600 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:bg-accent hover:text-accent-foreground h-10 border-white/20">
                                <Settings className="w-4 h-4 mr-2" />
                                Edit Public Page
                            </Button>
                        </Link>
                        <Link to={createPageUrl("CampaignBuilder")}>
                            <Button className="primary-gradient text-white">
                                <Plus className="w-4 h-4 mr-2" />
                                New Campaign
                            </Button>
                        </Link>
                        <Link to={createPageUrl("BillingPortal")}>
                            <Button variant="outline" className="bg-background text-slate-600 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:bg-accent hover:text-accent-foreground h-10 border-white/20">
                                <CreditCard className="w-4 h-4 mr-2" />
                                Manage Subscription
                            </Button>
                        </Link>
                    </div>
                </div>

                {/* Main Portal Interface */}
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
                    <TabsList className="glass-effect bg-transparent border-white/20 p-1 flex-wrap">
                        <TabsTrigger
              value="overview"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <BarChart3 className="w-4 h-4 mr-2" />
                            Overview
                        </TabsTrigger>
                        <TabsTrigger
              value="campaigns"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <Zap className="w-4 h-4 mr-2" />
                            Campaigns
                        </TabsTrigger>
                        <TabsTrigger
              value="bonds"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <Gift className="w-4 h-4 mr-2" />
                            Bond Listings
                        </TabsTrigger>
                        <TabsTrigger
              value="events"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <Calendar className="w-4 h-4 mr-2" />
                            Events
                        </TabsTrigger>
                        <TabsTrigger
              value="crm"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <Users className="w-4 h-4 mr-2" />
                            CRM
                        </TabsTrigger>
                        <TabsTrigger
              value="messaging"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <MessageSquare className="w-4 h-4 mr-2" />
                            Messages
                        </TabsTrigger>
                        <TabsTrigger
              value="team"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <Users className="w-4 h-4 mr-2" />
                            Team
                        </TabsTrigger>
                        <TabsTrigger
              value="reports"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <FileText className="w-4 h-4 mr-2" />
                            Reports
                        </TabsTrigger>
                        <TabsTrigger
              value="settings"
              className="text-gray-300 data-[state=active]:text-white data-[state=active]:bg-cyan-600">

                            <Settings className="w-4 h-4 mr-2" />
                            Settings
                        </TabsTrigger>
                    </TabsList>

                    <TabsContent value="overview">
                        <PortalDashboard partner={partner} portal={portal} />
                    </TabsContent>
                    
                    <TabsContent value="campaigns">
                        <CampaignsManager partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="bonds">
                        <BondManager partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="events">
                        <EventsManager partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="crm">
                        <CRMDashboard partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="messaging">
                        <MessagingHub partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="team">
                        <StaffManager partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="reports">
                        <ReportsAnalytics partner={partner} />
                    </TabsContent>
                    
                    <TabsContent value="settings">
                        <PortalSettings partner={partner} portal={portal} onUpdate={loadPortalData} />
                    </TabsContent>
                </Tabs>
            </div>
        </div>);

}