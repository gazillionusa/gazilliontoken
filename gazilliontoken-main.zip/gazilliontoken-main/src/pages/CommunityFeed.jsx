
import React, { useState, useEffect } from 'react';
import { Post } from '@/api/entities';
import { User } from '@/api/entities';
import { Like } from '@/api/entities';
import { Comment } from '@/api/entities';
import { Loader2, MessageSquare, Newspaper } from 'lucide-react';
import { toast } from "sonner";
import CreatePostForm from '@/components/community/CreatePostForm';
import PostCard from '@/components/community/PostCard';
import FriendsList from '@/components/community/FriendsList';

export default function CommunityFeed() {
    const [posts, setPosts] = useState([]);
    const [likes, setLikes] = useState([]);
    const [comments, setComments] = useState([]);
    const [currentUser, setCurrentUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('feed');

    const fetchAllData = async () => {
        try {
            const [postData, likeData, commentData, userData] = await Promise.all([
                Post.list('-created_date'),
                Like.list(),
                Comment.list(),
                User.me().catch(() => null)
            ]);
            
            setPosts(postData);
            setLikes(likeData);
            setComments(commentData);
            setCurrentUser(userData);

        } catch (error) {
            console.error("Failed to load community feed:", error);
            toast.error("Could not load the community feed.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllData();
    }, []);

    const onDataRefresh = () => {
        setLoading(true);
        fetchAllData();
    };

    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-3xl mx-auto">
                <div className="text-center mb-12">
                    <div className="inline-block glass-effect px-6 py-3 rounded-full mb-6">
                        <span className="brand-accent text-sm font-medium">Community Hub</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                        Investor's <span className="text-gradient">Roundtable</span>
                    </h1>
                    <p className="text-lg text-gray-300">
                        Share your investment journey, discuss market trends, and connect with other Gazillionaires.
                    </p>
                </div>

                {/* Navigation Tabs */}
                <div className="flex justify-center mb-8">
                    <div className="glass-effect p-2 rounded-2xl">
                        <button
                            onClick={() => setActiveTab('feed')}
                            className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                                activeTab === 'feed' 
                                    ? 'primary-gradient text-white shadow-lg' 
                                    : 'text-gray-400 hover:text-white'
                            }`}
                        >
                            Community Feed
                        </button>
                        <button
                            onClick={() => setActiveTab('friends')}
                            className={`px-6 py-3 rounded-xl font-medium transition-all duration-300 ${
                                activeTab === 'friends' 
                                    ? 'primary-gradient text-white shadow-lg' 
                                    : 'text-gray-400 hover:text-white'
                            }`}
                        >
                            Friends & Network
                        </button>
                    </div>
                </div>

                {/* Tab Content */}
                {activeTab === 'feed' ? (
                    <>
                        {currentUser ? (
                            <CreatePostForm onPostCreated={onDataRefresh} currentUser={currentUser} />
                        ) : (
                            <div className="glass-effect p-6 rounded-2xl text-center mb-8">
                                <p className="text-white">Please <a href="#" onClick={() => User.login()} className="text-cyan-400 font-bold underline">sign in</a> to create a post and join the conversation.</p>
                            </div>
                        )}

                        <div className="space-y-8">
                            {loading ? (
                                 <div className="flex justify-center items-center py-20">
                                    <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
                                </div>
                            ) : posts.length > 0 ? (
                                posts.map(post => (
                                    <PostCard 
                                        key={post.id} 
                                        post={post}
                                        currentUser={currentUser}
                                        initialLikes={likes.filter(l => l.post_id === post.id)}
                                        initialComments={comments.filter(c => c.post_id === post.id)}
                                        onDataRefresh={onDataRefresh}
                                    />
                                ))
                            ) : (
                                <div className="text-center py-20 glass-effect rounded-2xl">
                                    <MessageSquare className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                                    <h3 className="text-2xl font-bold text-white">It's Quiet Here...</h3>
                                    <p className="text-gray-400 mt-2">Be the first to share your thoughts and start a conversation!</p>
                                </div>
                            )}
                        </div>
                    </>
                ) : (
                    currentUser ? (
                        <FriendsList currentUser={currentUser} />
                    ) : (
                        <div className="glass-effect p-6 rounded-2xl text-center">
                            <p className="text-white">Please <a href="#" onClick={() => User.login()} className="text-cyan-400 font-bold underline">sign in</a> to manage your friends and network.</p>
                        </div>
                    )
                )}
            </div>
        </div>
    );
}
