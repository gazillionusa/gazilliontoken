
import React, { useState, useEffect, useCallback } from 'react';
import { UserPurchase } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ExternalLink, 
  Calendar, 
  DollarSign, 
  Hash, 
  Award,
  TrendingUp,
  Wallet,
  Clock
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from "sonner";

export default function PurchaseHistoryCard({ user }) {
    const [purchases, setPurchases] = useState([]);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        totalInvested: 0,
        totalRewards: 0,
        bondCount: 0
    });

    const loadPurchaseHistory = useCallback(async () => {
        try {
            // Ensure user and user.id exist before making the call
            if (!user || !user.id) {
                console.warn("User object or user ID is missing, cannot load purchase history.");
                setLoading(false);
                return;
            }
            const userPurchases = await UserPurchase.filter({ user_id: user.id }, '-purchase_timestamp');
            setPurchases(userPurchases);

            // Calculate stats
            const totalInvested = userPurchases.reduce((sum, p) => sum + p.purchase_amount, 0);
            const totalRewards = userPurchases.reduce((sum, p) => sum + (p.civic_rewards_earned || 0), 0);
            const bondCount = userPurchases.length;

            setStats({ totalInvested, totalRewards, bondCount });

        } catch (error) {
            console.error("Failed to load purchase history:", error);
            toast.error("Could not load purchase history.");
        } finally {
            setLoading(false);
        }
    }, [user]); // `user` is a dependency because `user.id` is used inside

    useEffect(() => {
        if (user) {
            loadPurchaseHistory();
        }
    }, [user, loadPurchaseHistory]); // `loadPurchaseHistory` is a dependency now, and `user` is needed for the initial check

    const getExplorerUrl = (txHash) => {
        // Default to Ethereum mainnet - adjust based on your network
        return `https://etherscan.io/tx/${txHash}`;
    };

    if (loading) {
        return (
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardContent className="p-6 text-center">
                    <div className="animate-spin w-8 h-8 border-2 border-cyan-400/20 border-t-cyan-400 rounded-full mx-auto"></div>
                    <p className="text-gray-400 mt-2">Loading purchase history...</p>
                </CardContent>
            </Card>
        );
    }

    return (
        <div className="space-y-6">
            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <div className="flex items-center justify-center mb-2">
                            <DollarSign className="w-8 h-8 text-green-400" />
                        </div>
                        <p className="text-2xl font-bold text-white">${stats.totalInvested.toLocaleString()}</p>
                        <p className="text-gray-400 text-sm">Total Invested</p>
                    </CardContent>
                </Card>

                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <div className="flex items-center justify-center mb-2">
                            <Award className="w-8 h-8 text-amber-400" />
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.totalRewards.toLocaleString()}</p>
                        <p className="text-gray-400 text-sm">Civic Rewards</p>
                    </CardContent>
                </Card>

                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <div className="flex items-center justify-center mb-2">
                            <Hash className="w-8 h-8 text-cyan-400" />
                        </div>
                        <p className="text-2xl font-bold text-white">{stats.bondCount}</p>
                        <p className="text-gray-400 text-sm">NFT Bonds Owned</p>
                    </CardContent>
                </Card>
            </div>

            {/* Purchase History */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <TrendingUp className="w-5 h-5" />
                        NFT Bond Purchase History
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {purchases.length === 0 ? (
                        <div className="text-center py-8">
                            <Wallet className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No Purchases Yet</h3>
                            <p className="text-gray-400">Your NFT bond purchases will appear here once you make your first investment.</p>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {purchases.map((purchase) => (
                                <div key={purchase.id} className="glass-effect p-4 rounded-lg border border-white/5">
                                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                                        <div className="flex-1">
                                            <div className="flex items-center gap-2 mb-2">
                                                <h4 className="text-white font-semibold">{purchase.bond_name}</h4>
                                                <Badge 
                                                    variant="outline" 
                                                    className={`text-xs ${
                                                        purchase.status === 'confirmed' 
                                                            ? 'text-green-400 border-green-400/20' 
                                                            : purchase.status === 'pending'
                                                            ? 'text-yellow-400 border-yellow-400/20'
                                                            : 'text-red-400 border-red-400/20'
                                                    }`}
                                                >
                                                    {purchase.status}
                                                </Badge>
                                            </div>
                                            
                                            <div className="grid grid-cols-2 gap-4 text-sm">
                                                <div className="flex items-center gap-2 text-gray-400">
                                                    <DollarSign className="w-4 h-4" />
                                                    <span>${purchase.purchase_amount.toLocaleString()}</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-gray-400">
                                                    <Award className="w-4 h-4" />
                                                    <span>{purchase.civic_rewards_earned || 0} rewards</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-gray-400">
                                                    <Calendar className="w-4 h-4" />
                                                    <span>{format(new Date(purchase.purchase_timestamp), 'MMM dd, yyyy')}</span>
                                                </div>
                                                <div className="flex items-center gap-2 text-gray-400">
                                                    <Clock className="w-4 h-4" />
                                                    <span>{format(new Date(purchase.purchase_timestamp), 'HH:mm')}</span>
                                                </div>
                                            </div>
                                            
                                            {purchase.nft_token_id && (
                                                <div className="mt-2">
                                                    <p className="text-xs text-gray-500">NFT Token ID:</p>
                                                    <p className="font-mono text-xs text-cyan-400 break-all">
                                                        {purchase.nft_token_id}
                                                    </p>
                                                </div>
                                            )}
                                        </div>
                                        
                                        <div className="flex gap-2">
                                            {purchase.transaction_hash && (
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    className="text-xs"
                                                    onClick={() => window.open(getExplorerUrl(purchase.transaction_hash), '_blank')}
                                                >
                                                    <ExternalLink className="w-3 h-3 mr-1" />
                                                    View on Etherscan
                                                </Button>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
