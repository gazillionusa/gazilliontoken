import { useState, useEffect } from 'react';

/**
 * A reusable hook to manage connection to a browser wallet (e.g., MetaMask).
 * This hook does NOT use the ethers.js library on the frontend, as it is not
 * available in this environment. It interacts directly with the window.ethereum provider.
 */
export function useGazillionWallet() {
  const [provider, setProvider] = useState(null);
  const [account, setAccount] = useState(null);
  const [chainId, setChainId] = useState(null);
  const [error, setError] = useState(null);

  const connectWallet = async () => {
    setError(null);
    if (typeof window !== "undefined" && window.ethereum) {
      try {
        const p = window.ethereum;
        setProvider(p);

        const accounts = await p.request({ method: 'eth_requestAccounts' });
        if (accounts.length > 0) {
          setAccount(accounts[0]);
          localStorage.setItem("gazillion_wallet", accounts[0]);
        }

        const currentChainId = await p.request({ method: 'eth_chainId' });
        setChainId(currentChainId);
        localStorage.setItem("gazillion_chainId", currentChainId);

      } catch (e) {
        const friendlyError = "User rejected the connection request.";
        setError(friendlyError);
        console.error("Wallet connection error:", e);
      }
    } else {
      const friendlyError = "No wallet provider found. Please install MetaMask or another Web3 wallet.";
      setError(friendlyError);
    }
  };

  useEffect(() => {
    // Attempt to connect if a wallet was previously connected
    const previouslyConnected = localStorage.getItem("gazillion_wallet");
    if (previouslyConnected && window.ethereum) {
        connectWallet();
    }

    if (window.ethereum) {
      const handleAccountsChanged = (accounts) => {
        if (accounts.length > 0) {
          setAccount(accounts[0]);
          localStorage.setItem("gazillion_wallet", accounts[0]);
        } else {
          setAccount(null);
          localStorage.removeItem("gazillion_wallet");
          localStorage.removeItem("gazillion_chainId");
        }
      };

      const handleChainChanged = (newChainId) => {
        setChainId(newChainId);
        localStorage.setItem("gazillion_chainId", newChainId);
        // MetaMask recommends reloading the page on chain changes
        window.location.reload();
      };

      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);

      // Cleanup listeners on component unmount
      return () => {
        if (window.ethereum.removeListener) {
            window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
            window.ethereum.removeListener('chainChanged', handleChainChanged);
        }
      };
    }
  }, []);

  return { provider, account, chainId, error, connectWallet };
}