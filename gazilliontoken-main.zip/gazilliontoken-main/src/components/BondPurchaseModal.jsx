
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User } from "@/api/entities";
import { createPaymentIntent } from "@/api/functions";
import { confirmPayment } from "@/api/functions";
import { generateBondCertificate } from "@/api/functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  X,
  Wallet,
  Sparkles,
  CheckCircle,
  Copy,
  ExternalLink,
  RefreshCw,
  Shield,
  AlertTriangle,
  Info,
  User as UserIcon,
  Download,
  FileText
} from "lucide-react";
import { toast } from "sonner";

export default function BondPurchaseModal({ bond, isOpen, onClose, onPurchaseComplete }) {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1: Payment Form, 2: Processing, 3: Success
  const [isProcessing, setIsProcessing] = useState(false);
  const [purchaseData, setPurchaseData] = useState({
    fullName: "",
    email: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    // Card info removed as Stripe is no longer used
  });
  const [mintedData, setMintedData] = useState(null);
  const [error, setError] = useState("");
  const [isGeneratingCert, setIsGeneratingCert] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setStep(1);
      setError("");
      setMintedData(null);
      setIsProcessing(false);
      setIsGeneratingCert(false); // Reset certificate generation state
      // Keep existing form data when reopening
    }
  }, [isOpen, bond]);

  if (!isOpen || !bond) return null;

  const handleInputChange = (field, value) => {
    setPurchaseData(prev => ({ ...prev, [field]: value }));
  };

  const handleCompletePurchase = async (e) => {
    e.preventDefault();
    setError("");
    setIsProcessing(true);
    setStep(2); // Show processing screen

    try {
      // Get current user
      const user = await User.me();

      // Create a *simulated* payment intent
      const paymentResponse = await createPaymentIntent({
        bondId: bond.id,
        amount: bond.current_price,
        bondName: bond.bond_name,
        email: purchaseData.email,
        customerInfo: {
          name: purchaseData.fullName,
          email: purchaseData.email,
          address: {
            line1: purchaseData.address,
            city: purchaseData.city,
            state: purchaseData.state,
            postal_code: purchaseData.zipCode,
            country: 'US'
          }
        }
      });

      if (paymentResponse.data.error) {
        throw new Error(paymentResponse.data.details || paymentResponse.data.error);
      }

      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Confirm payment and mint NFT
      const confirmResponse = await confirmPayment({
        paymentIntentId: paymentResponse.data.paymentIntentId,
        bondData: bond,
        customerInfo: purchaseData
      });

      if (confirmResponse.data.error) {
        throw new Error(confirmResponse.data.details || confirmResponse.data.error);
      }

      setMintedData(confirmResponse.data);
      setStep(3); // Success

      if (onPurchaseComplete) {
        onPurchaseComplete(bond, confirmResponse.data);
      }

    } catch (error) {
      if (error.message?.includes("not authenticated")) {
        await User.login();
      } else {
        setError(`Purchase failed: ${error.message}`);
        setStep(1); // Back to form
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadCertificate = async () => {
    if (!bond) return;

    setIsGeneratingCert(true);
    toast.info("Generating your bond certificate...");

    try {
      // Assuming generateBondCertificate returns an AxiosResponse-like object
      // where data is the Blob for success (status 200)
      // and data is an object { error: string } for failure.
      const response = await generateBondCertificate({ bondId: bond.id });

      if (response.status === 200) {
        const blob = response.data; // Assuming response.data is already the blob
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Gazillion_Bond_Certificate_${bond.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        window.URL.revokeObjectURL(url);
        toast.success("Certificate downloaded successfully!");
      } else {
        // For non-200 status, assume response.data might contain an error object.
        // The outline had `(await response.data())?.error` which is ambiguous;
        // interpreting it as `response.data?.error` if data is already parsed JSON.
        throw new Error(response.data?.error || 'Failed to generate certificate.');
      }
    } catch (error) {
      console.error("Certificate generation failed:", error);
      toast.error(`Certificate generation failed: ${error.message || String(error)}`);
    } finally {
      setIsGeneratingCert(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="glass-effect border-white/10 bg-transparent max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="text-white text-2xl">
              {step === 1 && "Complete Your Purchase"}
              {step === 2 && "Processing Payment..."}
              {step === 3 && "Purchase Complete!"}
            </CardTitle>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white">
              <X className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {error && (
            <div className="glass-effect p-4 rounded-lg border border-red-400/20 bg-red-400/5">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-red-300 font-semibold">Purchase Error</p>
                  <p className="text-red-400 text-sm mt-1">{error}</p>
                </div>
              </div>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-6">
              {/* Bond Summary */}
              <div className="glass-effect p-6 rounded-lg border border-cyan-400/20">
                <div className="flex items-center gap-3 mb-4">
                  <h3 className="text-white font-semibold text-lg">{bond.bond_name}</h3>
                  {bond.is_government_guaranteed && (
                    <Badge className="bg-green-600 text-white flex items-center gap-1">
                      <Shield className="w-3 h-3" />
                      Gov't Guaranteed
                    </Badge>
                  )}
                </div>
                <p className="text-gray-400 mb-4">{bond.municipality}</p>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Purchase Price:</span>
                  <span className="text-3xl font-bold text-white">${bond.current_price?.toLocaleString()}</span>
                </div>
              </div>

              {/* Payment Form */}
              <form onSubmit={handleCompletePurchase} className="space-y-6">
                {/* Personal Information */}
                <div className="space-y-4">
                  <h4 className="text-white font-semibold flex items-center">
                    <UserIcon className="w-5 h-5 mr-2" />
                    Personal Information
                  </h4>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-white">Full Name *</Label>
                      <Input
                        value={purchaseData.fullName}
                        onChange={(e) => handleInputChange('fullName', e.target.value)}
                        className="glass-effect border-white/20 bg-transparent text-white"
                        placeholder="John Doe"
                        required
                      />
                    </div>
                    <div>
                      <Label className="text-white">Email Address *</Label>
                      <Input
                        type="email"
                        value={purchaseData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="glass-effect border-white/20 bg-transparent text-white"
                        placeholder="john@email.com"
                        required
                      />
                    </div>
                  </div>
                </div>

                {/* Billing Address */}
                <div className="space-y-4">
                  <h4 className="text-white font-semibold">Billing Address</h4>
                  <div>
                    <Label className="text-white">Street Address</Label>
                    <Input
                      value={purchaseData.address}
                      onChange={(e) => handleInputChange('address', e.target.value)}
                      className="glass-effect border-white/20 bg-transparent text-white"
                      placeholder="123 Main Street"
                    />
                  </div>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label className="text-white">City</Label>
                      <Input
                        value={purchaseData.city}
                        onChange={(e) => handleInputChange('city', e.target.value)}
                        className="glass-effect border-white/20 bg-transparent text-white"
                        placeholder="New York"
                      />
                    </div>
                    <div>
                      <Label className="text-white">State</Label>
                      <Input
                        value={purchaseData.state}
                        onChange={(e) => handleInputChange('state', e.target.value)}
                        className="glass-effect border-white/20 bg-transparent text-white"
                        placeholder="NY"
                      />
                    </div>
                    <div>
                      <Label className="text-white">ZIP Code</Label>
                      <Input
                        value={purchaseData.zipCode}
                        onChange={(e) => handleInputChange('zipCode', e.target.value)}
                        className="glass-effect border-white/20 bg-transparent text-white"
                        placeholder="10001"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Information section removed */}

                <div className="glass-effect p-4 rounded-lg border border-cyan-400/20 bg-cyan-400/5">
                  <div className="flex items-center gap-3">
                    <Info className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-cyan-300 font-semibold">Ready to Invest?</p>
                      <p className="text-gray-400 text-sm mt-1">
                        Click "Complete Purchase" to finalize your investment. Payment processing is currently simulated.
                      </p>
                    </div>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full primary-gradient text-white font-semibold py-4 text-lg rounded-full"
                >
                  <Wallet className="w-5 h-5 mr-2" />
                  Complete Purchase - ${bond.current_price?.toLocaleString()}
                </Button>
              </form>
            </div>
          )}

          {step === 2 && (
            <div className="text-center space-y-6 py-8">
              <div className="relative w-24 h-24 mx-auto">
                <div className="absolute inset-0 primary-gradient rounded-full animate-spin"></div>
                <div className="absolute inset-1.5 bg-slate-800 rounded-full flex items-center justify-center">
                  <Sparkles className="w-10 h-10 text-white" />
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-bold text-white">Processing Your Purchase</h3>
                <p className="text-gray-400">
                  Payment confirmed! Generating your NFT bond...
                </p>
              </div>
            </div>
          )}

          {step === 3 && mintedData && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Purchase Complete!</h3>
                <p className="text-gray-400">Your municipal bond NFT has been minted successfully.</p>
              </div>

              <div className="glass-effect p-6 rounded-lg space-y-4">
                 <div className="flex items-center justify-center text-center p-8 border border-dashed border-cyan-400/30 rounded-lg bg-cyan-500/5">
                    <div className="space-y-4">
                      <FileText className="w-16 h-16 text-cyan-400 mx-auto" />
                      <h4 className="text-white font-semibold">Your NFT Certificate is Ready</h4>
                      <p className="text-gray-400 text-sm">Download your official proof of ownership. This document contains the blockchain details for your records.</p>
                      <Button onClick={handleDownloadCertificate} disabled={isGeneratingCert} className="primary-gradient text-white">
                        <Download className={`w-4 h-4 mr-2 ${isGeneratingCert ? 'animate-spin' : ''}`} />
                        {isGeneratingCert ? 'Generating...' : 'Download Certificate'}
                      </Button>
                    </div>
                </div>

                <div className="space-y-2 pt-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Token ID:</span>
                    <div className="flex items-center gap-2">
                      <span className="text-white font-mono text-sm">{mintedData.tokenId?.substring(0, 10)}...</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          navigator.clipboard.writeText(mintedData.tokenId);
                          toast.success("Token ID Copied!");
                        }}
                        className="w-6 h-6 text-gray-400"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Transaction Hash:</span>
                     <div className="flex items-center gap-2">
                        <span className="text-white font-mono text-sm">{mintedData.transactionHash?.substring(0, 10)}...</span>
                        <Button
                          variant="ghost"
                          size="icon"
                           onClick={() => {
                            navigator.clipboard.writeText(mintedData.transactionHash);
                            toast.success("Transaction Hash Copied!");
                          }}
                          className="w-6 h-6 text-gray-400"
                        >
                          <Copy className="w-3 h-3" />
                        </Button>
                      </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={() => navigate(createPageUrl("Dashboard"))}
                  className="flex-1 primary-gradient text-white"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View in Portfolio
                </Button>
                <Button
                  onClick={onClose}
                  variant="outline"
                  className="flex-1 glass-effect text-white border-white/30"
                >
                  Close
                </Button>
              </div>

              <div className="glass-effect p-4 rounded-lg border border-green-400/20 bg-green-400/5">
                <div className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <div>
                    <p className="text-green-300 font-medium">Confirmation Email Sent!</p>
                    <p className="text-gray-400 text-sm">Receipt and NFT details sent to {purchaseData.email}.</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
