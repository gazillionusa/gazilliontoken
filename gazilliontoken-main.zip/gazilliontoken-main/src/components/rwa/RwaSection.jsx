
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Briefcase, DollarSign, Globe, Layers, Lightbulb, Users } from 'lucide-react';

export default function RwaSection() {
  const marketStats = [
  {
    icon: <DollarSign className="w-8 h-8 text-cyan-400 mb-3" />,
    title: "Market Size",
    value: "$5–10B",
    description: "Already tokenized as of 2024"
  },
  {
    icon: <BarChart className="w-8 h-8 text-green-400 mb-3" />,
    title: "Projected Growth",
    value: "$4–16T",
    description: "Tokenized assets by 2030 (Citi, BCG)"
  },
  {
    icon: <Briefcase className="w-8 h-8 text-purple-400 mb-3" />,
    title: "Muni Bond Market",
    value: "$4T+",
    description: "Total value of the U.S. Municipal Bond Market"
  }];


  const rwaCategories = [
  "Bonds (treasuries, municipal, corporate)",
  "Real Estate (fractional property ownership)",
  "Commodities (gold, carbon credits, energy)",
  "Private Credit & Invoices",
  "Equities & Funds"];


  const whyItMatters = [
  {
    icon: <Users className="w-5 h-5 text-cyan-400" />,
    text: "Fractional ownership lets anyone invest with as little as $100."
  },
  {
    icon: <Globe className="w-5 h-5 text-cyan-400" />,
    text: "Bonds can trade globally, 24/7, with lower fees."
  },
  {
    icon: <DollarSign className="w-5 h-5 text-cyan-400" />,
    text: "Cities and nonprofits save money on bond issuance."
  },
  {
    icon: <Layers className="w-5 h-5 text-cyan-400" />,
    text: "Industry Validation: Major financial institutions are embracing RWA tokenization, signaling a market shift."
  }];


  return (
    <div className="py-12 md:py-20 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4"> The RWA Tokenization Sector

          </h2>
            <p className="text-lg text-gray-300 leading-relaxed max-w-3xl mx-auto">
              Real-World Asset (RWA) tokenization is the process of bringing traditional financial assets—such as bonds, real estate, and commodities—onto the blockchain as digital tokens. This makes them more liquid, accessible, and tradeable worldwide, 24/7.
            </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
            {marketStats.map((stat) =>
          <Card key={stat.title} className="glass-effect text-center">
                    <CardContent className="p-6">
                        {stat.icon}
                        <p className="text-3xl font-bold text-white">{stat.value}</p>
                        <p className="text-sm text-gray-400 mt-1">{stat.description}</p>
                    </CardContent>
                </Card>
          )}
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 items-center mb-16">
            <Card className="glass-effect">
                <CardContent className="p-6">
                    <h3 className="text-2xl font-bold text-white mb-4">Major Categories of Tokenized RWAs</h3>
                    <ul className="space-y-3">
                        {rwaCategories.map((category) =>
                <li key={category} className="flex items-start">
                                <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2 mr-3 shrink-0"></div>
                                <span className="text-gray-300">{category}</span>
                            </li>
                )}
                    </ul>
                </CardContent>
            </Card>

            <div className="text-center md:text-left">
                <h3 className="text-3xl font-bold text-white mb-4">Where Gazillion Fits In</h3>
                <p className="text-lg text-gray-300 leading-relaxed">
                    Gazillion is focused on <strong>municipal bonds</strong>, represented through <strong>NFTs</strong>. Each bond NFT carries key metadata—face value, maturity, coupon rate—enabling transparency, programmability, and accessibility for global investors. This unlocks fractional ownership, lowers costs for municipalities, and creates new opportunities for communities to fund infrastructure projects.
                </p>
            </div>
        </div>

        <div className="my-16 text-center">
          <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/12888ef84_output.png" alt="Gazillion RWA Sector Map" className="w-full max-w-4xl mx-auto rounded-lg shadow-2xl border border-white/10" />
          <p className="text-sm text-gray-500 mt-4">
            Gazillion is positioned in the RWA Tokenization market—leading the way in NFT-based municipal bonds.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 items-center mb-16">
            <div>
                <h3 className="text-3xl font-bold text-white mb-6">Why This Matters</h3>
                <ul className="space-y-4">
                    {whyItMatters.map((item) =>
              <li key={item.text} className="flex items-start gap-3">
                            <div className="p-2 bg-cyan-400/10 rounded-full mt-1">{item.icon}</div>
                            <span className="text-gray-300 flex-1">{item.text}</span>
                        </li>
              )}
                </ul>
            </div>
             <Card className="glass-effect">
                <CardContent className="p-8">
                    <Lightbulb className="w-10 h-10 text-amber-400 mb-4" />
                    <h3 className="text-2xl font-bold text-white mb-4">Summary</h3>
                    <p className="text-lg text-white leading-relaxed">
                        Gazillion is positioned in a massive, untapped niche—<span className="font-bold text-amber-400">municipal bonds</span>. By tokenizing bonds as NFTs, we’re redefining community and infrastructure funding, with the potential to become a billion-dollar leader in the RWA sector.
                    </p>
                </CardContent>
            </Card>
        </div>
      </div>
    </div>);

}
