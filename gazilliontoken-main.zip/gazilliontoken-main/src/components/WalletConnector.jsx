import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Wallet, Check, AlertCircle, ExternalLink } from 'lucide-react';
import { toast } from "sonner";
import { User } from '@/api/entities';
import { connectWallet } from '@/api/functions';

export default function WalletConnector({ user, onWalletConnected }) {
    const [isConnecting, setIsConnecting] = useState(false);
    const [walletAddress, setWalletAddress] = useState(user?.wallet_address || '');
    const [isConnected, setIsConnected] = useState(!!user?.wallet_address);

    useEffect(() => {
        setWalletAddress(user?.wallet_address || '');
        setIsConnected(!!user?.wallet_address);
    }, [user]);

    const handleConnectMetaMask = async () => {
        if (typeof window.ethereum === 'undefined') {
            toast.error('MetaMask is not installed. Please install MetaMask to connect your wallet.');
            window.open('https://metamask.io/download/', '_blank');
            return;
        }

        setIsConnecting(true);
        
        try {
            // Request account access
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });
            
            const address = accounts[0];
            
            // Get network info
            const chainId = await window.ethereum.request({
                method: 'eth_chainId'
            });

            // Connect wallet via our backend function
            const response = await connectWallet({
                walletAddress: address,
                walletType: 'MetaMask',
                chainId: chainId
            });

            if (response.data.success) {
                setWalletAddress(address);
                setIsConnected(true);
                toast.success('Wallet connected successfully!');
                
                if (onWalletConnected) {
                    onWalletConnected(address);
                }
            } else {
                throw new Error(response.data.error || 'Failed to connect wallet');
            }

        } catch (error) {
            console.error('Wallet connection error:', error);
            toast.error(`Failed to connect wallet: ${error.message}`);
        } finally {
            setIsConnecting(false);
        }
    };

    const handleDisconnectWallet = async () => {
        try {
            await User.updateMyUserData({
                wallet_address: null,
                wallet_type: null,
                wallet_connected_at: null,
                has_connected_external_wallet: false
            });
            
            setWalletAddress('');
            setIsConnected(false);
            toast.success('Wallet disconnected successfully!');
            
            if (onWalletConnected) {
                onWalletConnected(null);
            }
        } catch (error) {
            console.error('Wallet disconnect error:', error);
            toast.error('Failed to disconnect wallet');
        }
    };

    if (isConnected && walletAddress) {
        return (
            <Card className="glass-effect border-green-400/20 bg-green-400/5">
                <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
                                <Check className="w-5 h-5 text-white" />
                            </div>
                            <div>
                                <p className="text-white font-semibold">Wallet Connected</p>
                                <p className="text-gray-400 text-sm font-mono">
                                    {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
                                </p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={() => navigator.clipboard.writeText(walletAddress)}
                                className="text-xs"
                            >
                                Copy
                            </Button>
                            <Button
                                variant="outline"
                                size="sm"
                                onClick={handleDisconnectWallet}
                                className="text-xs text-red-400 border-red-400/20 hover:bg-red-400/10"
                            >
                                Disconnect
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="glass-effect border-white/10 bg-transparent">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Wallet className="w-5 h-5" />
                    Connect Web3 Wallet
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p className="text-gray-400 text-sm">
                    Connect your wallet to track NFT bond purchases and unlock civic rewards in your Zoo Keeper profile.
                </p>
                
                <Button
                    onClick={handleConnectMetaMask}
                    disabled={isConnecting}
                    className="w-full primary-gradient text-white font-semibold"
                >
                    {isConnecting ? (
                        <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                            Connecting...
                        </div>
                    ) : (
                        <div className="flex items-center gap-2">
                            <img src="https://upload.wikimedia.org/wikipedia/commons/3/36/MetaMask_Fox.svg" alt="MetaMask" className="w-5 h-5" />
                            Connect MetaMask
                        </div>
                    )}
                </Button>

                <div className="flex items-center gap-2 text-xs text-gray-400">
                    <AlertCircle className="w-4 h-4" />
                    <span>Secure connection via MetaMask. Your keys never leave your wallet.</span>
                </div>
            </CardContent>
        </Card>
    );
}