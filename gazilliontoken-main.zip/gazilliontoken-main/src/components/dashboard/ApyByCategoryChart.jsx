import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import _ from 'lodash';

export default function ApyByCategoryChart({ bonds }) {
  const data = _.chain(bonds)
    .groupBy('category')
    .map((value, key) => ({
      name: _.startCase(key.replace('_', ' ')),
      apy: _.meanBy(value, 'apy'),
    }))
    .value();
    
  const formatPercent = (value) => `${value.toFixed(1)}%`;

  return (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <CardTitle className="text-white text-xl">Average APY by Category</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={data} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
            <XAxis dataKey="name" stroke="#A0AEC0" tick={{ fill: '#A0AEC0' }} />
            <YAxis stroke="#A0AEC0" tickFormatter={formatPercent} tick={{ fill: '#A0AEC0' }} />
            <Tooltip
              cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }}
              contentStyle={{
                background: 'rgba(15, 23, 42, 0.9)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '0.75rem'
              }}
              formatter={(value) => `${value.toFixed(2)}%`}
              labelStyle={{ color: '#ffffff' }}
            />
            <Legend />
            <Bar dataKey="apy" name="Average APY" fill="#80CBC4" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}