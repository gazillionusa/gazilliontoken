import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Download, CheckCircle, Clock } from 'lucide-react';
import { formatDistanceToNow, isAfter } from 'date-fns';
import { redeemSavingsBond } from '@/api/functions';
import { toast } from 'sonner';

export default function SavingsBondCard({ bond, onRedeem }) {
    const [isRedeeming, setIsRedeeming] = useState(false);
    const [isMatured, setIsMatured] = useState(false);
    const [timeToMaturity, setTimeToMaturity] = useState('');

    useEffect(() => {
        const maturityDate = new Date(bond.maturity_date);
        const now = new Date();

        if (isAfter(now, maturityDate)) {
            setIsMatured(true);
            setTimeToMaturity('Matured');
        } else {
            const interval = setInterval(() => {
                setTimeToMaturity(formatDistanceToNow(maturityDate, { addSuffix: true }));
            }, 1000);
            return () => clearInterval(interval);
        }
    }, [bond.maturity_date]);
    
    const handleRedeem = async () => {
        setIsRedeeming(true);
        try {
            const updatedBond = await redeemSavingsBond({ userSavingsBondId: bond.id });
            toast.success("Bond Redeemed!", { description: "The funds have been credited to your account (simulation)." });
            onRedeem(updatedBond); // Notify parent to update state
        } catch (error) {
            toast.error("Redemption Failed", { description: error.message });
        } finally {
            setIsRedeeming(false);
        }
    };
    
    const handleDownload = () => {
        window.open(bond.certificate_image_url, '_blank');
    };

    const isRedeemed = bond.status === 'redeemed';

    return (
        <Card className="glass-effect border-white/10 bg-transparent overflow-hidden">
            <CardContent className="p-4 flex flex-col md:flex-row gap-4">
                <div className="relative md:w-1/3 flex-shrink-0">
                    <img src={bond.certificate_image_url} alt={`Savings Bond ${bond.id}`} className="rounded-lg w-full object-cover" />
                    {isRedeemed && (
                         <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center rounded-lg">
                             <CheckCircle className="w-16 h-16 text-green-400 mb-2" />
                             <p className="text-2xl font-bold text-white">REDEEMED</p>
                        </div>
                    )}
                </div>

                <div className="flex-grow flex flex-col justify-between">
                    <div>
                        <div className="flex justify-between items-start">
                            <h3 className="text-xl font-bold text-white">{bond.bond_details.name}</h3>
                            <Badge className={`${isRedeemed ? 'bg-gray-500' : isMatured ? 'bg-green-500' : 'bg-blue-500'} text-white`}>
                                {isRedeemed ? 'Redeemed' : isMatured ? 'Matured' : 'Active'}
                            </Badge>
                        </div>
                        <p className="text-gray-400 text-sm">Denomination: ${bond.bond_details.denomination} @ {bond.bond_details.interest_rate}% APR</p>
                        <div className="mt-4 space-y-2 text-sm">
                            <p className="flex justify-between">
                                <span className="text-gray-400">Issue Date:</span>
                                <span className="text-white">{new Date(bond.issue_date).toLocaleDateString()}</span>
                            </p>
                            <p className="flex justify-between">
                                <span className="text-gray-400">Maturity Date:</span>
                                <span className="text-white">{new Date(bond.maturity_date).toLocaleDateString()}</span>
                            </p>
                            <p className="flex justify-between items-center">
                                <span className="text-gray-400">Time Remaining:</span>
                                 <span className={`font-semibold ${isMatured ? 'text-green-400' : 'text-cyan-400'}`}>
                                    {timeToMaturity}
                                 </span>
                            </p>
                        </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                        <Button 
                            variant="outline" 
                            className="w-full border-white/20 hover:bg-white/10"
                            onClick={handleDownload}
                        >
                            <Download className="w-4 h-4 mr-2" /> Download
                        </Button>
                         <Button 
                            className="w-full primary-gradient"
                            disabled={!isMatured || isRedeemed || isRedeeming}
                            onClick={handleRedeem}
                        >
                            {isRedeeming ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Redeem'}
                        </Button>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}