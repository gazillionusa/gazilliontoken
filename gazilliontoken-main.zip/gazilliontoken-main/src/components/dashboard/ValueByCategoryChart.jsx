import React from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import _ from 'lodash';

export default function ValueByCategoryChart({ bonds }) {
  const data = _.chain(bonds)
    .groupBy('category')
    .map((value, key) => ({
      name: _.startCase(key.replace('_', ' ')),
      value: _.sumBy(value, 'current_price'),
    }))
    .value();

  const formatCurrency = (value) => `$${(value / 1000).toFixed(0)}k`;

  return (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <CardTitle className="text-white text-xl">Total Value by Category</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={data} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
            <XAxis dataKey="name" stroke="#A0AEC0" tick={{ fill: '#A0AEC0' }} />
            <YAxis stroke="#A0AEC0" tickFormatter={formatCurrency} tick={{ fill: '#A0AEC0' }} />
            <Tooltip
              cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }}
              contentStyle={{
                background: 'rgba(15, 23, 42, 0.9)',
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderRadius: '0.75rem'
              }}
              labelStyle={{ color: '#ffffff' }}
            />
            <Legend />
            <Bar dataKey="value" name="Total Value" fill="#4ECDC4" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}