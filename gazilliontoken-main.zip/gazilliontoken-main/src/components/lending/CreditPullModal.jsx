
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Lock, 
  FileText,
  CreditCard,
  TrendingUp,
  X
} from 'lucide-react';
import { creditBureauService } from "@/api/functions";

export default function CreditPullModal({ isOpen, onClose, borrowerId, onCreditPulled }) {
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [consentGiven, setConsentGiven] = useState(false);
  const [pullType, setPullType] = useState('soft_pull');
  const [borrowerInfo, setBorrowerInfo] = useState({
    ssn: '',
    dateOfBirth: '',
    address: '',
    phone: ''
  });
  const [creditResults, setCreditResults] = useState(null);
  const [underwritingResults, setUnderwritingResults] = useState(null);

  const handleBorrowerInfoChange = (field, value) => {
    setBorrowerInfo(prev => ({ ...prev, [field]: value }));
  };

  const handleCreditPull = async () => {
    setIsLoading(true);
    try {
      const response = await creditBureauService({
        action: 'initiate_credit_pull',
        borrower_id: borrowerId,
        request_type: pullType,
        bureaus: ['experian', 'equifax', 'transunion'],
        borrower_info: borrowerInfo
      });

      if (response.data.success) {
        setCreditResults(response.data);
        setStep(3);
        
        // Automatically trigger underwriting
        const underwritingResponse = await creditBureauService({
          action: 'trigger_underwriting',
          credit_request_id: response.data.credit_request_id,
          borrower_id: borrowerId
        });

        if (underwritingResponse.data.success) {
          setUnderwritingResults(underwritingResponse.data);
        }
      } else {
        alert('Failed to pull credit report: ' + response.data.error);
      }
    } catch (error) {
      console.error('Credit pull failed:', error);
      alert('An error occurred while pulling your credit report.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleComplete = () => {
    if (onCreditPulled && underwritingResults) {
      onCreditPulled(underwritingResults);
    }
    onClose();
    resetModal();
  };

  const resetModal = () => {
    setStep(1);
    setConsentGiven(false);
    setBorrowerInfo({ ssn: '', dateOfBirth: '', address: '', phone: '' });
    setCreditResults(null);
    setUnderwritingResults(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Step 1: Credit Pull Type Selection */}
        {step === 1 && (
          <Card className="border-white/10 bg-transparent">
            <CardHeader className="flex flex-row items-center justify-between px-4 sm:px-6">
              <CardTitle className="text-white text-lg sm:text-xl">Credit Report Authorization</CardTitle>
              <Button variant="ghost" size="icon" onClick={onClose} className="flex-shrink-0">
                <X className="w-5 h-5 text-white" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6">
              <div className="space-y-4">
                <h3 className="text-base sm:text-lg font-semibold text-white">Select Credit Pull Type</h3>
                
                <div className="grid gap-4">
                  <label className="flex items-start space-x-3 p-3 sm:p-4 border border-white/20 rounded-lg cursor-pointer hover:bg-white/5">
                    <input
                      type="radio"
                      name="pullType"
                      value="soft_pull"
                      checked={pullType === 'soft_pull'}
                      onChange={(e) => setPullType(e.target.value)}
                      className="mt-1 flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-green-400 flex-shrink-0" />
                        <span className="text-white font-medium text-sm sm:text-base">Soft Credit Pull</span>
                        <Badge className="bg-green-600 text-white text-xs">Recommended</Badge>
                      </div>
                      <p className="text-gray-400 text-xs sm:text-sm mt-1">
                        Will NOT impact your credit score. Used for pre-qualification and rate estimation.
                      </p>
                    </div>
                  </label>

                  <label className="flex items-start space-x-3 p-3 sm:p-4 border border-white/20 rounded-lg cursor-pointer hover:bg-white/5">
                    <input
                      type="radio"
                      name="pullType"
                      value="hard_pull"
                      checked={pullType === 'hard_pull'}
                      onChange={(e) => setPullType(e.target.value)}
                      className="mt-1 flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 text-amber-400 flex-shrink-0" />
                        <span className="text-white font-medium text-sm sm:text-base">Hard Credit Pull</span>
                      </div>
                      <p className="text-gray-400 text-xs sm:text-sm mt-1">
                        May temporarily impact your credit score. Required for final loan approval.
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="flex justify-end">
                <Button 
                  onClick={() => setStep(2)}
                  className="primary-gradient text-white text-sm sm:text-base"
                >
                  Continue
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Borrower Information & Consent */}
        {step === 2 && (
          <Card className="border-white/10 bg-transparent">
            <CardHeader className="px-4 sm:px-6">
              <CardTitle className="text-white text-lg sm:text-xl">Borrower Information & Consent</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label className="text-white text-sm">Social Security Number</Label>
                  <Input
                    type="password"
                    placeholder="XXX-XX-XXXX"
                    value={borrowerInfo.ssn}
                    onChange={(e) => handleBorrowerInfoChange('ssn', e.target.value)}
                    className="glass-effect border-white/20 bg-transparent text-white"
                  />
                </div>
                <div>
                  <Label className="text-white text-sm">Date of Birth</Label>
                  <Input
                    type="date"
                    value={borrowerInfo.dateOfBirth}
                    onChange={(e) => handleBorrowerInfoChange('dateOfBirth', e.target.value)}
                    className="glass-effect border-white/20 bg-transparent text-white"
                  />
                </div>
              </div>

              <div>
                <Label className="text-white text-sm">Current Address</Label>
                <Input
                  placeholder="123 Main St, City, State, ZIP"
                  value={borrowerInfo.address}
                  onChange={(e) => handleBorrowerInfoChange('address', e.target.value)}
                  className="glass-effect border-white/20 bg-transparent text-white"
                />
              </div>

              <div>
                <Label className="text-white text-sm">Phone Number</Label>
                <Input
                  placeholder="(555) 123-4567"
                  value={borrowerInfo.phone}
                  onChange={(e) => handleBorrowerInfoChange('phone', e.target.value)}
                  className="glass-effect border-white/20 bg-transparent text-white"
                />
              </div>

              {/* Disclosure */}
              <div className="bg-slate-700/50 p-3 sm:p-4 rounded-lg">
                <div className="flex items-start space-x-3">
                  <Lock className="w-4 h-4 sm:w-5 sm:h-5 text-cyan-400 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="text-white font-medium mb-2 text-sm sm:text-base">Credit Report Disclosure</h4>
                    <p className="text-gray-300 text-xs sm:text-sm leading-relaxed">
                      By authorizing this {pullType.replace('_', ' ')}, you permit Gazillion to fetch your 
                      credit report from major credit bureaus (Experian, Equifax, and TransUnion) for loan 
                      underwriting purposes. This {pullType === 'hard_pull' ? 'may temporarily impact your credit score' : 'will not impact your credit score'}. 
                      Your credit information will be securely stored and used solely for underwriting and 
                      servicing your loan application. You have the right to request copies of any credit 
                      reports obtained and to dispute any inaccuracies directly with the credit bureaus.
                    </p>
                  </div>
                </div>
              </div>

              {/* Consent Checkbox */}
              <div className="flex items-start space-x-3">
                <Checkbox
                  id="consent"
                  checked={consentGiven}
                  onCheckedChange={setConsentGiven}
                  className="mt-1 flex-shrink-0"
                />
                <label htmlFor="consent" className="text-gray-300 text-xs sm:text-sm cursor-pointer">
                  I have read and agree to the credit report disclosure above. I authorize Gazillion 
                  to obtain my credit report(s) for the purpose of evaluating my loan application.
                </label>
              </div>

              <div className="flex flex-col sm:flex-row justify-between gap-3">
                <Button variant="outline" onClick={() => setStep(1)} className="w-full sm:w-auto">
                  Back
                </Button>
                <Button 
                  onClick={handleCreditPull}
                  disabled={!consentGiven || isLoading || !borrowerInfo.ssn || !borrowerInfo.dateOfBirth}
                  className="primary-gradient text-white w-full sm:w-auto"
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Pulling Credit Report...
                    </div>
                  ) : (
                    'Authorize Credit Pull'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Credit Results & Underwriting Decision */}
        {step === 3 && creditResults && underwritingResults && (
          <Card className="border-white/10 bg-transparent">
            <CardHeader className="px-4 sm:px-6">
              <CardTitle className="text-white text-lg sm:text-xl flex items-center flex-wrap gap-2">
                <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-400 flex-shrink-0" />
                <span>Credit Report & Underwriting Complete</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6 px-4 sm:px-6">
              {/* Credit Score Summary */}
              <div className="grid grid-cols-3 gap-3 sm:gap-4">
                <div className="text-center">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">
                    {creditResults.summary.average_score}
                  </div>
                  <div className="text-gray-400 text-xs sm:text-sm">Average Score</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">
                    {creditResults.summary.credit_utilization}%
                  </div>
                  <div className="text-gray-400 text-xs sm:text-sm">Credit Utilization</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl sm:text-3xl font-bold text-white mb-1">
                    ${creditResults.summary.total_debt?.toLocaleString()}
                  </div>
                  <div className="text-gray-400 text-xs sm:text-sm">Total Debt</div>
                </div>
              </div>

              {/* Bureau Breakdown */}
              <div>
                <h4 className="text-white font-medium mb-3 text-sm sm:text-base">Credit Bureau Scores</h4>
                <div className="grid grid-cols-3 gap-3 sm:gap-4">
                  {creditResults.bureau_scores.map(bureau => (
                    <div key={bureau.bureau} className="bg-slate-700/50 p-2 sm:p-3 rounded-lg text-center">
                      <div className="text-base sm:text-lg font-bold text-white">{bureau.score}</div>
                      <div className="text-gray-400 text-[10px] sm:text-xs capitalize">{bureau.bureau}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Underwriting Decision */}
              <div className="bg-slate-700/50 p-3 sm:p-4 rounded-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                  <h4 className="text-white font-medium text-sm sm:text-base">Underwriting Decision</h4>
                  <Badge 
                    className={
                      underwritingResults.decision.decision === 'approved' 
                        ? 'bg-green-600 text-white'
                        : underwritingResults.decision.decision === 'conditional'
                        ? 'bg-yellow-600 text-white'
                        : 'bg-red-600 text-white'
                    }
                  >
                    {underwritingResults.decision.decision.toUpperCase()}
                  </Badge>
                </div>

                {(underwritingResults.decision.decision === 'approved' || underwritingResults.decision.decision === 'conditional') ? (
                  <div className="grid grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <div className="text-xs sm:text-sm text-gray-400">Maximum Loan Amount</div>
                      <div className="text-xl sm:text-2xl font-bold text-green-400">
                        ${underwritingResults.decision.max_loan_amount?.toLocaleString()}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs sm:text-sm text-gray-400">Interest Rate</div>
                      <div className="text-xl sm:text-2xl font-bold text-green-400">
                        {underwritingResults.decision.interest_rate}%
                      </div>
                    </div>
                    <div>
                      <div className="text-xs sm:text-sm text-gray-400">Risk Grade</div>
                      <div className="text-base sm:text-lg font-bold text-white">
                        {underwritingResults.decision.risk_grade}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs sm:text-sm text-gray-400">Max Term</div>
                      <div className="text-base sm:text-lg font-bold text-white">
                        {underwritingResults.decision.max_term_months} months
                      </div>
                    </div>
                  </div>
                ) : (
                  <div>
                    <h5 className="text-white font-medium mb-2 text-sm">Denial Reasons:</h5>
                    <ul className="list-disc list-inside text-gray-300 space-y-1 text-xs sm:text-sm">
                      {underwritingResults.decision.denial_reasons?.map((reason, index) => (
                        <li key={index}>{reason}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {underwritingResults.decision.conditions && underwritingResults.decision.conditions.length > 0 && (
                  <div className="mt-4">
                    <h5 className="text-white font-medium mb-2 text-sm">Conditions:</h5>
                    <ul className="list-disc list-inside text-gray-300 space-y-1 text-xs sm:text-sm">
                      {underwritingResults.decision.conditions.map((condition, index) => (
                        <li key={index}>{condition}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="flex justify-end">
                <Button onClick={handleComplete} className="primary-gradient text-white w-full sm:w-auto">
                  Continue with Application
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
