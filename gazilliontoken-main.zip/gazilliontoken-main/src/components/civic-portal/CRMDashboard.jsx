
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { CivicContact } from '@/api/entities';
import { 
    Users, 
    Search, 
    Download, 
    Plus,
    Mail,
    Phone,
    Star,
    Filter,
    Loader2,
    UserPlus
} from 'lucide-react';

export default function CRMDashboard({ partner }) {
    const [contacts, setContacts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedFilter, setSelectedFilter] = useState('all');

    const loadContacts = useCallback(async () => {
        if (!partner) {
            setLoading(false); // Ensure loading is set to false even if no partner
            return;
        }
        
        try {
            const contactData = await CivicContact.filter({ partner_id: partner.id }, '-last_interaction_date');
            setContacts(contactData);
        } catch (error) {
            console.error("Failed to load contacts:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]); // `partner` is a dependency for `loadContacts`

    useEffect(() => {
        loadContacts();
    }, [loadContacts]); // `loadContacts` is now a dependency for `useEffect`

    const filteredContacts = contacts.filter(contact => {
        const matchesSearch = contact.contact_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                             contact.contact_email.toLowerCase().includes(searchTerm.toLowerCase());
        
        if (selectedFilter === 'all') return matchesSearch;
        if (selectedFilter === 'high-engagement') return matchesSearch && contact.civic_xp_score > 500;
        if (selectedFilter === 'recent') return matchesSearch && new Date(contact.last_interaction_date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        
        return matchesSearch;
    });

    const getEngagementLevel = (score) => {
        if (score > 1000) return { level: 'High', color: 'bg-green-600' };
        if (score > 500) return { level: 'Medium', color: 'bg-yellow-600' };
        return { level: 'Low', color: 'bg-gray-600' };
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Contact Management</h2>
                    <p className="text-gray-400">Track and manage your community relationships.</p>
                </div>
                <div className="flex space-x-3">
                    <Button variant="outline" className="text-gray-300 border-white/20">
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                    </Button>
                    <Button className="primary-gradient text-white">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Contact
                    </Button>
                </div>
            </div>

            {/* CRM Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { label: "Total Contacts", value: contacts.length, icon: Users, color: "text-cyan-400" },
                    { label: "High Engagement", value: contacts.filter(c => c.civic_xp_score > 1000).length, icon: Star, color: "text-green-400" },
                    { label: "This Week", value: contacts.filter(c => new Date(c.last_interaction_date) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)).length, icon: UserPlus, color: "text-blue-400" },
                    { label: "Avg. XP Score", value: Math.round(contacts.reduce((sum, c) => sum + c.civic_xp_score, 0) / (contacts.length || 1)) || 0, icon: Star, color: "text-purple-400" }
                ].map((stat, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-gray-400 text-sm">{stat.label}</p>
                                    <p className="text-xl font-bold text-white">{stat.value}</p>
                                </div>
                                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Search and Filter */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardContent className="p-4">
                    <div className="flex flex-col md:flex-row gap-4">
                        <div className="relative flex-1">
                            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                            <Input
                                placeholder="Search contacts..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10 glass-effect border-white/20 bg-transparent text-white"
                            />
                        </div>
                        <div className="flex space-x-2">
                            {['all', 'high-engagement', 'recent'].map((filter) => (
                                <Button
                                    key={filter}
                                    variant={selectedFilter === filter ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => setSelectedFilter(filter)}
                                    className={selectedFilter === filter ? "bg-cyan-600 text-white" : "text-gray-300 border-white/20"}
                                >
                                    {filter === 'all' ? 'All' : filter === 'high-engagement' ? 'High Engagement' : 'Recent'}
                                </Button>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Contacts List */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white">Contacts ({filteredContacts.length})</CardTitle>
                </CardHeader>
                <CardContent>
                    {filteredContacts.length === 0 ? (
                        <div className="text-center py-8">
                            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No contacts found</h3>
                            <p className="text-gray-400 mb-4">
                                {contacts.length === 0 ? "Start building your community contact list." : "Try adjusting your search or filter."}
                            </p>
                            {contacts.length === 0 && (
                                <Button className="primary-gradient text-white">
                                    <Plus className="w-4 h-4 mr-2" />
                                    Add First Contact
                                </Button>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {filteredContacts.map((contact) => {
                                const engagement = getEngagementLevel(contact.civic_xp_score);
                                return (
                                    <div key={contact.id} className="border border-white/10 rounded-lg p-4 hover:border-white/20 transition-colors">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center space-x-4">
                                                <div className="w-12 h-12 bg-gradient-to-br from-cyan-400 to-teal-500 rounded-full flex items-center justify-center">
                                                    <span className="text-white font-semibold text-sm">
                                                        {contact.contact_name.charAt(0).toUpperCase()}
                                                    </span>
                                                </div>
                                                <div>
                                                    <h4 className="text-white font-semibold">{contact.contact_name}</h4>
                                                    <div className="flex items-center space-x-4 text-sm text-gray-400">
                                                        <div className="flex items-center">
                                                            <Mail className="w-3 h-3 mr-1" />
                                                            {contact.contact_email}
                                                        </div>
                                                        {contact.contact_phone && (
                                                            <div className="flex items-center">
                                                                <Phone className="w-3 h-3 mr-1" />
                                                                {contact.contact_phone}
                                                            </div>
                                                        )}
                                                    </div>
                                                    {contact.tags && contact.tags.length > 0 && (
                                                        <div className="flex space-x-1 mt-1">
                                                            {contact.tags.slice(0, 3).map((tag, index) => (
                                                                <Badge key={index} variant="outline" className="text-xs">
                                                                    {tag}
                                                                </Badge>
                                                            ))}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <div className="flex items-center space-x-4">
                                                <div className="text-right">
                                                    <div className="text-white font-semibold">{contact.civic_xp_score}</div>
                                                    <div className="text-xs text-gray-500">XP Score</div>
                                                </div>
                                                <Badge className={`${engagement.color} text-white`}>
                                                    {engagement.level}
                                                </Badge>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
