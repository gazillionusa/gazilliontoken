
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CivicEvent } from '@/api/entities';
import { EventRSVP } from '@/api/entities';
import { 
    Plus, 
    Calendar, 
    MapPin, 
    Users, 
    Clock,
    Video,
    Loader2,
    MoreHorizontal
} from 'lucide-react';
import { format, isPast, isFuture } from 'date-fns';

export default function EventsManager({ partner }) {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadEvents = useCallback(async () => {
        if (!partner) return;
        
        try {
            const eventData = await CivicEvent.filter({ partner_id: partner.id }, '-event_date');
            setEvents(eventData);
        } catch (error) {
            console.error("Failed to load events:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]);

    useEffect(() => {
        loadEvents();
    }, [loadEvents]);

    const getEventStatus = (eventDate) => {
        const date = new Date(eventDate);
        if (isPast(date)) return { status: 'completed', color: 'bg-gray-600' };
        if (isFuture(date)) return { status: 'upcoming', color: 'bg-cyan-600' };
        return { status: 'live', color: 'bg-red-600' };
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Events & Gatherings</h2>
                    <p className="text-gray-400">Schedule and manage community events with RSVP tracking.</p>
                </div>
                <Button className="primary-gradient text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    New Event
                </Button>
            </div>

            {/* Event Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { label: "Upcoming Events", value: events.filter(e => isFuture(new Date(e.event_date))).length, icon: Calendar, color: "text-cyan-400" },
                    { label: "Total RSVPs", value: events.reduce((sum, e) => sum + e.current_attendees, 0), icon: Users, color: "text-green-400" },
                    { label: "This Month", value: events.filter(e => {
                        const date = new Date(e.event_date);
                        const now = new Date();
                        return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
                    }).length, icon: Clock, color: "text-blue-400" },
                    { label: "Virtual Events", value: events.filter(e => e.is_virtual).length, icon: Video, color: "text-purple-400" }
                ].map((stat, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-gray-400 text-sm">{stat.label}</p>
                                    <p className="text-xl font-bold text-white">{stat.value}</p>
                                </div>
                                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Events List */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white">All Events</CardTitle>
                </CardHeader>
                <CardContent>
                    {events.length === 0 ? (
                        <div className="text-center py-8">
                            <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No events scheduled</h3>
                            <p className="text-gray-400 mb-4">Create your first event to bring your community together.</p>
                            <Button className="primary-gradient text-white">
                                <Plus className="w-4 h-4 mr-2" />
                                Schedule Event
                            </Button>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {events.map((event) => {
                                const eventStatus = getEventStatus(event.event_date);
                                return (
                                    <div key={event.id} className="border border-white/10 rounded-xl p-4 hover:border-white/20 transition-colors">
                                        <div className="flex items-start justify-between">
                                            <div className="flex items-start space-x-4">
                                                <div className="w-12 h-12 bg-cyan-400/10 rounded-lg flex items-center justify-center flex-shrink-0">
                                                    {event.is_virtual ? 
                                                        <Video className="w-6 h-6 text-cyan-400" /> :
                                                        <MapPin className="w-6 h-6 text-cyan-400" />
                                                    }
                                                </div>
                                                <div className="flex-1">
                                                    <div className="flex items-center space-x-3 mb-2">
                                                        <h4 className="text-white font-semibold">{event.event_name}</h4>
                                                        <Badge className={`${eventStatus.color} text-white text-xs`}>
                                                            {eventStatus.status}
                                                        </Badge>
                                                    </div>
                                                    <p className="text-gray-400 text-sm mb-2">{event.description}</p>
                                                    <div className="flex items-center space-x-6 text-sm">
                                                        <div className="flex items-center text-gray-400">
                                                            <Calendar className="w-4 h-4 mr-2" />
                                                            {format(new Date(event.event_date), 'PPP p')}
                                                        </div>
                                                        <div className="flex items-center text-gray-400">
                                                            <Users className="w-4 h-4 mr-2" />
                                                            {event.current_attendees} / {event.max_attendees || '∞'} RSVPs
                                                        </div>
                                                        {event.xp_reward > 0 && (
                                                            <div className="flex items-center text-yellow-400">
                                                                <span className="text-xs font-semibold">+{event.xp_reward} XP</span>
                                                            </div>
                                                        )}
                                                    </div>
                                                    {event.location && (
                                                        <div className="flex items-center text-gray-500 text-sm mt-1">
                                                            <MapPin className="w-3 h-3 mr-1" />
                                                            {event.location}
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                <MoreHorizontal className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
