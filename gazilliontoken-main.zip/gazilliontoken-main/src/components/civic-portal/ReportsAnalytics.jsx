
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CivicCampaign } from '@/api/entities';
import { CivicContact } from '@/api/entities';
import { 
    TrendingUp, 
    Users, 
    Eye,
    Calendar,
    Download,
    BarChart3,
    PieChart,
    Activity,
    Loader2
} from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, BarChart, Bar, PieChart as RechartsPieChart, Cell, Pie } from 'recharts';

const COLORS = ['#4ECDC4', '#26A69A', '#80CBC4', '#B2DFDB', '#E0F2F1'];

export default function ReportsAnalytics({ partner }) {
    const [loading, setLoading] = useState(true);
    const [timeRange, setTimeRange] = useState('30d');
    const [metrics, setMetrics] = useState({
        totalEngagement: 0,
        campaignReach: 0,
        xpIssued: 0,
        conversionRate: 0,
        topCampaigns: [],
        engagementTrend: [],
        audienceBreakdown: []
    });

    const loadAnalytics = useCallback(async () => {
        if (!partner) {
            setLoading(false);
            return;
        }
        
        try {
            const [campaigns, contacts] = await Promise.all([
                CivicCampaign.filter({ partner_id: partner.id }),
                CivicContact.filter({ partner_id: partner.id })
            ]);

            // Mock analytics data - in production, this would come from actual engagement tracking
            const engagementTrend = [
                { date: '2024-01-01', engagement: 120, campaigns: 2 },
                { date: '2024-01-08', engagement: 180, campaigns: 3 },
                { date: '2024-01-15', engagement: 240, campaigns: 4 },
                { date: '2024-01-22', engagement: 300, campaigns: 5 },
                { date: '2024-01-29', engagement: 280, campaigns: 4 },
            ];

            const audienceBreakdown = [
                { name: 'Local Residents', value: 45, count: contacts.length * 0.45 },
                { name: 'Investors', value: 30, count: contacts.length * 0.30 },
                { name: 'Business Partners', value: 15, count: contacts.length * 0.15 },
                { name: 'Government Officials', value: 10, count: contacts.length * 0.10 },
            ];

            const topCampaigns = campaigns.slice(0, 5).map(c => ({
                name: c.campaign_name,
                participants: c.current_participants || Math.floor(Math.random() * 100),
                xp: c.reward_amount || 0
            }));

            setMetrics({
                totalEngagement: Math.floor(Math.random() * 5000) + 1000,
                campaignReach: Math.floor(Math.random() * 10000) + 2000,
                xpIssued: campaigns.reduce((sum, c) => sum + (c.reward_amount || 0), 0),
                conversionRate: Math.round((Math.random() * 15 + 5) * 100) / 100,
                topCampaigns,
                engagementTrend,
                audienceBreakdown
            });

        } catch (error) {
            console.error("Failed to load analytics:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]);

    useEffect(() => {
        loadAnalytics();
    }, [loadAnalytics, timeRange]);

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Reports & Analytics</h2>
                    <p className="text-gray-400">Track your civic engagement performance and community impact.</p>
                </div>
                <div className="flex items-center space-x-3">
                    <Select value={timeRange} onValueChange={setTimeRange}>
                        <SelectTrigger className="glass-effect text-white border-white/20 w-32">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-slate-800 text-white border-white/20">
                            <SelectItem value="7d">Last 7 Days</SelectItem>
                            <SelectItem value="30d">Last 30 Days</SelectItem>
                            <SelectItem value="90d">Last 90 Days</SelectItem>
                            <SelectItem value="1y">Last Year</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button variant="outline" className="text-gray-300 border-white/20">
                        <Download className="w-4 h-4 mr-2" />
                        Export
                    </Button>
                </div>
            </div>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { 
                        label: "Total Engagement", 
                        value: metrics.totalEngagement.toLocaleString(), 
                        icon: Activity, 
                        color: "text-cyan-400",
                        change: "+12.5%"
                    },
                    { 
                        label: "Campaign Reach", 
                        value: metrics.campaignReach.toLocaleString(), 
                        icon: Eye, 
                        color: "text-green-400",
                        change: "+8.3%"
                    },
                    { 
                        label: "XP Issued", 
                        value: metrics.xpIssued.toLocaleString(), 
                        icon: TrendingUp, 
                        color: "text-yellow-400",
                        change: "+15.7%"
                    },
                    { 
                        label: "Conversion Rate", 
                        value: `${metrics.conversionRate}%`, 
                        icon: BarChart3, 
                        color: "text-purple-400",
                        change: "+2.1%"
                    }
                ].map((metric, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between mb-2">
                                <p className="text-gray-400 text-sm">{metric.label}</p>
                                <metric.icon className={`w-5 h-5 ${metric.color}`} />
                            </div>
                            <div className="flex items-end justify-between">
                                <p className="text-2xl font-bold text-white">{metric.value}</p>
                                <span className="text-green-400 text-sm font-medium">{metric.change}</span>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Charts Grid */}
            <div className="grid lg:grid-cols-2 gap-6">
                {/* Engagement Trend */}
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <TrendingUp className="w-5 h-5 mr-2 text-cyan-400" />
                            Engagement Trend
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <LineChart data={metrics.engagementTrend}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                                <XAxis dataKey="date" stroke="#A0AEC0" />
                                <YAxis stroke="#A0AEC0" />
                                <Tooltip 
                                    contentStyle={{
                                        background: 'rgba(15, 23, 42, 0.9)',
                                        border: 'rgba(255, 255, 255, 0.1)',
                                        borderRadius: '0.5rem'
                                    }}
                                />
                                <Line type="monotone" dataKey="engagement" stroke="#4ECDC4" strokeWidth={2} />
                            </LineChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {/* Audience Breakdown */}
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <Users className="w-5 h-5 mr-2 text-cyan-400" />
                            Audience Breakdown
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={300}>
                            <RechartsPieChart>
                                <Pie
                                    data={metrics.audienceBreakdown}
                                    cx="50%"
                                    cy="50%"
                                    outerRadius={80}
                                    fill="#8884d8"
                                    dataKey="value"
                                    label={({ name, value }) => `${name}: ${value}%`}
                                >
                                    {metrics.audienceBreakdown.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </RechartsPieChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>

                {/* Top Campaigns */}
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <BarChart3 className="w-5 h-5 mr-2 text-cyan-400" />
                            Top Performing Campaigns
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-3">
                            {metrics.topCampaigns.map((campaign, index) => (
                                <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                                    <div>
                                        <p className="text-white font-medium">{campaign.name}</p>
                                        <p className="text-gray-400 text-sm">{campaign.participants} participants</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="text-yellow-400 font-semibold">{campaign.xp} XP</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* Campaign Performance */}
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <Calendar className="w-5 h-5 mr-2 text-cyan-400" />
                            Campaign Performance
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <ResponsiveContainer width="100%" height={200}>
                            <BarChart data={metrics.topCampaigns}>
                                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                                <XAxis dataKey="name" stroke="#A0AEC0" />
                                <YAxis stroke="#A0AEC0" />
                                <Tooltip 
                                    contentStyle={{
                                        background: 'rgba(15, 23, 42, 0.9)',
                                        border: 'rgba(255, 255, 255, 0.1)',
                                        borderRadius: '0.5rem'
                                    }}
                                />
                                <Bar dataKey="participants" fill="#4ECDC4" />
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
