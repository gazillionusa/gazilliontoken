import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bond } from '@/api/entities';
import { 
    Plus, 
    Gift, 
    DollarSign,
    TrendingUp,
    Calendar,
    MoreHorizontal,
    Edit,
    Eye,
    Loader2
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function BondManager({ partner }) {
    const [bonds, setBonds] = useState([]);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        totalBonds: 0,
        activeBonds: 0,
        totalValue: 0,
        avgAPY: 0
    });

    const loadBonds = useCallback(async () => {
        if (!partner) {
            setLoading(false);
            return;
        }
        
        try {
            // For now, we'll show all bonds - in a real implementation, 
            // you'd filter by bonds associated with this partner
            const bondData = await Bond.list('-created_date', 20);
            setBonds(bondData);
            
            // Calculate stats
            const activeBonds = bondData.filter(b => b.status === 'active');
            const totalValue = bondData.reduce((sum, b) => sum + (b.current_price || b.face_value), 0);
            const avgAPY = bondData.reduce((sum, b) => sum + b.apy, 0) / (bondData.length || 1);
            
            setStats({
                totalBonds: bondData.length,
                activeBonds: activeBonds.length,
                totalValue,
                avgAPY: Math.round(avgAPY * 100) / 100
            });
            
        } catch (error) {
            console.error("Failed to load bonds:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]);

    useEffect(() => {
        loadBonds();
    }, [loadBonds]);

    const formatCurrency = (amount) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0,
        }).format(amount);
    };

    const getBondStatusColor = (status) => {
        switch(status) {
            case 'active': return 'bg-green-600';
            case 'trading': return 'bg-blue-600';
            case 'matured': return 'bg-purple-600';
            case 'suspended': return 'bg-red-600';
            default: return 'bg-gray-600';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Bond Listings Manager</h2>
                    <p className="text-gray-400">Create and manage municipal bond NFT offerings.</p>
                </div>
                <Link to={createPageUrl("CreateBond")}>
                    <Button className="primary-gradient text-white">
                        <Plus className="w-4 h-4 mr-2" />
                        Create Bond
                    </Button>
                </Link>
            </div>

            {/* Bond Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { label: "Total Bonds", value: stats.totalBonds, icon: Gift, color: "text-cyan-400" },
                    { label: "Active Bonds", value: stats.activeBonds, icon: TrendingUp, color: "text-green-400" },
                    { label: "Total Value", value: formatCurrency(stats.totalValue), icon: DollarSign, color: "text-blue-400" },
                    { label: "Average APY", value: `${stats.avgAPY}%`, icon: Calendar, color: "text-purple-400" }
                ].map((stat, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-gray-400 text-sm">{stat.label}</p>
                                    <p className="text-xl font-bold text-white">{stat.value}</p>
                                </div>
                                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Bonds List */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white">Your Bond Listings</CardTitle>
                </CardHeader>
                <CardContent>
                    {bonds.length === 0 ? (
                        <div className="text-center py-8">
                            <Gift className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No bonds created yet</h3>
                            <p className="text-gray-400 mb-4">Create your first municipal bond NFT to get started.</p>
                            <Link to={createPageUrl("CreateBond")}>
                                <Button className="primary-gradient text-white">
                                    <Plus className="w-4 h-4 mr-2" />
                                    Create First Bond
                                </Button>
                            </Link>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {bonds.map((bond) => (
                                <div key={bond.id} className="border border-white/10 rounded-xl p-4 hover:border-white/20 transition-colors">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-4">
                                            <div className="w-10 h-10 bg-cyan-400/10 rounded-lg flex items-center justify-center">
                                                <Gift className="w-5 h-5 text-cyan-400" />
                                            </div>
                                            <div>
                                                <h4 className="text-white font-semibold">{bond.bond_name}</h4>
                                                <p className="text-gray-400 text-sm">{bond.municipality}</p>
                                                <div className="flex items-center space-x-4 mt-1">
                                                    <span className="text-xs text-gray-500">
                                                        {formatCurrency(bond.current_price || bond.face_value)}
                                                    </span>
                                                    <span className="text-xs text-green-400">
                                                        {bond.apy}% APY
                                                    </span>
                                                    <span className="text-xs text-gray-500">
                                                        {bond.category.replace('_', ' ').toUpperCase()}
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <Badge className={`${getBondStatusColor(bond.status)} text-white`}>
                                                {bond.status}
                                            </Badge>
                                            <div className="flex space-x-1">
                                                <Link to={createPageUrl(`BondDetails?id=${bond.id}`)}>
                                                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                        <Eye className="w-4 h-4" />
                                                    </Button>
                                                </Link>
                                                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                    <Edit className="w-4 h-4" />
                                                </Button>
                                                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                    <MoreHorizontal className="w-4 h-4" />
                                                </Button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}