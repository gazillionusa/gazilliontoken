
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CivicCampaign } from '@/api/entities';
import { 
    Plus, 
    Zap, 
    Calendar, 
    Users, 
    Play,
    Pause,
    MoreHorizontal,
    Gift,
    Trophy,
    Target,
    Loader2
} from 'lucide-react';

export default function CampaignsManager({ partner }) {
    const [campaigns, setCampaigns] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadCampaigns = useCallback(async () => {
        if (!partner) {
            setLoading(false); // Ensure loading state is reset even if no partner
            return;
        }
        
        try {
            const campaignData = await CivicCampaign.filter({ partner_id: partner.id }, '-created_date');
            setCampaigns(campaignData);
        } catch (error) {
            console.error("Failed to load campaigns:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]); // `partner` is a dependency of `loadCampaigns`

    useEffect(() => {
        loadCampaigns();
    }, [loadCampaigns]); // `loadCampaigns` itself is a dependency, ensuring it re-runs when `partner` changes

    const getCampaignIcon = (type) => {
        switch(type) {
            case 'xp_reward': return <Zap className="w-4 h-4" />;
            case 'badge_drop': return <Trophy className="w-4 h-4" />;
            case 'nft_drop': return <Gift className="w-4 h-4" />;
            case 'challenge': return <Target className="w-4 h-4" />;
            default: return <Zap className="w-4 h-4" />;
        }
    };

    const getCampaignColor = (status) => {
        switch(status) {
            case 'active': return 'bg-green-600';
            case 'draft': return 'bg-gray-600';
            case 'paused': return 'bg-yellow-600';
            case 'completed': return 'bg-blue-600';
            case 'cancelled': return 'bg-red-600';
            default: return 'bg-gray-600';
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Campaigns & Rewards</h2>
                    <p className="text-gray-400">Create and manage XP rewards, badge drops, and community challenges.</p>
                </div>
                <Button className="primary-gradient text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    New Campaign
                </Button>
            </div>

            {/* Campaign Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { label: "Active Campaigns", value: campaigns.filter(c => c.status === 'active').length, icon: Play, color: "text-green-400" },
                    { label: "Total Participants", value: campaigns.reduce((sum, c) => sum + c.current_participants, 0), icon: Users, color: "text-blue-400" },
                    { label: "XP Issued", value: campaigns.reduce((sum, c) => sum + (c.reward_amount || 0), 0), icon: Zap, color: "text-yellow-400" },
                    { label: "Completion Rate", value: "87%", icon: Target, color: "text-purple-400" }
                ].map((stat, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-gray-400 text-sm">{stat.label}</p>
                                    <p className="text-xl font-bold text-white">{stat.value}</p>
                                </div>
                                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Campaigns List */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white">All Campaigns</CardTitle>
                </CardHeader>
                <CardContent>
                    {campaigns.length === 0 ? (
                        <div className="text-center py-8">
                            <Zap className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No campaigns yet</h3>
                            <p className="text-gray-400 mb-4">Create your first campaign to start engaging with your community.</p>
                            <Button className="primary-gradient text-white">
                                <Plus className="w-4 h-4 mr-2" />
                                Create Campaign
                            </Button>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {campaigns.map((campaign) => (
                                <div key={campaign.id} className="border border-white/10 rounded-xl p-4 hover:border-white/20 transition-colors">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-4">
                                            <div className="w-10 h-10 bg-cyan-400/10 rounded-lg flex items-center justify-center">
                                                {getCampaignIcon(campaign.campaign_type)}
                                            </div>
                                            <div>
                                                <h4 className="text-white font-semibold">{campaign.campaign_name}</h4>
                                                <p className="text-gray-400 text-sm">{campaign.description}</p>
                                                <div className="flex items-center space-x-4 mt-2">
                                                    <span className="text-xs text-gray-500">
                                                        {campaign.current_participants} / {campaign.max_participants || '∞'} participants
                                                    </span>
                                                    {campaign.end_date && (
                                                        <span className="text-xs text-gray-500">
                                                            Ends: {new Date(campaign.end_date).toLocaleDateString()}
                                                        </span>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            {campaign.reward_amount && (
                                                <div className="text-right">
                                                    <div className="text-yellow-400 font-semibold">{campaign.reward_amount} XP</div>
                                                    <div className="text-xs text-gray-500">Reward</div>
                                                </div>
                                            )}
                                            <Badge className={`${getCampaignColor(campaign.status)} text-white`}>
                                                {campaign.status}
                                            </Badge>
                                            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                <MoreHorizontal className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
