
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageThread } from '@/api/entities';
import { 
    MessageSquare, 
    Users, 
    Clock,
    Send,
    Inbox,
    Loader2
} from 'lucide-react';

export default function MessagingHub({ partner }) {
    const [threads, setThreads] = useState([]);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState({
        totalMessages: 0,
        unreadCount: 0,
        activeThreads: 0,
        responseTime: '2.5h'
    });

    const loadMessaging = useCallback(async () => {
        if (!partner) {
            setLoading(false); // Ensure loading is set to false if no partner is available initially
            return;
        }
        
        try {
            // In a real implementation, you'd filter threads where any participant
            // is associated with this partner
            const threadData = await MessageThread.list('-last_message_timestamp', 10);
            setThreads(threadData);
            
            // Calculate stats
            const unread = threadData.filter(t => t.unread_count > 0).length;
            const active = threadData.filter(t => !t.is_archived).length;
            
            setStats({
                totalMessages: threadData.reduce((sum, t) => sum + (t.unread_count || 0), 0),
                unreadCount: unread,
                activeThreads: active,
                responseTime: '2.5h'
            });
            
        } catch (error) {
            console.error("Failed to load messaging data:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]); // `loadMessaging` now depends on `partner`

    useEffect(() => {
        // `loadMessaging` is a stable function reference (or re-created if `partner` changes)
        // so it's safe to put it in the dependency array.
        // The `if (!partner) return;` inside `loadMessaging` handles the initial state.
        loadMessaging();
    }, [loadMessaging]); // `useEffect` now depends on `loadMessaging`

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Community Messages</h2>
                    <p className="text-gray-400">Communicate with citizens and manage support inquiries.</p>
                </div>
                <Button className="primary-gradient text-white">
                    <Send className="w-4 h-4 mr-2" />
                    New Message
                </Button>
            </div>

            {/* Messaging Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {[
                    { label: "Active Conversations", value: stats.activeThreads, icon: MessageSquare, color: "text-cyan-400" },
                    { label: "Unread Messages", value: stats.unreadCount, icon: Inbox, color: "text-red-400" },
                    { label: "Avg Response Time", value: stats.responseTime, icon: Clock, color: "text-green-400" },
                    { label: "This Week", value: "47", icon: Users, color: "text-blue-400" }
                ].map((stat, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-4">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-gray-400 text-sm">{stat.label}</p>
                                    <p className="text-xl font-bold text-white">{stat.value}</p>
                                </div>
                                <stat.icon className={`w-8 h-8 ${stat.color}`} />
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Message Threads */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white flex items-center">
                        <MessageSquare className="w-5 h-5 mr-2" />
                        Recent Conversations
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {threads.length === 0 ? (
                        <div className="text-center py-8">
                            <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No conversations yet</h3>
                            <p className="text-gray-400">
                                Messages from community members will appear here.
                            </p>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {threads.slice(0, 5).map((thread) => (
                                <div key={thread.id} className="border border-white/10 rounded-lg p-4 hover:border-white/20 transition-colors cursor-pointer">
                                    <div className="flex items-start justify-between">
                                        <div className="flex items-start space-x-3">
                                            <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-teal-500 rounded-full flex items-center justify-center">
                                                <MessageSquare className="w-5 h-5 text-white" />
                                            </div>
                                            <div className="flex-1">
                                                <div className="flex items-center space-x-2 mb-1">
                                                    <h4 className="text-white font-semibold">
                                                        {thread.participant_names?.[1] || 'Community Member'}
                                                    </h4>
                                                    {thread.unread_count > 0 && (
                                                        <Badge className="bg-red-600 text-white text-xs">
                                                            {thread.unread_count}
                                                        </Badge>
                                                    )}
                                                </div>
                                                <p className="text-gray-400 text-sm line-clamp-2">
                                                    {thread.last_message_content || 'No messages yet'}
                                                </p>
                                                <p className="text-gray-500 text-xs mt-1">
                                                    {thread.last_message_timestamp ? 
                                                        new Date(thread.last_message_timestamp).toLocaleDateString() : 
                                                        'No activity'
                                                    }
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
