
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CivicCampaign } from '@/api/entities';
import { CivicEvent } from '@/api/entities';
import { CivicContact } from '@/api/entities';
import { 
    TrendingUp, 
    Users, 
    Calendar, 
    Zap, 
    Eye,
    Gift,
    MessageSquare,
    ArrowUpRight,
    Loader2
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom'; // Added Link import

export default function PortalDashboard({ partner, portal }) {
    const [stats, setStats] = useState({
        totalCampaigns: 0,
        activeCampaigns: 0,
        totalEvents: 0,
        upcomingEvents: 0,
        totalContacts: 0,
        thisMonthViews: 0,
        xpIssued: 0,
        totalEngagement: 0
    });
    const [loading, setLoading] = useState(true);
    const [recentActivity, setRecentActivity] = useState([]);

    // Placeholder for createPageUrl - assuming it's available in the actual application context
    // You might need to define or import this function based on your routing setup.
    const createPageUrl = useCallback((pageName) => {
        // Example: If partner.id and pageName are used to construct URLs
        if (partner && partner.id) {
            switch (pageName) {
                case "CampaignBuilder":
                    return `/partner/${partner.id}/campaigns/new`;
                // Add other page URLs as needed
                default:
                    return `/partner/${partner.id}/${pageName.toLowerCase()}`;
            }
        }
        return `/${pageName.toLowerCase()}`; // Fallback or general URL
    }, [partner]);


    const loadDashboardData = useCallback(async () => {
        if (!partner) return;
        
        try {
            const [campaigns, events, contacts] = await Promise.all([
                CivicCampaign.filter({ partner_id: partner.id }),
                CivicEvent.filter({ partner_id: partner.id }),
                CivicContact.filter({ partner_id: partner.id })
            ]);

            const now = new Date();
            const activeCampaigns = campaigns.filter(c => c.status === 'active');
            const upcomingEvents = events.filter(e => new Date(e.event_date) > now);

            setStats({
                totalCampaigns: campaigns.length,
                activeCampaigns: activeCampaigns.length,
                totalEvents: events.length,
                upcomingEvents: upcomingEvents.length,
                totalContacts: contacts.length,
                thisMonthViews: Math.floor(Math.random() * 2000) + 500, // Mock data
                xpIssued: campaigns.reduce((sum, c) => sum + (c.reward_amount || 0), 0),
                totalEngagement: Math.floor(Math.random() * 5000) + 1000 // Mock data
            });

            // Generate recent activity
            const activity = [
                { type: 'campaign', message: 'New user joined "Green Energy Challenge"', time: '2 hours ago' },
                { type: 'event', message: 'Town Hall meeting RSVP received', time: '4 hours ago' },
                { type: 'message', message: 'New message from citizen about bond inquiry', time: '6 hours ago' },
                { type: 'contact', message: '3 new contacts added from website', time: '1 day ago' }
            ];
            setRecentActivity(activity);

        } catch (error) {
            console.error("Failed to load dashboard data:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]);

    useEffect(() => {
        loadDashboardData();
    }, [loadDashboardData]);

    const statCards = [
        {
            title: "Active Campaigns",
            value: stats.activeCampaigns,
            total: stats.totalCampaigns,
            icon: Zap,
            color: "text-yellow-400",
            bgColor: "bg-yellow-400/10"
        },
        {
            title: "Upcoming Events", 
            value: stats.upcomingEvents,
            total: stats.totalEvents,
            icon: Calendar,
            color: "text-blue-400",
            bgColor: "bg-blue-400/10"
        },
        {
            title: "Total Contacts",
            value: stats.totalContacts,
            icon: Users,
            color: "text-green-400",
            bgColor: "bg-green-400/10"
        },
        {
            title: "Monthly Views",
            value: stats.thisMonthViews,
            icon: Eye,
            color: "text-purple-400", 
            bgColor: "bg-purple-400/10"
        }
    ];

    const getActivityIcon = (type) => {
        switch(type) {
            case 'campaign': return <Zap className="w-4 h-4 text-yellow-400" />;
            case 'event': return <Calendar className="w-4 h-4 text-blue-400" />;
            case 'message': return <MessageSquare className="w-4 h-4 text-green-400" />;
            case 'contact': return <Users className="w-4 h-4 text-purple-400" />;
            default: return <TrendingUp className="w-4 h-4 text-gray-400" />;
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Welcome Section */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-xl font-bold text-white mb-2">
                                Welcome back, {partner?.name}! 
                            </h2>
                            <p className="text-gray-400">
                                Here's what's happening with your civic community engagement.
                            </p>
                        </div>
                        <div className="text-right">
                            <div className="text-2xl font-bold text-cyan-400">
                                {stats.xpIssued.toLocaleString()}
                            </div>
                            <div className="text-sm text-gray-400">
                                Total XP Issued
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {statCards.map((stat, index) => (
                    <Card key={index} className="glass-effect border-white/10 bg-transparent">
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <div>
                                    <p className="text-gray-400 text-sm">{stat.title}</p>
                                    <div className="flex items-baseline space-x-2">
                                        <p className="text-2xl font-bold text-white">{stat.value}</p>
                                        {stat.total && (
                                            <p className="text-sm text-gray-500">/ {stat.total}</p>
                                        )}
                                    </div>
                                </div>
                                <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Dashboard Content Grid */}
            <div className="grid lg:grid-cols-2 gap-6">
                {/* Recent Activity */}
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <TrendingUp className="w-5 h-5 mr-2 text-cyan-400" />
                            Recent Activity
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-4">
                            {recentActivity.map((activity, index) => (
                                <div key={index} className="flex items-start space-x-3">
                                    {getActivityIcon(activity.type)}
                                    <div className="flex-1">
                                        <p className="text-white text-sm">{activity.message}</p>
                                        <p className="text-gray-500 text-xs">{activity.time}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardHeader>
                        <CardTitle className="text-white flex items-center">
                            <Gift className="w-5 h-5 mr-2 text-cyan-400" />
                            Quick Actions
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 gap-4">
                            <Link to={createPageUrl("CampaignBuilder")}>
                                <button className="w-full p-4 rounded-xl bg-yellow-400/10 hover:bg-yellow-400/20 transition-colors border border-yellow-400/20">
                                    <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                                    <p className="text-white text-sm font-medium">New Campaign</p>
                                    <p className="text-gray-400 text-xs">Create XP rewards</p>
                                </button>
                            </Link>
                            <button className="w-full p-4 rounded-xl bg-blue-400/10 hover:bg-blue-400/20 transition-colors border border-blue-400/20">
                                <Calendar className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                                <p className="text-white text-sm font-medium">Schedule Event</p>
                                <p className="text-gray-400 text-xs">Plan community gathering</p>
                            </button>
                            <button className="w-full p-4 rounded-xl bg-green-400/10 hover:bg-green-400/20 transition-colors border border-green-400/20">
                                <Users className="w-8 h-8 text-green-400 mx-auto mb-2" />
                                <p className="text-white text-sm font-medium">Add Contacts</p>
                                <p className="text-gray-400 text-xs">Import or add manually</p>
                            </button>
                            <button className="w-full p-4 rounded-xl bg-purple-400/10 hover:bg-purple-400/20 transition-colors border border-purple-400/20">
                                <MessageSquare className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                                <p className="text-white text-sm font-medium">Send Message</p>
                                <p className="text-gray-400 text-xs">Reach out to community</p>
                            </button>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Portal Status */}
            {!portal?.onboarding_completed && (
                <Card className="glass-effect border-amber-400/30 bg-amber-400/5">
                    <CardContent className="p-6">
                        <div className="flex items-center space-x-4">
                            <div className="w-12 h-12 bg-amber-400/20 rounded-xl flex items-center justify-center">
                                <ArrowUpRight className="w-6 h-6 text-amber-400" />
                            </div>
                            <div className="flex-1">
                                <h3 className="text-white font-semibold">Complete Your Portal Setup</h3>
                                <p className="text-gray-400 text-sm">
                                    Finish setting up your public portal page to start engaging with citizens.
                                </p>
                            </div>
                            <Badge className="bg-amber-400 text-amber-900">
                                Step {portal?.setup_step || 1} of 5
                            </Badge>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
