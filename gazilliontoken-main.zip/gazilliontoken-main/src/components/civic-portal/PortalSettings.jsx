
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { CivicPartnerPortal } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import {
    Building,
    Palette,
    Link as LinkIcon,
    Loader2,
    Save,
    CreditCard,
    Zap,
    Gift,
    Users,
    Lock,
    Twitter,
    Linkedin,
    Instagram
} from 'lucide-react';
import { toast } from "sonner";

// New SettingsCard component to encapsulate sections
function SettingsCard({ title, icon, children }) {
    return (
        <Card className="glass-effect border-white/10 bg-transparent">
            <CardHeader>
                <CardTitle className="text-white flex items-center">
                    {icon && <span className="mr-2">{icon}</span>}
                    {title}
                </CardTitle>
            </CardHeader>
            <CardContent>
                {children}
            </CardContent>
        </Card>
    );
}

export default function PortalSettings({ partner, portal, onUpdate }) {
    const [portalData, setPortalData] = useState({
        partner_name: '',
        description: '',
        logo_url: '',
        banner_url: '',
        is_public: true, // New field for public profile
        color_scheme: {
            primary_color: '#4ECDC4',
            secondary_color: '#26A69A',
            accent_color: '#80CBC4',
            background_color: '#0f172a'
        },
        contact_info: { email: '', phone: '', address: '', website: '' },
        social_links: { twitter: '', linkedin: '', instagram: '' } // New field for social links
    });
    const [isSaving, setIsSaving] = useState(false); // Renamed from saving
    const [isUploading, setIsUploading] = useState(false); // Changed from object to boolean

    useEffect(() => {
        if (portal) {
            setPortalData(prev => ({
                ...prev,
                ...portal,
                color_scheme: portal.color_scheme || prev.color_scheme,
                contact_info: portal.contact_info || prev.contact_info,
                social_links: portal.social_links || prev.social_links,
                is_public: portal.is_public !== undefined ? portal.is_public : true, // Ensure is_public is set, default to true
            }));
        } else if (partner) {
            // Initialize with partner data if no portal exists
            setPortalData(prev => ({
                ...prev,
                partner_name: partner.name.toLowerCase().replace(/\s+/g, '-'),
                contact_info: {
                    email: partner.contact_email || '',
                    phone: '',
                    address: '',
                    website: partner.website || ''
                },
                social_links: { twitter: '', linkedin: '', instagram: '' }, // Default social links for new partner
                is_public: true, // Default to true for a new partner
            }));
        }
    }, [portal, partner]);

    const handleUpdate = async () => { // Renamed from handleSave
        setIsSaving(true);
        try {
            const dataToSave = {
                ...portalData,
                partner_id: partner.id,
                portal_url: `gazillionusa.com/partners/${portalData.partner_name}`,
                onboarding_completed: true,
                setup_step: 5,
                is_active: true
            };

            if (portal) {
                await CivicPartnerPortal.update(portal.id, dataToSave);
            } else {
                await CivicPartnerPortal.create(dataToSave);
            }

            toast.success("Portal settings saved successfully!");
            onUpdate();
        } catch (error) {
            console.error("Failed to save portal settings:", error);
            toast.error("Failed to save settings.");
        } finally {
            setIsSaving(false);
        }
    };
    
    const handleFileUpload = async (field, file) => { // Refactored to accept field as string
        if (!file) return;

        setIsUploading(true);
        try {
            const { file_url } = await UploadFile({ file });
            setPortalData(prev => ({
                ...prev,
                [field]: file_url
            }));
            toast.success(`${field.replace('_url', '').replace('_', ' ')} uploaded successfully!`);
        } catch (error) {
            console.error(`Failed to upload ${field}:`, error);
            toast.error(`Failed to upload ${field}.`);
        } finally {
            setIsUploading(false);
        }
    };

    const handleSocialLinkChange = (platform, value) => {
        setPortalData(prev => ({
            ...prev,
            social_links: {
                ...prev.social_links,
                [platform]: value
            }
        }));
    };

    const addons = [
        { name: "Advertising Boost", description: "Featured placement on homepage & Civic Zoo map.", price: "$49/month", icon: Zap },
        { name: "Client Support System", description: "Access to live chat widget & priority help desk.", price: "$29/month", icon: Gift },
        { name: "XP Event Sponsor", description: "Boost community XP in your name + civic challenge creation.", price: "$99/event", icon: CreditCard },
        { name: "Consultation Session", description: "30-minute 1-on-1 onboarding with a Gazillion consultant.", price: "$75 (one-time)", icon: Users },
    ];

    if (!portalData) {
        return <div>Loading...</div>; // Placeholder for loading state if portalData could be null
    }

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
                {/* Profile Settings */}
                <SettingsCard title="Public Profile Settings" icon={<Building className="w-5 h-5" />}>
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="partnerName" className="text-white">Portal URL Slug</Label>
                            <div className="flex mt-1">
                                <span className="text-gray-400 text-sm py-2 pr-2">gazillionusa.com/partners/</span>
                                <Input
                                    id="partnerName"
                                    value={portalData.partner_name || ''}
                                    onChange={e => setPortalData(p => ({ ...p, partner_name: e.target.value.toLowerCase().replace(/\s+/g, '-') }))}
                                    className="glass-effect border-white/20 bg-transparent text-white"
                                    placeholder="your-organization-name"
                                />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="description" className="text-white">Description</Label>
                            <Textarea
                                id="description"
                                value={portalData.description || ''}
                                onChange={e => setPortalData(p => ({ ...p, description: e.target.value }))}
                                className="glass-effect min-h-[120px] border-white/20 bg-transparent text-white"
                                placeholder="Describe your organization and civic mission..."
                            />
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label className="text-white">Logo</Label>
                                <Input
                                    type="file"
                                    accept="image/*"
                                    onChange={e => handleFileUpload('logo_url', e.target.files[0])}
                                    className="glass-effect file:text-white border-white/20 bg-transparent"
                                    disabled={isUploading}
                                />
                                {portalData.logo_url && <img src={portalData.logo_url} alt="logo" className="w-20 h-20 rounded-lg mt-2 object-contain bg-white p-1"/>}
                                {isUploading && <p className="text-cyan-400 text-sm mt-1"><Loader2 className="w-4 h-4 inline mr-1 animate-spin" /> Uploading...</p>}
                            </div>
                            <div className="space-y-2">
                                <Label className="text-white">Banner Image</Label>
                                <Input
                                    type="file"
                                    accept="image/*"
                                    onChange={e => handleFileUpload('banner_url', e.target.files[0])}
                                    className="glass-effect file:text-white border-white/20 bg-transparent"
                                    disabled={isUploading}
                                />
                                {portalData.banner_url && <img src={portalData.banner_url} alt="banner" className="w-full h-20 rounded-lg mt-2 object-cover"/>}
                                {isUploading && <p className="text-cyan-400 text-sm mt-1"><Loader2 className="w-4 h-4 inline mr-1 animate-spin" /> Uploading...</p>}
                            </div>
                        </div>
                    </div>
                </SettingsCard>

                {/* Theme Settings */}
                <SettingsCard title="Theme & Branding" icon={<Palette className="w-5 h-5" />}>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {Object.keys(portalData.color_scheme || {}).map(colorKey => (
                            <div key={colorKey} className="space-y-2">
                                <Label className="text-white capitalize">{colorKey.replace('_', ' ')}</Label>
                                <Input
                                    type="color"
                                    value={portalData.color_scheme[colorKey] || '#ffffff'}
                                    onChange={e => setPortalData(p => ({ ...p, color_scheme: { ...p.color_scheme, [colorKey]: e.target.value } }))}
                                    className="w-full h-12 p-1 glass-effect border-white/20 bg-transparent"
                                />
                            </div>
                        ))}
                    </div>
                </SettingsCard>

                {/* Social Links */}
                <SettingsCard title="Social Links" icon={<LinkIcon className="w-5 h-5" />}>
                     <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                            <Twitter className="w-5 h-5 text-gray-400" />
                            <Input
                                value={portalData.social_links?.twitter || ''}
                                onChange={e => handleSocialLinkChange('twitter', e.target.value)}
                                placeholder="https://twitter.com/username"
                                className="glass-effect border-white/20 bg-transparent text-white"
                            />
                        </div>
                         <div className="flex items-center space-x-2">
                            <Linkedin className="w-5 h-5 text-gray-400" />
                            <Input
                                value={portalData.social_links?.linkedin || ''}
                                onChange={e => handleSocialLinkChange('linkedin', e.target.value)}
                                placeholder="https://linkedin.com/in/username"
                                className="glass-effect border-white/20 bg-transparent text-white"
                            />
                        </div>
                         <div className="flex items-center space-x-2">
                            <Instagram className="w-5 h-5 text-gray-400" />
                            <Input
                                value={portalData.social_links?.instagram || ''}
                                onChange={e => handleSocialLinkChange('instagram', e.target.value)}
                                placeholder="https://instagram.com/username"
                                className="glass-effect border-white/20 bg-transparent text-white"
                            />
                        </div>
                    </div>
                </SettingsCard>
                
                {/* Contact Information - Preserving existing functionality */}
                <SettingsCard title="Contact Information" icon={<Users className="w-5 h-5" />}>
                    <div className="space-y-4">
                        <div>
                            <Label className="text-white">Email</Label>
                            <Input
                                value={portalData.contact_info.email}
                                onChange={(e) => setPortalData(prev => ({
                                    ...prev,
                                    contact_info: { ...prev.contact_info, email: e.target.value }
                                }))}
                                className="glass-effect border-white/20 bg-transparent text-white mt-1"
                                placeholder="contact@youremail.com"
                            />
                        </div>
                        <div>
                            <Label className="text-white">Phone</Label>
                            <Input
                                value={portalData.contact_info.phone}
                                onChange={(e) => setPortalData(prev => ({
                                    ...prev,
                                    contact_info: { ...prev.contact_info, phone: e.target.value }
                                }))}
                                className="glass-effect border-white/20 bg-transparent text-white mt-1"
                                placeholder="+1 (555) 123-4567"
                            />
                        </div>
                        <div>
                            <Label className="text-white">Address</Label>
                            <Input
                                value={portalData.contact_info.address}
                                onChange={(e) => setPortalData(prev => ({
                                    ...prev,
                                    contact_info: { ...prev.contact_info, address: e.target.value }
                                }))}
                                className="glass-effect border-white/20 bg-transparent text-white mt-1"
                                placeholder="123 Main St, Anytown, USA"
                            />
                        </div>
                        <div>
                            <Label className="text-white">Website</Label>
                            <Input
                                value={portalData.contact_info.website}
                                onChange={(e) => setPortalData(prev => ({
                                    ...prev,
                                    contact_info: { ...prev.contact_info, website: e.target.value }
                                }))}
                                className="glass-effect border-white/20 bg-transparent text-white mt-1"
                                placeholder="https://www.yourwebsite.com"
                            />
                        </div>
                    </div>
                </SettingsCard>

                {/* Privacy Settings */}
                <SettingsCard title="Privacy Settings" icon={<Lock className="w-5 h-5" />}>
                     <div className="flex items-center justify-between">
                        <div>
                            <Label htmlFor="is_public" className="text-white font-medium">Public Profile Page</Label>
                            <p className="text-sm text-gray-400">Allow your partner page to be discovered in the public directory.</p>
                        </div>
                        <Switch id="is_public" checked={portalData.is_public} onCheckedChange={(checked) => setPortalData(p => ({...p, is_public: checked}))} />
                    </div>
                </SettingsCard>

                 <div className="flex justify-end">
                    <Button onClick={handleUpdate} disabled={isSaving || isUploading} className="primary-gradient text-white">
                        {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
                        Save Changes
                    </Button>
                </div>
            </div>

            <div className="space-y-8">
                <SettingsCard title="Subscription & Add-ons" icon={<CreditCard className="w-5 h-5" />}>
                    <div className="space-y-4">
                         <div className="p-4 rounded-lg bg-cyan-400/10 border border-cyan-400/30 text-center">
                            <p className="text-sm text-cyan-300">Current Plan</p>
                            <p className="text-2xl font-bold text-white">Professional Tier</p>
                        </div>
                        <Button className="w-full bg-cyan-600 hover:bg-cyan-700 text-white">Manage Subscription</Button>
                        <div className="space-y-3 pt-4">
                            <h4 className="font-semibold text-white">Available Add-ons</h4>
                            {addons.map(addon => {
                                const Icon = addon.icon;
                                return (
                                    <div key={addon.name} className="p-3 rounded-lg glass-effect border-white/10 flex items-start space-x-3">
                                        <Icon className="w-5 h-5 text-cyan-400 mt-1" />
                                        <div>
                                            <p className="font-semibold text-white">{addon.name} - <span className="font-bold text-amber-400">{addon.price}</span></p>
                                            <p className="text-xs text-gray-400">{addon.description}</p>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                </SettingsCard>
                 <SettingsCard title="Domain & URL" icon={<LinkIcon className="w-5 h-5" />}>
                    <p className="text-gray-300 text-sm mb-2">Your public portal is live at:</p>
                    <div className="p-3 rounded-lg glass-effect border-white/10">
                        <a href={`/partners/${portalData.partner_name}`} target="_blank" rel="noopener noreferrer" className="font-mono text-cyan-400 break-all">{`gazillionusa.com/partners/${portalData.partner_name}`}</a>
                    </div>
                </SettingsCard>
            </div>
        </div>
    );
}
