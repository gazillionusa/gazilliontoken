
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { User } from '@/api/entities';
import { 
    Users, 
    UserPlus,
    Mail,
    Shield,
    Search,
    MoreHorizontal,
    Loader2
} from 'lucide-react';

export default function StaffManager({ partner }) {
    const [staff, setStaff] = useState([]);
    const [loading, setLoading] = useState(true);
    const [searchEmail, setSearchEmail] = useState('');

    const loadStaff = useCallback(async () => {
        if (!partner) return; // Add guard for partner existence
        
        try {
            const staffData = await User.filter({ partner_id: partner.id });
            setStaff(staffData);
        } catch (error) {
            console.error("Failed to load staff:", error);
        } finally {
            setLoading(false);
        }
    }, [partner]); // `partner` is a dependency for `loadStaff`

    useEffect(() => {
        // `loadStaff` is now a stable function reference thanks to useCallback,
        // so it can be safely used in the dependency array.
        // It will only change if its own dependencies (`partner`) change.
        loadStaff();
    }, [loadStaff]); 

    const handleAddStaff = async () => {
        if (!searchEmail.trim()) return;
        
        try {
            // In a real implementation, this would search for the user by email
            // and update their partner_id and partner_role
            console.log('Adding staff member:', searchEmail);
            setSearchEmail('');
            // Reload staff list
            await loadStaff(); // Make sure to await if loadStaff is async and we want to ensure staff is reloaded
        } catch (error) {
            console.error("Failed to add staff:", error);
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl font-bold text-white">Staff Management</h2>
                    <p className="text-gray-400">Manage team access and roles for your civic partner portal.</p>
                </div>
            </div>

            {/* Add Staff */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white flex items-center">
                        <UserPlus className="w-5 h-5 mr-2" />
                        Add Staff Member
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="flex gap-3">
                        <div className="flex-1">
                            <Input
                                placeholder="Enter user's email address"
                                value={searchEmail}
                                onChange={(e) => setSearchEmail(e.target.value)}
                                className="glass-effect border-white/20 bg-transparent text-white"
                                onKeyPress={(e) => e.key === 'Enter' && handleAddStaff()}
                            />
                            <p className="text-xs text-gray-500 mt-1">
                                User must have an existing Gazillion account
                            </p>
                        </div>
                        <Button 
                            onClick={handleAddStaff} 
                            className="primary-gradient text-white"
                            disabled={!searchEmail.trim()}
                        >
                            Add Staff
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Current Staff */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white flex items-center justify-between">
                        <div className="flex items-center">
                            <Users className="w-5 h-5 mr-2" />
                            Team Members ({staff.length})
                        </div>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {staff.length === 0 ? (
                        <div className="text-center py-8">
                            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white mb-2">No staff members yet</h3>
                            <p className="text-gray-400">
                                Add team members to help manage your civic partner portal.
                            </p>
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {staff.map((member) => (
                                <div key={member.id} className="border border-white/10 rounded-lg p-4 hover:border-white/20 transition-colors">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center space-x-4">
                                            <div className="w-10 h-10 rounded-full overflow-hidden">
                                                {member.avatar_image_url ? (
                                                    <img src={member.avatar_image_url} alt={member.full_name} className="w-full h-full object-cover" />
                                                ) : (
                                                    <div className="w-full h-full bg-gradient-to-br from-cyan-400 to-teal-500 flex items-center justify-center">
                                                        <span className="text-white font-semibold text-sm">
                                                            {member.full_name?.charAt(0) || member.email?.charAt(0)}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>
                                            <div>
                                                <h4 className="text-white font-semibold">
                                                    {member.full_name || 'User'}
                                                </h4>
                                                <div className="flex items-center text-sm text-gray-400">
                                                    <Mail className="w-3 h-3 mr-1" />
                                                    {member.email}
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center space-x-3">
                                            <Badge className={
                                                member.partner_role === 'admin' ? 
                                                'bg-red-600 text-white' : 
                                                'bg-blue-600 text-white'
                                            }>
                                                <Shield className="w-3 h-3 mr-1" />
                                                {member.partner_role || 'Staff'}
                                            </Badge>
                                            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                                                <MoreHorizontal className="w-4 h-4" />
                                            </Button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
