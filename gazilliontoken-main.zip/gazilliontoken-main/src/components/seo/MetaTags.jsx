import React, { useEffect } from 'react';

/**
 * A component to dynamically update SEO meta tags in the document head.
 * @param {string} title - The title for the page.
 * @param {string} description - The meta description for the page.
 * @param {string} keywords - Comma-separated keywords for the page.
 */
export default function MetaTags({ title, description, keywords }) {
  useEffect(() => {
    if (title) {
      document.title = title;
    }
    
    if (description) {
      let metaDescription = document.querySelector('meta[name="description"]');
      if (!metaDescription) {
        metaDescription = document.createElement('meta');
        metaDescription.name = 'description';
        document.head.appendChild(metaDescription);
      }
      metaDescription.content = description;
    }
    
    if (keywords) {
      let metaKeywords = document.querySelector('meta[name="keywords"]');
      if (!metaKeywords) {
        metaKeywords = document.createElement('meta');
        metaKeywords.name = 'keywords';
        document.head.appendChild(metaKeywords);
      }
      metaKeywords.content = keywords;
    }
  }, [title, description, keywords]);

  return null; // This component does not render anything to the DOM
}