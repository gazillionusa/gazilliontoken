
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, RefreshCw, Camera } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { cryptoPricing } from '@/api/functions';
import { generateChartImage } from '@/api/functions';
import { ChartSnapshot } from '@/api/entities';

export default function GochartingWidget() {
  const [prices, setPrices] = useState({});
  const [chartImage, setChartImage] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generatingChart, setGeneratingChart] = useState(false);
  const [error, setError] = useState(null);

  const loadPrices = useCallback(async () => {
    try {
      const { data } = await cryptoPricing({
        symbols: 'bitcoin,ethereum,usd-coin,binancecoin,cardano,solana',
        vs_currency: 'usd'
      });

      if (data.success) {
        const priceMap = {};
        data.prices.forEach((p) => {
          priceMap[p.symbol] = p;
        });
        setPrices(priceMap);
        setError(null);
      }
    } catch (err) {
      setError('Failed to load crypto prices');
      console.error('Crypto pricing error:', err);
    }
  }, []);

  const generateNewChart = useCallback(async () => {
    try {
      setGeneratingChart(true);
      
      // Mark old charts as not current
      const oldSnapshots = await ChartSnapshot.filter({ chart_type: 'bitcoin_30day', is_current: true });
      for (const snapshot of oldSnapshots) {
        await ChartSnapshot.update(snapshot.id, { is_current: false });
      }
      
      // Generate new chart
      const { data } = await generateChartImage();
      if (data.success) {
        setChartImage(data.image_url);
      }
    } catch (error) {
      console.error('Failed to generate chart:', error);
    } finally {
      setGeneratingChart(false);
    }
  }, []);

  const loadChartImage = useCallback(async () => {
    try {
      // Get the most recent chart snapshot
      const snapshots = await ChartSnapshot.filter(
        { chart_type: 'bitcoin_30day', is_current: true }, 
        '-generated_at', 
        1
      );
      
      if (snapshots.length > 0) {
        const snapshot = snapshots[0];
        const generatedAt = new Date(snapshot.generated_at);
        const now = new Date();
        const hoursSinceGenerated = (now - generatedAt) / (1000 * 60 * 60);
        
        // If chart is older than 6 hours, generate a new one
        if (hoursSinceGenerated > 6) {
          await generateNewChart();
        } else {
          setChartImage(snapshot.image_url);
        }
      } else {
        // No chart exists, generate first one
        await generateNewChart();
      }
    } catch (error) {
      console.error('Failed to load chart:', error);
      // Use fallback static chart if available
      setChartImage('https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/fallback_chart.png');
    }
  }, [generateNewChart]);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      await Promise.all([
        loadPrices(),
        loadChartImage()
      ]);
      setLoading(false);
    };

    loadData();
    
    // Update prices every 5 minutes
    const priceInterval = setInterval(loadPrices, 300000);
    
    // Check for chart updates every hour
    const chartInterval = setInterval(loadChartImage, 3600000);
    
    return () => {
      clearInterval(priceInterval);
      clearInterval(chartInterval);
    };
  }, [loadPrices, loadChartImage]);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 6
    }).format(price);
  };

  const formatChange = (change) => {
    return change > 0 ? `+${change.toFixed(2)}%` : `${change.toFixed(2)}%`;
  };

  return (
    <Card className="glass-effect border-white/10 bg-transparent xl:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-white text-xl flex items-center">
          <LineChart className="w-6 h-6 mr-3 text-cyan-400" />
          Live Crypto Market Prices
        </CardTitle>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={generateNewChart}
            disabled={generatingChart}
            className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md border-white/20 hover:bg-white/10"
          >
            <Camera className={`w-4 h-4 mr-2 ${generatingChart ? 'animate-spin' : ''}`} />
            Update Chart
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={loadPrices}
            disabled={loading}
            className="bg-background text-slate-950 px-3 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md border-white/20 hover:bg-white/10"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error ?
        <div className="text-center py-8">
            <p className="text-red-400 mb-4">{error}</p>
            <Button onClick={loadPrices} variant="outline" className="text-white border-white/20">
              Try Again
            </Button>
          </div> :

        <>
            {/* Live Price Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
              {Object.entries(prices).map(([symbol, data]) => {
              const isPositive = data.change_24h >= 0;
              return (
                <div key={symbol} className="glass-effect p-4 rounded-lg text-center">
                    <div className="text-sm text-gray-400 mb-1 capitalize">
                      {symbol.replace('-', ' ')}
                    </div>
                    <div className="text-lg font-bold text-white mb-1">
                      {formatPrice(data.price)}
                    </div>
                    <div className={`text-sm font-medium ${
                  isPositive ? 'text-green-400' : 'text-red-400'}`
                  }>
                      {formatChange(data.change_24h)}
                    </div>
                  </div>);

            })}
            </div>

            {/* Chart Image */}
            <div>
              <div className="h-[400px] w-full rounded-lg overflow-hidden bg-slate-800/50 flex items-center justify-center">
                {chartImage ? (
                  <img 
                    src={chartImage} 
                    alt="Bitcoin 30-Day Price Chart" 
                    className="max-w-full max-h-full object-contain rounded-lg"
                    onError={() => setChartImage(null)}
                  />
                ) : (
                  <div className="text-center text-gray-400">
                    <LineChart className="w-16 h-16 mx-auto mb-4 opacity-50" />
                    <p>Chart loading...</p>
                    {generatingChart && <p className="text-sm">Generating new chart...</p>}
                  </div>
                )}
              </div>
            </div>
            
            <p className="text-xs text-gray-500 mt-4 text-center">
              Chart updates every 6 hours • 
              Price data from <a href="https://www.coingecko.com/" target="_blank" rel="noopener noreferrer" className="hover:text-cyan-400">CoinGecko</a> • 
              Updates every 5 minutes
            </p>
          </>
        }
      </CardContent>
    </Card>);

}
