import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { kycVerification } from '@/api/functions';
import { 
    Shield, 
    Camera, 
    FileText, 
    CheckCircle, 
    AlertTriangle,
    Upload,
    RefreshCw
} from 'lucide-react';

const KYC_STEPS = [
    { id: 1, title: 'Personal Information', icon: FileText },
    { id: 2, title: 'Document Upload', icon: Upload },
    { id: 3, title: 'Identity Verification', icon: Camera },
    { id: 4, title: 'Review & Complete', icon: CheckCircle }
];

export default function KYCVerificationFlow({ user, onVerificationComplete }) {
    const [currentStep, setCurrentStep] = useState(1);
    const [loading, setLoading] = useState(false);
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        dateOfBirth: '',
        address: '',
        city: '',
        state: '',
        zipCode: '',
        country: 'United States',
        phoneNumber: '',
        documents: []
    });
    const [sessionId, setSessionId] = useState(null);

    const updateFormData = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleFileUpload = (event) => {
        const files = Array.from(event.target.files);
        updateFormData('documents', [...formData.documents, ...files]);
    };

    const initiateKYC = async () => {
        setLoading(true);
        try {
            const { data } = await kycVerification({
                action: 'initiate_kyc',
                verification_type: 'standard'
            });

            if (data.success) {
                setSessionId(data.session_id);
                setCurrentStep(2);
            }
        } catch (error) {
            console.error('KYC initiation failed:', error);
        } finally {
            setLoading(false);
        }
    };

    const completeKYC = async () => {
        setLoading(true);
        try {
            const { data } = await kycVerification({
                action: 'complete_kyc',
                session_id: sessionId,
                documents: formData.documents.map(f => f.name),
                verification_data: formData
            });

            if (data.success) {
                setCurrentStep(4);
                if (onVerificationComplete) {
                    onVerificationComplete(data);
                }
            }
        } catch (error) {
            console.error('KYC completion failed:', error);
        } finally {
            setLoading(false);
        }
    };

    const renderStep = () => {
        switch (currentStep) {
            case 1:
                return (
                    <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <Label className="text-white">First Name</Label>
                                <Input
                                    value={formData.firstName}
                                    onChange={(e) => updateFormData('firstName', e.target.value)}
                                    className="glass-effect border-white/20 bg-transparent text-white"
                                    placeholder="John"
                                />
                            </div>
                            <div>
                                <Label className="text-white">Last Name</Label>
                                <Input
                                    value={formData.lastName}
                                    onChange={(e) => updateFormData('lastName', e.target.value)}
                                    className="glass-effect border-white/20 bg-transparent text-white"
                                    placeholder="Doe"
                                />
                            </div>
                        </div>

                        <div>
                            <Label className="text-white">Date of Birth</Label>
                            <Input
                                type="date"
                                value={formData.dateOfBirth}
                                onChange={(e) => updateFormData('dateOfBirth', e.target.value)}
                                className="glass-effect border-white/20 bg-transparent text-white"
                            />
                        </div>

                        <div>
                            <Label className="text-white">Street Address</Label>
                            <Input
                                value={formData.address}
                                onChange={(e) => updateFormData('address', e.target.value)}
                                className="glass-effect border-white/20 bg-transparent text-white"
                                placeholder="123 Main Street"
                            />
                        </div>

                        <div className="grid md:grid-cols-3 gap-4">
                            <div>
                                <Label className="text-white">City</Label>
                                <Input
                                    value={formData.city}
                                    onChange={(e) => updateFormData('city', e.target.value)}
                                    className="glass-effect border-white/20 bg-transparent text-white"
                                    placeholder="Phoenix"
                                />
                            </div>
                            <div>
                                <Label className="text-white">State</Label>
                                <Input
                                    value={formData.state}
                                    onChange={(e) => updateFormData('state', e.target.value)}
                                    className="glass-effect border-white/20 bg-transparent text-white"
                                    placeholder="AZ"
                                />
                            </div>
                            <div>
                                <Label className="text-white">ZIP Code</Label>
                                <Input
                                    value={formData.zipCode}
                                    onChange={(e) => updateFormData('zipCode', e.target.value)}
                                    className="glass-effect border-white/20 bg-transparent text-white"
                                    placeholder="85001"
                                />
                            </div>
                        </div>

                        <div>
                            <Label className="text-white">Phone Number</Label>
                            <Input
                                value={formData.phoneNumber}
                                onChange={(e) => updateFormData('phoneNumber', e.target.value)}
                                className="glass-effect border-white/20 bg-transparent text-white"
                                placeholder="(555) 123-4567"
                            />
                        </div>

                        <Button
                            onClick={initiateKYC}
                            disabled={loading || !formData.firstName || !formData.lastName}
                            className="w-full bg-cyan-600 hover:bg-cyan-700"
                        >
                            {loading ? (
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                                <FileText className="w-4 h-4 mr-2" />
                            )}
                            Continue to Document Upload
                        </Button>
                    </div>
                );

            case 2:
                return (
                    <div className="space-y-4">
                        <div className="text-center mb-6">
                            <Upload className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white">Upload Identity Documents</h3>
                            <p className="text-gray-400 text-sm">
                                Please upload a clear photo of your government-issued ID
                            </p>
                        </div>

                        <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center">
                            <input
                                type="file"
                                multiple
                                accept=".jpg,.jpeg,.png,.pdf"
                                onChange={handleFileUpload}
                                className="hidden"
                                id="document-upload"
                            />
                            <label
                                htmlFor="document-upload"
                                className="cursor-pointer block"
                            >
                                <Camera className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                                <p className="text-white mb-1">Click to upload documents</p>
                                <p className="text-gray-400 text-sm">PNG, JPG, or PDF up to 10MB</p>
                            </label>
                        </div>

                        {formData.documents.length > 0 && (
                            <div className="space-y-2">
                                <h4 className="text-white font-medium">Uploaded Documents:</h4>
                                {formData.documents.map((file, index) => (
                                    <div key={index} className="flex items-center justify-between p-2 bg-slate-800/50 rounded">
                                        <span className="text-gray-300 text-sm">{file.name}</span>
                                        <CheckCircle className="w-4 h-4 text-green-400" />
                                    </div>
                                ))}
                            </div>
                        )}

                        <Button
                            onClick={() => setCurrentStep(3)}
                            disabled={formData.documents.length === 0}
                            className="w-full bg-cyan-600 hover:bg-cyan-700"
                        >
                            <Camera className="w-4 h-4 mr-2" />
                            Continue to Identity Verification
                        </Button>
                    </div>
                );

            case 3:
                return (
                    <div className="space-y-4 text-center">
                        <div className="mb-6">
                            <Shield className="w-12 h-12 text-cyan-400 mx-auto mb-4" />
                            <h3 className="text-lg font-semibold text-white">Identity Verification</h3>
                            <p className="text-gray-400 text-sm">
                                We're processing your documents and verifying your identity
                            </p>
                        </div>

                        <div className="bg-slate-800/50 p-6 rounded-lg">
                            <div className="space-y-4">
                                <div className="flex items-center justify-between">
                                    <span className="text-gray-300">Document Review</span>
                                    <CheckCircle className="w-5 h-5 text-green-400" />
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-gray-300">Identity Matching</span>
                                    <RefreshCw className="w-5 h-5 text-cyan-400 animate-spin" />
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-gray-300">Final Verification</span>
                                    <div className="w-5 h-5 border-2 border-gray-600 rounded-full"></div>
                                </div>
                            </div>
                        </div>

                        <Button
                            onClick={completeKYC}
                            disabled={loading}
                            className="w-full bg-green-600 hover:bg-green-700"
                        >
                            {loading ? (
                                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                                <CheckCircle className="w-4 h-4 mr-2" />
                            )}
                            Complete Verification
                        </Button>
                    </div>
                );

            case 4:
                return (
                    <div className="space-y-4 text-center">
                        <div className="mb-6">
                            <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-white">Verification Complete!</h3>
                            <p className="text-gray-400">
                                Your identity has been successfully verified. You can now access all crypto features.
                            </p>
                        </div>

                        <div className="bg-green-600/10 p-4 rounded-lg border border-green-600/20">
                            <p className="text-green-400 text-sm">
                                ✓ Full crypto payment access
                                <br />
                                ✓ Higher transaction limits
                                <br />
                                ✓ Enhanced security features
                            </p>
                        </div>
                    </div>
                );

            default:
                return null;
        }
    };

    const progress = (currentStep / KYC_STEPS.length) * 100;

    return (
        <Card className="glass-effect border-white/10 bg-transparent max-w-2xl mx-auto">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Shield className="w-6 h-6 text-cyan-400" />
                    Identity Verification (KYC)
                </CardTitle>
                <div className="space-y-2">
                    <Progress value={progress} className="h-2" />
                    <div className="flex justify-between text-sm">
                        {KYC_STEPS.map((step) => (
                            <div
                                key={step.id}
                                className={`flex items-center gap-1 ${
                                    currentStep >= step.id ? 'text-cyan-400' : 'text-gray-500'
                                }`}
                            >
                                <step.icon className="w-3 h-3" />
                                <span className="hidden sm:inline">{step.title}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </CardHeader>
            <CardContent>
                {renderStep()}
            </CardContent>
        </Card>
    );
}