import React, { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { ArrowUp, ArrowDown, Loader2 } from 'lucide-react';

const CryptoTicker = () => {
  const [prices, setPrices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isPaused, setIsPaused] = useState(false);

  const fetchPrices = useCallback(async () => {
    try {
      const response = await base44.functions.invoke('cryptoPricing', {
        symbols: 'bitcoin,ethereum,solana,ripple,cardano,dogecoin,binancecoin,usd-coin',
        vs_currency: 'usd'
      });
      if (response.data.success) {
        const gztToken = { symbol: 'gzt', price: 1.00, change_24h: 0.00 };
        const displayOrder = ['gzt', 'bitcoin', 'ethereum', 'solana', 'ripple', 'cardano', 'dogecoin', 'binancecoin', 'usd-coin'];
        
        const priceMap = new Map(response.data.prices.map(p => [p.symbol, p]));
        priceMap.set('gzt', gztToken);

        const orderedPrices = displayOrder
          .map(symbol => priceMap.get(symbol))
          .filter(Boolean);

        setPrices(orderedPrices);
      }
    } catch (error) {
      console.error("Failed to fetch crypto prices for ticker:", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchPrices();
    const interval = setInterval(fetchPrices, 60000); // Refresh every 60 seconds
    return () => clearInterval(interval);
  }, [fetchPrices]);

  const PriceItem = ({ symbol, price, change }) => {
    let colorClass = 'text-[color:var(--ticker-neutral)]';
    if (change > 0) colorClass = 'text-[color:var(--ticker-up)]';
    if (change < 0) colorClass = 'text-[color:var(--ticker-down)]';

    const symbolMap = {
      'gzt': 'GZT',
      'bitcoin': 'BTC',
      'ethereum': 'ETH',
      'usd-coin': 'USDC',
      'binancecoin': 'BNB',
      'cardano': 'ADA',
      'solana': 'SOL',
      'ripple': 'XRP',
      'dogecoin': 'DOGE'
    };
    const displayName = symbolMap[symbol] || symbol.toUpperCase();
    const symbolColor = symbol === 'gzt' ? 'text-[color:var(--gazillion-primary)]' : 'text-white';
    
    const formattedChange = () => {
      const value = change ? change.toFixed(2) : '0.00';
      if (symbol === 'gzt') return `+0.00%`;
      if (change > 0) return `+${value}%`;
      return `${value}%`;
    }

    return (
      <div className="flex items-center space-x-2 mx-4 flex-shrink-0 text-xs sm:text-sm">
        <span className={`font-bold ${symbolColor}`}>{displayName}</span>
        <span className="font-mono text-gray-300">${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        <span className={`font-mono flex items-center font-medium ${colorClass}`}>
          {change > 0 && <ArrowUp className="w-3 h-3" />}
          {change < 0 && <ArrowDown className="w-3 h-3" />}
          {formattedChange()}
        </span>
        <span className="text-gray-600 mx-2">|</span>
      </div>
    );
  };

  if (loading && prices.length === 0) {
    return (
      <div className="bg-slate-950 text-white text-xs py-2 flex items-center justify-center h-[36px]">
        <Loader2 className="w-3 h-3 animate-spin mr-2" />
        <span>Loading Market Data...</span>
      </div>
    );
  }

  if (prices.length === 0) {
    return null;
  }

  return (
    <div 
      className="bg-slate-950 w-full overflow-hidden border-b border-t border-white/10 h-[36px] relative group flex items-center" 
      aria-live="polite"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div 
        className="w-full h-full flex items-center absolute left-0 animate-scroll-left"
        style={{ animationPlayState: isPaused ? 'paused' : 'running' }}
      >
        {[...prices, ...prices, ...prices, ...prices].map((price, index) => (
          <PriceItem 
            key={`${price.symbol}-${index}`} 
            symbol={price.symbol} 
            price={price.price} 
            change={price.change_24h}
          />
        ))}
      </div>
      <div className="absolute left-0 top-0 h-full w-12 bg-gradient-to-r from-slate-950 to-transparent z-10 pointer-events-none"></div>
      <div className="absolute right-0 top-0 h-full w-12 bg-gradient-to-l from-slate-950 to-transparent z-10 pointer-events-none"></div>
    </div>
  );
};

export default CryptoTicker;