
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { walletOperations } from '@/api/functions';
import { cryptoPricing } from '@/api/functions';
import { 
    Bitcoin, 
    Zap, 
    DollarSign, 
    TrendingUp, 
    TrendingDown,
    RefreshCw,
    ExternalLink,
    Clock,
    CheckCircle,
    AlertTriangle
} from 'lucide-react';
import { format } from 'date-fns';

export default function CryptoDashboard({ user }) {
    const [transactions, setTransactions] = useState([]);
    const [balances, setBalances] = useState({});
    const [prices, setPrices] = useState({});
    const [loading, setLoading] = useState(true);

    const loadTransactions = useCallback(async () => {
        try {
            const { data } = await walletOperations({
                action: 'get_transactions',
                address: user?.wallet_address,
                limit: 20
            });
            
            if (data.success) {
                setTransactions(data.transactions);
            }
        } catch (error) {
            console.error('Failed to load transactions:', error);
        }
    }, [user?.wallet_address]);

    const loadBalances = useCallback(async () => {
        if (user?.wallet_address) {
            try {
                const { data } = await walletOperations({
                    action: 'get_balance',
                    address: user.wallet_address
                });
                
                if (data.success) {
                    setBalances(data.balances);
                }
            } catch (error) {
                console.error('Failed to load balances:', error);
            }
        }
    }, [user?.wallet_address]);

    const loadPrices = useCallback(async () => {
        try {
            const { data } = await cryptoPricing({
                symbols: 'bitcoin,ethereum,usd-coin',
                vs_currency: 'usd'
            });
            
            if (data.success) {
                const priceMap = {};
                data.prices.forEach(p => {
                    priceMap[p.symbol] = p;
                });
                setPrices(priceMap);
            }
        } catch (error) {
            console.error('Failed to load prices:', error);
        }
    }, []);

    const loadDashboardData = useCallback(async () => {
        setLoading(true);
        try {
            await Promise.all([
                loadTransactions(),
                loadBalances(),
                loadPrices()
            ]);
        } catch (error) {
            console.error('Failed to load crypto dashboard:', error);
        } finally {
            setLoading(false);
        }
    }, [loadTransactions, loadBalances, loadPrices]);

    useEffect(() => {
        loadDashboardData();
        const interval = setInterval(loadPrices, 60000); // Update prices every minute
        return () => clearInterval(interval);
    }, [loadDashboardData, loadPrices]);

    const getStatusIcon = (status) => {
        switch (status) {
            case 'completed':
                return <CheckCircle className="w-4 h-4 text-green-400" />;
            case 'pending':
                return <Clock className="w-4 h-4 text-yellow-400" />;
            case 'failed':
                return <AlertTriangle className="w-4 h-4 text-red-400" />;
            default:
                return <RefreshCw className="w-4 h-4 text-gray-400" />;
        }
    };

    const getCryptoIcon = (currency) => {
        switch (currency?.toLowerCase()) {
            case 'btc':
            case 'bitcoin':
                return <Bitcoin className="w-5 h-5 text-orange-500" />;
            case 'eth':
            case 'ethereum':
                return <Zap className="w-5 h-5 text-blue-500" />;
            case 'usdc':
            case 'usd-coin':
                return <DollarSign className="w-5 h-5 text-green-500" />;
            default:
                return <DollarSign className="w-5 h-5 text-gray-500" />;
        }
    };

    const formatCurrency = (amount, currency) => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: currency || 'USD'
        }).format(amount);
    };

    const calculatePortfolioValue = () => {
        let total = 0;
        Object.entries(balances).forEach(([currency, balance]) => {
            const price = prices[currency]?.price || 0;
            total += balance * price;
        });
        return total;
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center p-8">
                <RefreshCw className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Portfolio Overview */}
            <div className="grid md:grid-cols-3 gap-6">
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-400 text-sm">Portfolio Value</p>
                                <p className="text-3xl font-bold text-white mt-1">
                                    {formatCurrency(calculatePortfolioValue())}
                                </p>
                            </div>
                            <div className="w-12 h-12 bg-cyan-500/20 rounded-full flex items-center justify-center">
                                <DollarSign className="w-6 h-6 text-cyan-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-400 text-sm">Total Transactions</p>
                                <p className="text-3xl font-bold text-white mt-1">
                                    {transactions.length}
                                </p>
                            </div>
                            <div className="w-12 h-12 bg-blue-500/20 rounded-full flex items-center justify-center">
                                <RefreshCw className="w-6 h-6 text-blue-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>

                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <p className="text-gray-400 text-sm">Active Assets</p>
                                <p className="text-3xl font-bold text-white mt-1">
                                    {Object.keys(balances).length}
                                </p>
                            </div>
                            <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                                <Bitcoin className="w-6 h-6 text-green-400" />
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>

            {/* Detailed Data */}
            <Tabs defaultValue="balances" className="space-y-4">
                <TabsList className="glass-effect bg-transparent border-white/10">
                    <TabsTrigger value="balances">Wallet Balances</TabsTrigger>
                    <TabsTrigger value="transactions">Transaction History</TabsTrigger>
                    <TabsTrigger value="markets">Live Prices</TabsTrigger>
                </TabsList>

                <TabsContent value="balances">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                            <CardTitle className="text-white">Crypto Balances</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {Object.keys(balances).length === 0 ? (
                                <div className="text-center py-8">
                                    <p className="text-gray-400">No crypto assets found</p>
                                    <p className="text-gray-500 text-sm mt-2">
                                        Connect a wallet or make your first crypto purchase
                                    </p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    {Object.entries(balances).map(([currency, balance]) => {
                                        const price = prices[currency]?.price || 0;
                                        const value = balance * price;
                                        return (
                                            <div key={currency} className="flex items-center justify-between p-4 bg-slate-800/30 rounded-lg">
                                                <div className="flex items-center gap-3">
                                                    {getCryptoIcon(currency)}
                                                    <div>
                                                        <p className="text-white font-medium uppercase">{currency}</p>
                                                        <p className="text-gray-400 text-sm">
                                                            {formatCurrency(price)} per {currency.toUpperCase()}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <p className="text-white font-bold">
                                                        {balance.toFixed(6)} {currency.toUpperCase()}
                                                    </p>
                                                    <p className="text-gray-400 text-sm">
                                                        {formatCurrency(value)}
                                                    </p>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="transactions">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                            <CardTitle className="text-white">Recent Transactions</CardTitle>
                        </CardHeader>
                        <CardContent>
                            {transactions.length === 0 ? (
                                <div className="text-center py-8">
                                    <p className="text-gray-400">No transactions found</p>
                                    <p className="text-gray-500 text-sm mt-2">
                                        Your crypto transactions will appear here
                                    </p>
                                </div>
                            ) : (
                                <div className="space-y-3">
                                    {transactions.map((tx) => (
                                        <div key={tx.id} className="flex items-center justify-between p-3 bg-slate-800/30 rounded-lg">
                                            <div className="flex items-center gap-3">
                                                {getStatusIcon(tx.status)}
                                                <div>
                                                    <p className="text-white font-medium">
                                                        {formatCurrency(tx.amount)} → {tx.crypto_amount?.toFixed(6)} {tx.crypto_currency}
                                                    </p>
                                                    <p className="text-gray-400 text-sm">
                                                        {format(new Date(tx.created_date), 'MMM dd, yyyy HH:mm')}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Badge variant={tx.status === 'completed' ? 'success' : 'outline'}>
                                                    {tx.status}
                                                </Badge>
                                                {tx.transaction_hash && (
                                                    <button
                                                        onClick={() => window.open(`https://etherscan.io/tx/${tx.transaction_hash}`, '_blank')}
                                                        className="text-cyan-400 hover:text-cyan-300"
                                                    >
                                                        <ExternalLink className="w-4 h-4" />
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="markets">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                            <CardTitle className="text-white flex items-center justify-between">
                                Live Crypto Prices
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={loadPrices}
                                    className="border-gray-600 text-gray-300"
                                >
                                    <RefreshCw className="w-4 h-4" />
                                </Button>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {Object.keys(prices).length === 0 ? (
                                <div className="text-center py-8">
                                    <RefreshCw className="w-8 h-8 animate-spin text-cyan-400 mx-auto mb-4" />
                                    <p className="text-gray-400">Loading market data...</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    {Object.entries(prices).map(([currency, data]) => (
                                        <div key={currency} className="flex items-center justify-between p-4 bg-slate-800/30 rounded-lg">
                                            <div className="flex items-center gap-3">
                                                {getCryptoIcon(currency)}
                                                <div>
                                                    <p className="text-white font-medium">
                                                        {currency.replace('-', ' ').toUpperCase()}
                                                    </p>
                                                    <p className="text-gray-400 text-sm">
                                                        Last updated: {format(new Date(data.last_updated * 1000), 'HH:mm')}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <p className="text-white font-bold text-xl">
                                                    {formatCurrency(data.price)}
                                                </p>
                                                <div className="flex items-center gap-1">
                                                    {data.change_24h > 0 ? (
                                                        <TrendingUp className="w-4 h-4 text-green-400" />
                                                    ) : (
                                                        <TrendingDown className="w-4 h-4 text-red-400" />
                                                    )}
                                                    <span className={`text-sm ${data.change_24h > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                                        {data.change_24h > 0 ? '+' : ''}{data.change_24h.toFixed(2)}%
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
