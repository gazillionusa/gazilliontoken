import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cryptoPayment } from '@/api/functions';
import { cryptoPricing } from '@/api/functions';
import { walletOperations } from '@/api/functions';
import { 
    Bitcoin, 
    Zap, 
    DollarSign, 
    RefreshCw, 
    CheckCircle, 
    AlertTriangle,
    ExternalLink,
    Wallet,
    QrCode
} from 'lucide-react';

const CRYPTO_OPTIONS = [
    { id: 'bitcoin', name: 'Bitcoin', symbol: 'BTC', icon: Bitcoin, color: 'bg-orange-500' },
    { id: 'ethereum', name: 'Ethereum', symbol: 'ETH', icon: Zap, color: 'bg-blue-500' },
    { id: 'usd-coin', name: 'USD Coin', symbol: 'USDC', icon: DollarSign, color: 'bg-green-500' }
];

export default function CryptoPaymentModal({ 
    isOpen, 
    onClose, 
    bond, 
    amount, 
    onPaymentComplete 
}) {
    const [selectedCrypto, setSelectedCrypto] = useState('bitcoin');
    const [prices, setPrices] = useState({});
    const [loading, setLoading] = useState(false);
    const [step, setStep] = useState(1); // 1: Select, 2: Payment, 3: Complete
    const [chargeData, setChargeData] = useState(null);
    const [paymentStatus, setPaymentStatus] = useState('pending');

    useEffect(() => {
        if (isOpen) {
            loadPrices();
            const interval = setInterval(loadPrices, 30000); // Update every 30s
            return () => clearInterval(interval);
        }
    }, [isOpen]);

    const loadPrices = async () => {
        try {
            const { data } = await cryptoPricing({
                symbols: 'bitcoin,ethereum,usd-coin',
                vs_currency: 'usd'
            });
            
            if (data.success) {
                const priceMap = {};
                data.prices.forEach(p => {
                    priceMap[p.symbol] = p;
                });
                setPrices(priceMap);
            }
        } catch (error) {
            console.error('Failed to load crypto prices:', error);
        }
    };

    const calculateCryptoAmount = (cryptoId) => {
        const price = prices[cryptoId]?.price;
        return price ? (amount / price).toFixed(8) : '0';
    };

    const handleCreatePayment = async () => {
        setLoading(true);
        try {
            const { data } = await cryptoPayment({
                action: 'create_charge',
                amount: amount,
                currency: 'USD',
                crypto_currency: selectedCrypto.toUpperCase(),
                bond_id: bond.id,
                metadata: {
                    bond_name: bond.bond_name,
                    municipality: bond.municipality
                }
            });

            if (data.success) {
                setChargeData(data);
                setStep(2);
                // Start polling for payment status
                pollPaymentStatus(data.charge_id);
            }
        } catch (error) {
            console.error('Payment creation failed:', error);
        } finally {
            setLoading(false);
        }
    };

    const pollPaymentStatus = (chargeId) => {
        const interval = setInterval(async () => {
            try {
                const { data } = await cryptoPayment({
                    action: 'check_status',
                    charge_id: chargeId
                });

                if (data.success && data.status) {
                    setPaymentStatus(data.status);
                    
                    if (data.status === 'COMPLETED') {
                        setStep(3);
                        clearInterval(interval);
                        if (onPaymentComplete) {
                            onPaymentComplete(data);
                        }
                    } else if (data.status === 'EXPIRED' || data.status === 'CANCELLED') {
                        clearInterval(interval);
                    }
                }
            } catch (error) {
                console.error('Status check failed:', error);
            }
        }, 5000); // Poll every 5 seconds
    };

    const selectedCryptoData = CRYPTO_OPTIONS.find(c => c.id === selectedCrypto);
    const Icon = selectedCryptoData?.icon || Bitcoin;

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="glass-effect border-white/10 bg-slate-900 text-white max-w-md">
                <DialogHeader>
                    <DialogTitle className="text-xl">
                        Pay with Cryptocurrency
                    </DialogTitle>
                </DialogHeader>

                {step === 1 && (
                    <div className="space-y-6">
                        <div className="text-center">
                            <p className="text-3xl font-bold text-white mb-2">
                                ${amount.toLocaleString()}
                            </p>
                            <p className="text-gray-400">
                                for {bond?.bond_name}
                            </p>
                        </div>

                        <Tabs value={selectedCrypto} onValueChange={setSelectedCrypto}>
                            <TabsList className="grid w-full grid-cols-3 bg-slate-800">
                                {CRYPTO_OPTIONS.map((crypto) => (
                                    <TabsTrigger 
                                        key={crypto.id}
                                        value={crypto.id}
                                        className="data-[state=active]:bg-slate-700"
                                    >
                                        <crypto.icon className="w-4 h-4 mr-2" />
                                        {crypto.symbol}
                                    </TabsTrigger>
                                ))}
                            </TabsList>

                            {CRYPTO_OPTIONS.map((crypto) => (
                                <TabsContent key={crypto.id} value={crypto.id}>
                                    <Card className="bg-slate-800 border-slate-700 p-4">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center gap-3">
                                                <div className={`w-10 h-10 ${crypto.color} rounded-full flex items-center justify-center`}>
                                                    <crypto.icon className="w-5 h-5 text-white" />
                                                </div>
                                                <div>
                                                    <p className="font-semibold">{crypto.name}</p>
                                                    <p className="text-sm text-gray-400">
                                                        ${prices[crypto.id]?.price?.toLocaleString() || '---'}
                                                    </p>
                                                </div>
                                            </div>
                                            <div className="text-right">
                                                <p className="font-bold text-lg">
                                                    {calculateCryptoAmount(crypto.id)} {crypto.symbol}
                                                </p>
                                                {prices[crypto.id]?.change_24h && (
                                                    <Badge variant={prices[crypto.id].change_24h > 0 ? 'success' : 'destructive'}>
                                                        {prices[crypto.id].change_24h > 0 ? '+' : ''}
                                                        {prices[crypto.id].change_24h.toFixed(2)}%
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                    </Card>
                                </TabsContent>
                            ))}
                        </Tabs>

                        <div className="flex gap-3">
                            <Button
                                variant="outline"
                                onClick={onClose}
                                className="flex-1 border-gray-600 text-gray-300"
                            >
                                Cancel
                            </Button>
                            <Button
                                onClick={handleCreatePayment}
                                disabled={loading || !prices[selectedCrypto]}
                                className="flex-1 bg-cyan-600 hover:bg-cyan-700"
                            >
                                {loading ? (
                                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                ) : (
                                    <Icon className="w-4 h-4 mr-2" />
                                )}
                                Pay with {selectedCryptoData?.symbol}
                            </Button>
                        </div>
                    </div>
                )}

                {step === 2 && chargeData && (
                    <div className="space-y-6 text-center">
                        <div className="space-y-4">
                            <div className={`w-16 h-16 ${selectedCryptoData?.color} rounded-full flex items-center justify-center mx-auto`}>
                                <Icon className="w-8 h-8 text-white" />
                            </div>
                            
                            <div>
                                <h3 className="text-xl font-bold mb-2">Complete Your Payment</h3>
                                <p className="text-gray-400 mb-4">
                                    Send exactly {calculateCryptoAmount(selectedCrypto)} {selectedCryptoData?.symbol}
                                </p>
                                
                                <div className="bg-slate-800 p-4 rounded-lg border border-slate-700">
                                    <p className="text-sm text-gray-400 mb-2">Payment Address:</p>
                                    <p className="font-mono text-sm break-all bg-slate-900 p-2 rounded">
                                        {chargeData.addresses?.[selectedCrypto] || 'Address loading...'}
                                    </p>
                                </div>

                                <div className="mt-4">
                                    <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                                        <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                                        Waiting for payment...
                                    </Badge>
                                </div>
                            </div>
                        </div>

                        <div className="flex gap-3">
                            <Button
                                variant="outline"
                                onClick={() => window.open(chargeData.hosted_url, '_blank')}
                                className="flex-1 border-gray-600 text-gray-300"
                            >
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Open Payment Page
                            </Button>
                            <Button
                                variant="outline"
                                onClick={onClose}
                                className="flex-1 border-gray-600 text-gray-300"
                            >
                                Close
                            </Button>
                        </div>
                    </div>
                )}

                {step === 3 && (
                    <div className="space-y-6 text-center">
                        <div className="space-y-4">
                            <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto">
                                <CheckCircle className="w-8 h-8 text-white" />
                            </div>
                            
                            <div>
                                <h3 className="text-xl font-bold mb-2 text-green-400">Payment Complete!</h3>
                                <p className="text-gray-400 mb-4">
                                    Your {selectedCryptoData?.symbol} payment has been confirmed.
                                </p>
                                <p className="text-sm text-gray-500">
                                    Your NFT bond will be minted shortly.
                                </p>
                            </div>
                        </div>

                        <Button
                            onClick={onClose}
                            className="w-full bg-green-600 hover:bg-green-700"
                        >
                            Continue to Dashboard
                        </Button>
                    </div>
                )}
            </DialogContent>
        </Dialog>
    );
}