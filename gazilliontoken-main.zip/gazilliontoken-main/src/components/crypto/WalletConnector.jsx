import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { walletOperations } from '@/api/functions';
import { 
    Wallet, 
    ExternalLink, 
    CheckCircle, 
    AlertTriangle,
    RefreshCw,
    Copy,
    Unlink
} from 'lucide-react';

const WALLET_TYPES = [
    {
        id: 'metamask',
        name: 'MetaMask',
        icon: '🦊',
        description: 'Most popular Ethereum wallet'
    },
    {
        id: 'walletconnect',
        name: 'WalletConnect',
        icon: '🔗',
        description: 'Connect to mobile wallets'
    },
    {
        id: 'coinbase',
        name: 'Coinbase Wallet',
        icon: '🏦',
        description: 'Coinbase self-custody wallet'
    }
];

export default function WalletConnector({ user, onWalletConnected }) {
    const [connecting, setConnecting] = useState(false);
    const [selectedWallet, setSelectedWallet] = useState(null);
    const [walletInfo, setWalletInfo] = useState(null);
    const [balances, setBalances] = useState({});

    useEffect(() => {
        if (user?.wallet_address) {
            setWalletInfo({
                address: user.wallet_address,
                type: user.wallet_type || 'unknown',
                connected_at: user.wallet_connected_at
            });
            loadBalances(user.wallet_address);
        }
    }, [user]);

    const loadBalances = async (address) => {
        try {
            const { data } = await walletOperations({
                action: 'get_balance',
                address: address
            });
            
            if (data.success) {
                setBalances(data.balances);
            }
        } catch (error) {
            console.error('Failed to load wallet balances:', error);
        }
    };

    const connectWallet = async (walletType) => {
        setConnecting(true);
        setSelectedWallet(walletType);

        try {
            if (walletType.id === 'metamask') {
                if (typeof window.ethereum !== 'undefined') {
                    const accounts = await window.ethereum.request({
                        method: 'eth_requestAccounts'
                    });
                    
                    const chainId = await window.ethereum.request({
                        method: 'eth_chainId'
                    });

                    if (accounts.length > 0) {
                        const { data } = await walletOperations({
                            action: 'connect_wallet',
                            address: accounts[0],
                            wallet_type: walletType.name,
                            chain_id: chainId
                        });

                        if (data.success) {
                            setWalletInfo({
                                address: accounts[0],
                                type: walletType.name,
                                connected_at: new Date().toISOString()
                            });
                            
                            loadBalances(accounts[0]);
                            
                            if (onWalletConnected) {
                                onWalletConnected({
                                    address: accounts[0],
                                    type: walletType.name
                                });
                            }
                        }
                    }
                } else {
                    alert('MetaMask is not installed. Please install MetaMask to continue.');
                    window.open('https://metamask.io/download/', '_blank');
                }
            } else {
                // For other wallet types, show installation/connection instructions
                alert(`${walletType.name} connection coming soon!`);
            }
        } catch (error) {
            console.error('Wallet connection failed:', error);
            alert('Failed to connect wallet. Please try again.');
        } finally {
            setConnecting(false);
            setSelectedWallet(null);
        }
    };

    const disconnectWallet = async () => {
        try {
            // In a real implementation, you might want to keep the wallet info
            // but mark it as disconnected or allow users to manage multiple wallets
            setWalletInfo(null);
            setBalances({});
            
            if (onWalletConnected) {
                onWalletConnected(null);
            }
        } catch (error) {
            console.error('Failed to disconnect wallet:', error);
        }
    };

    const copyAddress = () => {
        if (walletInfo?.address) {
            navigator.clipboard.writeText(walletInfo.address);
            // You could add a toast notification here
        }
    };

    const formatAddress = (address) => {
        return `${address.slice(0, 6)}...${address.slice(-4)}`;
    };

    const formatBalance = (amount, decimals = 4) => {
        return parseFloat(amount).toFixed(decimals);
    };

    if (walletInfo) {
        return (
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-400" />
                        Wallet Connected
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
                        <div>
                            <p className="text-white font-medium">{walletInfo.type}</p>
                            <p className="text-gray-400 text-sm font-mono">
                                {formatAddress(walletInfo.address)}
                            </p>
                        </div>
                        <div className="flex gap-2">
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={copyAddress}
                                className="border-gray-600 text-gray-300"
                            >
                                <Copy className="w-4 h-4" />
                            </Button>
                            <Button
                                size="sm"
                                variant="outline"
                                onClick={disconnectWallet}
                                className="border-red-600 text-red-400 hover:bg-red-600/10"
                            >
                                <Unlink className="w-4 h-4" />
                            </Button>
                        </div>
                    </div>

                    {Object.keys(balances).length > 0 && (
                        <div className="space-y-2">
                            <h4 className="text-white font-medium">Balances</h4>
                            <div className="grid gap-2">
                                {Object.entries(balances).map(([currency, balance]) => (
                                    <div key={currency} className="flex justify-between p-2 bg-slate-800/30 rounded">
                                        <span className="text-gray-400 uppercase">{currency}</span>
                                        <span className="text-white font-medium">
                                            {formatBalance(balance)} {currency.toUpperCase()}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </CardContent>
            </Card>
        );
    }

    return (
        <Card className="glass-effect border-white/10 bg-transparent">
            <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                    <Wallet className="w-5 h-5 text-cyan-400" />
                    Connect Crypto Wallet
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p className="text-gray-400 text-sm">
                    Connect your crypto wallet to make payments and manage your digital assets.
                </p>

                <div className="grid gap-3">
                    {WALLET_TYPES.map((wallet) => (
                        <Button
                            key={wallet.id}
                            variant="outline"
                            onClick={() => connectWallet(wallet)}
                            disabled={connecting}
                            className="w-full justify-start h-auto p-4 border-gray-600 text-gray-300 hover:bg-white/10"
                        >
                            <div className="flex items-center gap-3">
                                <span className="text-2xl">{wallet.icon}</span>
                                <div className="text-left">
                                    <p className="font-medium">{wallet.name}</p>
                                    <p className="text-sm text-gray-400">{wallet.description}</p>
                                </div>
                                {connecting && selectedWallet?.id === wallet.id && (
                                    <RefreshCw className="w-4 h-4 ml-auto animate-spin" />
                                )}
                            </div>
                        </Button>
                    ))}
                </div>

                <div className="pt-2 border-t border-gray-700">
                    <p className="text-xs text-gray-500 text-center">
                        Your wallet connection is encrypted and secure. We never store your private keys.
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}