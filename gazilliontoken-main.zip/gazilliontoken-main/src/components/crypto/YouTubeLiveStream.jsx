import React, { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Wifi, Play, Calendar, ExternalLink } from 'lucide-react';

export default function YouTubeLiveStream() {
  const playerRef = useRef(null);
  const [isLive, setIsLive] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [videoTitle, setVideoTitle] = useState('');
  const [channelId, setChannelId] = useState(null);

  // Gazillon YouTube channel
  const CHANNEL_USERNAME = "gazillon";
  const CHANNEL_URL = "https://www.youtube.com/@gazillon";
  const FALLBACK_VIDEO_ID = "jfKfPfyJRdk"; // lofi hip hop radio - Replace with your latest video
  const API_KEY = "AIzaSyDummy_Replace_With_Real_Key"; // Replace with actual YouTube Data API key

  useEffect(() => {
    const getChannelId = async () => {
      try {
        // First, get the channel ID from the username
        const channelUrl = `https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=${CHANNEL_USERNAME}&key=${API_KEY}`;
        const response = await fetch(channelUrl);
        const data = await response.json();
        
        if (data.items && data.items.length > 0) {
          return data.items[0].id;
        }
        return null;
      } catch (error) {
        console.error('Error getting channel ID:', error);
        return null;
      }
    };

    const checkLiveStatus = async (channelIdToUse) => {
      try {
        setIsLoading(true);
        
        if (!channelIdToUse) {
          // If no channel ID, use fallback
          setIsLive(false);
          setVideoTitle('Gazillon Crypto News');
          if (playerRef.current && playerRef.current.loadVideoById) {
            playerRef.current.loadVideoById(FALLBACK_VIDEO_ID);
          }
          return;
        }

        // Check for live streams
        const liveUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelIdToUse}&type=video&eventType=live&key=${API_KEY}`;
        
        const response = await fetch(liveUrl);
        const data = await response.json();

        if (data.items && data.items.length > 0) {
          // Live stream found
          const liveVideo = data.items[0];
          setIsLive(true);
          setVideoTitle(liveVideo.snippet.title);
          if (playerRef.current && playerRef.current.loadVideoById) {
            playerRef.current.loadVideoById(liveVideo.id.videoId);
          }
        } else {
          // No live stream, load latest video
          const latestUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelIdToUse}&type=video&order=date&maxResults=1&key=${API_KEY}`;
          
          const latestResponse = await fetch(latestUrl);
          const latestData = await latestResponse.json();
          
          if (latestData.items && latestData.items.length > 0) {
            const latestVideo = latestData.items[0];
            setIsLive(false);
            setVideoTitle(latestVideo.snippet.title);
            if (playerRef.current && playerRef.current.loadVideoById) {
              playerRef.current.loadVideoById(latestVideo.id.videoId);
            }
          } else {
            // Fallback to hardcoded video
            setIsLive(false);
            setVideoTitle('Latest Crypto News');
            if (playerRef.current && playerRef.current.loadVideoById) {
              playerRef.current.loadVideoById(FALLBACK_VIDEO_ID);
            }
          }
        }
      } catch (error) {
        console.error('Error checking live status:', error);
        // Fallback to hardcoded video
        setIsLive(false);
        setVideoTitle('Crypto Market Update');
        if (playerRef.current && playerRef.current.loadVideoById) {
          playerRef.current.loadVideoById(FALLBACK_VIDEO_ID);
        }
      } finally {
        setIsLoading(false);
      }
    };

    const initializePlayer = async () => {
      // Get channel ID first
      const channelIdResult = await getChannelId();
      setChannelId(channelIdResult);

      playerRef.current = new window.YT.Player('youtube-player', {
        height: '450',
        width: '100%',
        playerVars: {
          autoplay: 0,
          controls: 1,
          modestbranding: 1,
          rel: 0
        },
        events: {
          onReady: () => checkLiveStatus(channelIdResult)
        }
      });
    };

    // Load YouTube IFrame API
    if (!window.YT) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      const firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

      // Setup callback for when API is ready
      window.onYouTubeIframeAPIReady = initializePlayer;
    } else {
      initializePlayer();
    }

    return () => {
      if (playerRef.current && playerRef.current.destroy) {
        try {
          playerRef.current.destroy();
        } catch (e) {
          // Player already destroyed
        }
      }
    };
  }, [CHANNEL_USERNAME, FALLBACK_VIDEO_ID, API_KEY]);

  return (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <CardTitle className="text-white text-xl flex items-center gap-3">
            <Play className="w-6 h-6 text-cyan-400" />
            Gazillon Crypto News Live
          </CardTitle>
          <div className="flex items-center gap-3">
            {isLive && (
              <Badge className="bg-red-500 text-white animate-pulse flex items-center gap-2">
                <Wifi className="w-4 h-4" />
                LIVE
              </Badge>
            )}
            {!isLive && !isLoading && (
              <Badge className="bg-gray-600 text-white flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Latest Upload
              </Badge>
            )}
            <a 
              href={CHANNEL_URL} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              <Button variant="outline" size="sm" className="gap-2 border-cyan-400/30 hover:border-cyan-400/50">
                <ExternalLink className="w-4 h-4" />
                <span className="hidden sm:inline">Visit Channel</span>
              </Button>
            </a>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading && (
          <div className="w-full h-[450px] bg-slate-800/50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400 mx-auto mb-4"></div>
              <p className="text-gray-400">Loading Gazillon stream...</p>
            </div>
          </div>
        )}
        
        <div id="youtube-player" className={`w-full rounded-lg overflow-hidden ${isLoading ? 'hidden' : 'block'}`}></div>
        
        {videoTitle && !isLoading && (
          <div className="mt-4 p-4 glass-effect rounded-lg">
            <h3 className="text-white font-semibold mb-2">
              {isLive ? '🔴 Now Streaming Live' : '📺 Latest Video'}
            </h3>
            <p className="text-gray-300">{videoTitle}</p>
            <a 
              href={CHANNEL_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 text-sm mt-2 inline-flex items-center gap-1"
            >
              Subscribe to Gazillon for more crypto insights
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        )}

        <div className="mt-4 p-4 bg-amber-500/10 border border-amber-500/30 rounded-lg">
          <p className="text-amber-300 text-sm">
            <strong>Setup Required:</strong> To enable live stream detection and load latest videos automatically, add a YouTube Data API key to the environment variables. 
            <a 
              href="https://console.cloud.google.com/apis/credentials" 
              target="_blank" 
              rel="noopener noreferrer"
              className="underline hover:text-amber-200 ml-1"
            >
              Get API Key
            </a>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}