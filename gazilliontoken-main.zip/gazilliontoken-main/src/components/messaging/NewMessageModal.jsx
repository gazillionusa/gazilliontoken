
import React, { useState, useEffect, useCallback } from 'react';
import { User } from '@/api/entities';
import { sendMessage } from '@/api/functions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Search, Send, X } from 'lucide-react';
import { toast } from "sonner";

export default function NewMessageModal({ isOpen, onClose, currentUser }) {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  const loadUsers = useCallback(async () => {
    try {
      const allUsers = await User.list();
      // Filter out the current user
      const otherUsers = allUsers.filter((user) => user.email !== currentUser?.email);
      setUsers(otherUsers);
      setFilteredUsers(otherUsers);
    } catch (error) {
      console.error("Failed to load users:", error);
      toast.error("Failed to load users.");
    }
  }, [currentUser?.email]);

  useEffect(() => {
    if (isOpen) {
      loadUsers();
    }
  }, [isOpen, loadUsers]);

  useEffect(() => {
    if (searchTerm) {
      const filtered = users.filter((user) =>
      user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(users);
    }
  }, [users, searchTerm]);

  const handleSendMessage = async () => {
    if (!selectedUser || !message.trim()) {
      toast.error("Please select a recipient and enter a message.");
      return;
    }

    setSending(true);
    try {
      await sendMessage({
        recipientId: selectedUser.id,
        content: message.trim(),
        messageType: 'text'
      });

      toast.success(`Message sent to ${selectedUser.full_name}!`);
      onClose();
      resetForm();
    } catch (error) {
      console.error("Failed to send message:", error);
      toast.error("Failed to send message. Please try again.");
    } finally {
      setSending(false);
    }
  };

  const resetForm = () => {
    setSelectedUser(null);
    setMessage('');
    setSearchTerm('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
            <DialogContent className="glass-effect border-white/10 bg-slate-900 text-white max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="text-white text-xl">Start New Conversation</DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    {/* User Selection */}
                    {!selectedUser ?
          <div className="space-y-4">
                            <div className="relative">
                                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                                <Input
                placeholder="Search for ZooKeepers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 glass-effect border-white/20 bg-transparent text-white" />

                            </div>

                            <div className="max-h-60 overflow-y-auto space-y-2">
                                {filteredUsers.map((user) =>
              <div
                key={user.id}
                onClick={() => setSelectedUser(user)}
                className="flex items-center gap-3 p-3 glass-effect rounded-lg border border-white/10 hover:bg-white/5 cursor-pointer transition-all">

                                        <Avatar className="w-10 h-10 border-2 border-cyan-400/30">
                                            <AvatarImage src={user.avatar_image_url} alt={user.full_name} />
                                            <AvatarFallback>{user.full_name?.charAt(0) || user.email.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <div className="flex-1">
                                            <p className="font-semibold text-white">{user.full_name || 'Anonymous ZooKeeper'}</p>
                                            <p className="text-sm text-gray-400">{user.email}</p>
                                        </div>
                                    </div>
              )}
                            </div>

                            {filteredUsers.length === 0 &&
            <div className="text-center py-8 text-gray-400">
                                    {searchTerm ? 'No users found matching your search.' : 'No other users available.'}
                                </div>
            }
                        </div> :

          <div className="space-y-4">
                            {/* Selected User */}
                            <div className="flex items-center gap-3 p-3 glass-effect rounded-lg border border-cyan-400/30">
                                <Avatar className="w-10 h-10 border-2 border-cyan-400/30">
                                    <AvatarImage src={selectedUser.avatar_image_url} alt={selectedUser.full_name} />
                                    <AvatarFallback>{selectedUser.full_name?.charAt(0) || selectedUser.email.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                    <p className="font-semibold text-white">{selectedUser.full_name || 'Anonymous ZooKeeper'}</p>
                                    <p className="text-sm text-gray-400">Sending message to this ZooKeeper</p>
                                </div>
                                <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedUser(null)}
                className="text-gray-400 hover:text-white">

                                    <X className="w-4 h-4" />
                                </Button>
                            </div>

                            {/* Message Input */}
                            <div className="space-y-3">
                                <Textarea
                placeholder="Type your message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="glass-effect border-white/20 bg-transparent text-white placeholder-gray-400 min-h-24" />


                                <div className="flex justify-end gap-3">
                                    <Button
                  variant="outline"
                  onClick={handleClose}
                  disabled={sending} className="bg-background text-slate-950 px-4 py-2 text-sm font-medium inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 border-white/20 hover:bg-white/10">


                                        Cancel
                                    </Button>
                                    <Button
                  onClick={handleSendMessage}
                  disabled={sending || !message.trim()}
                  className="primary-gradient text-white">

                                        {sending ?
                  <div className="flex items-center gap-2">
                                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                                                Sending...
                                            </div> :

                  <>
                                                <Send className="w-4 h-4 mr-2" />
                                                Send Message
                                            </>
                  }
                                    </Button>
                                </div>
                            </div>
                        </div>
          }
                </div>
            </DialogContent>
        </Dialog>);

}