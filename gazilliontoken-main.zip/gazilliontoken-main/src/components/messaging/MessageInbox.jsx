
import React, { useState, useEffect, useCallback } from 'react';
import { MessageThread } from '@/api/entities';
import { User } from '@/api/entities';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  MessageSquare, 
  Search, 
  Plus, 
  Shield, 
  Clock,
  Archive
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import NewMessageModal from '@/components/messaging/NewMessageModal';

export default function MessageInbox() {
    const [threads, setThreads] = useState([]);
    const [filteredThreads, setFilteredThreads] = useState([]);
    const [currentUser, setCurrentUser] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all'); // all, unread, admin
    const [showNewMessageModal, setShowNewMessageModal] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            const user = await User.me();
            setCurrentUser(user);
            
            const userThreads = await MessageThread.list('-last_message_timestamp');
            // Filter threads where current user is a participant
            const myThreads = userThreads.filter(thread => 
                thread.participants && thread.participants.includes(user.id)
            );
            setThreads(myThreads);
        } catch (error) {
            console.error("Failed to load messages:", error);
        } finally {
            setLoading(false);
        }
    };

    const filterThreads = useCallback(() => {
        let filtered = [...threads];

        // Apply search filter
        if (searchTerm) {
            filtered = filtered.filter(thread =>
                thread.participant_names?.some(name => 
                    name.toLowerCase().includes(searchTerm.toLowerCase())
                ) || 
                thread.last_message_content?.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        // Apply category filter
        switch (filter) {
            case 'unread':
                filtered = filtered.filter(thread => (thread.unread_count || 0) > 0);
                break;
            case 'admin':
                filtered = filtered.filter(thread => thread.is_admin_thread);
                break;
            default:
                break;
        }

        setFilteredThreads(filtered);
    }, [threads, searchTerm, filter]);

    useEffect(() => {
        filterThreads();
    }, [filterThreads]);

    const getOtherParticipant = (thread) => {
        if (!currentUser || !thread.participants) return null;
        const otherUserId = thread.participants.find(id => id !== currentUser.id);
        const otherUserIndex = thread.participants.indexOf(otherUserId);
        return {
            name: thread.participant_names?.[otherUserIndex] || 'Unknown User',
            avatar: thread.participant_avatars?.[otherUserIndex]
        };
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="animate-spin w-8 h-8 border-2 border-cyan-400/20 border-t-cyan-400 rounded-full"></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen px-6 py-12">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
                    <div>
                        <h1 className="text-3xl font-bold text-white mb-2">
                            <MessageSquare className="w-8 h-8 inline-block mr-3 text-cyan-400" />
                            Messages
                        </h1>
                        <p className="text-gray-400">Connect with fellow ZooKeepers and Gazillion HQ</p>
                    </div>
                    <Button 
                        onClick={() => setShowNewMessageModal(true)}
                        className="primary-gradient text-white mt-4 md:mt-0"
                    >
                        <Plus className="w-4 h-4 mr-2" />
                        New Message
                    </Button>
                </div>

                {/* Search and Filters */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                    <div className="relative flex-1">
                        <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                            placeholder="Search messages..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="pl-10 glass-effect border-white/20 bg-transparent text-white"
                        />
                    </div>
                    <div className="flex gap-2">
                        <Button
                            variant={filter === 'all' ? 'default' : 'outline'}
                            onClick={() => setFilter('all')}
                            size="sm"
                        >
                            All
                        </Button>
                        <Button
                            variant={filter === 'unread' ? 'default' : 'outline'}
                            onClick={() => setFilter('unread')}
                            size="sm"
                        >
                            Unread
                        </Button>
                        <Button
                            variant={filter === 'admin' ? 'default' : 'outline'}
                            onClick={() => setFilter('admin')}
                            size="sm"
                        >
                            <Shield className="w-4 h-4 mr-1" />
                            Admin
                        </Button>
                    </div>
                </div>

                {/* Message Threads */}
                <div className="space-y-4">
                    {filteredThreads.length === 0 ? (
                        <Card className="glass-effect border-white/10 bg-transparent p-8 text-center">
                            <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-white mb-2">No Messages</h3>
                            <p className="text-gray-400">
                                {searchTerm || filter !== 'all' 
                                    ? 'No messages match your search criteria.' 
                                    : 'Start a conversation with fellow ZooKeepers!'
                                }
                            </p>
                        </Card>
                    ) : (
                        filteredThreads.map((thread) => {
                            const otherParticipant = getOtherParticipant(thread);
                            const isUnread = (thread.unread_count || 0) > 0;

                            return (
                                <Link key={thread.id} to={createPageUrl(`MessageThread?id=${thread.id}`)}>
                                    <Card className={`glass-effect border-white/10 bg-transparent hover:bg-white/5 transition-all duration-300 ${isUnread ? 'border-cyan-400/30' : ''}`}>
                                        <div className="p-4 flex items-center gap-4">
                                            <div className="relative">
                                                <Avatar className="w-12 h-12 border-2 border-cyan-400/30">
                                                    <AvatarImage src={otherParticipant?.avatar} />
                                                    <AvatarFallback>
                                                        {otherParticipant?.name?.charAt(0) || 'U'}
                                                    </AvatarFallback>
                                                </Avatar>
                                                {thread.is_admin_thread && (
                                                    <div className="absolute -bottom-1 -right-1 bg-amber-500 rounded-full p-1">
                                                        <Shield className="w-3 h-3 text-white" />
                                                    </div>
                                                )}
                                            </div>
                                            
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center justify-between mb-1">
                                                    <h3 className={`font-semibold ${isUnread ? 'text-white' : 'text-gray-300'}`}>
                                                        {thread.is_admin_thread ? 'Gazillion HQ' : otherParticipant?.name || 'Unknown User'}
                                                    </h3>
                                                    <div className="flex items-center gap-2">
                                                        {isUnread && (
                                                            <Badge className="bg-cyan-500 text-white text-xs">
                                                                {thread.unread_count}
                                                            </Badge>
                                                        )}
                                                        <span className="text-xs text-gray-400">
                                                            <Clock className="w-3 h-3 inline mr-1" />
                                                            {formatDistanceToNow(new Date(thread.last_message_timestamp), { addSuffix: true })}
                                                        </span>
                                                    </div>
                                                </div>
                                                <p className={`text-sm truncate ${isUnread ? 'text-gray-200' : 'text-gray-400'}`}>
                                                    {thread.last_sender_name}: {thread.last_message_content}
                                                </p>
                                            </div>
                                        </div>
                                    </Card>
                                </Link>
                            );
                        })
                    )}
                </div>
            </div>

            {/* New Message Modal */}
            <NewMessageModal
                isOpen={showNewMessageModal}
                onClose={() => setShowNewMessageModal(false)}
                currentUser={currentUser}
            />
        </div>
    );
}
