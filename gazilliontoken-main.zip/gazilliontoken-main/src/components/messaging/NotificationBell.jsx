import React, { useState, useEffect } from 'react';
import { Notification } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Bell, MessageSquare, Award, DollarSign, Users } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function NotificationBell() {
    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [currentUser, setCurrentUser] = useState(null);

    useEffect(() => {
        loadNotifications();
        
        // Poll for new notifications every 30 seconds
        const interval = setInterval(loadNotifications, 30000);
        return () => clearInterval(interval);
    }, []);

    const loadNotifications = async () => {
        try {
            const user = await User.me();
            if (!user) return;
            
            setCurrentUser(user);
            
            // Get recent notifications for this user
            const userNotifications = await Notification.filter(
                { user_id: user.id },
                '-created_date',
                20
            );
            
            setNotifications(userNotifications);
            setUnreadCount(userNotifications.filter(n => !n.is_read).length);
        } catch (error) {
            console.error("Failed to load notifications:", error);
        }
    };

    const markAsRead = async (notificationId) => {
        try {
            await Notification.update(notificationId, { is_read: true });
            setNotifications(prev => 
                prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
            );
            setUnreadCount(prev => Math.max(0, prev - 1));
        } catch (error) {
            console.error("Failed to mark notification as read:", error);
        }
    };

    const getNotificationIcon = (type) => {
        switch (type) {
            case 'message': return MessageSquare;
            case 'achievement': return Award;
            case 'bond_purchase': return DollarSign;
            case 'friend_request': return Users;
            default: return Bell;
        }
    };

    if (!currentUser) return null;

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="relative text-white hover:bg-white/10">
                    <Bell className="w-5 h-5" />
                    {unreadCount > 0 && (
                        <Badge className="absolute -top-1 -right-1 bg-red-500 text-white text-xs min-w-[1.25rem] h-5 flex items-center justify-center rounded-full">
                            {unreadCount > 9 ? '9+' : unreadCount}
                        </Badge>
                    )}
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-80 bg-slate-800 border-white/10 text-white max-h-96 overflow-y-auto">
                <div className="p-3 border-b border-white/10">
                    <h3 className="font-semibold">Notifications</h3>
                    {unreadCount > 0 && (
                        <p className="text-xs text-gray-400">{unreadCount} unread</p>
                    )}
                </div>
                
                {notifications.length === 0 ? (
                    <div className="p-4 text-center text-gray-400">
                        <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No notifications yet</p>
                    </div>
                ) : (
                    notifications.map((notification) => {
                        const Icon = getNotificationIcon(notification.type);
                        return (
                            <DropdownMenuItem 
                                key={notification.id}
                                className={`p-3 cursor-pointer hover:bg-white/10 ${!notification.is_read ? 'bg-cyan-400/5' : ''}`}
                                onClick={() => {
                                    markAsRead(notification.id);
                                    if (notification.action_url) {
                                        // Navigate to the action URL
                                        window.location.href = notification.action_url;
                                    }
                                }}
                            >
                                <div className="flex items-start gap-3 w-full">
                                    <div className={`p-2 rounded-full ${!notification.is_read ? 'bg-cyan-400/20' : 'bg-white/10'}`}>
                                        <Icon className="w-4 h-4 text-cyan-400" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <p className={`font-medium text-sm ${!notification.is_read ? 'text-white' : 'text-gray-300'}`}>
                                            {notification.title}
                                        </p>
                                        <p className="text-xs text-gray-400 mt-1 line-clamp-2">
                                            {notification.content}
                                        </p>
                                        <p className="text-xs text-gray-500 mt-1">
                                            {formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}
                                        </p>
                                    </div>
                                    {!notification.is_read && (
                                        <div className="w-2 h-2 bg-cyan-400 rounded-full flex-shrink-0 mt-2"></div>
                                    )}
                                </div>
                            </DropdownMenuItem>
                        );
                    })
                )}
                
                <div className="p-3 border-t border-white/10">
                    <Link to={createPageUrl("Messages")} className="text-xs text-cyan-400 hover:text-cyan-300">
                        View all messages →
                    </Link>
                </div>
            </DropdownMenuContent>
        </DropdownMenu>
    );
}