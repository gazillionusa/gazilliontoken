import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  GraduationCap, 
  Video, 
  FileText, 
  CheckCircle,
  Lock,
  Play,
  Award
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function EducationalHub() {
  const [completedLessons, setCompletedLessons] = useState([]);

  const courses = [
    {
      id: 'basics',
      title: 'Municipal Bonds 101',
      description: 'Learn the fundamentals of municipal bonds and how they work',
      lessons: 5,
      duration: '30 min',
      difficulty: 'Beginner',
      icon: BookOpen,
      color: 'from-blue-500 to-cyan-500'
    },
    {
      id: 'nft',
      title: 'NFT Bonds Explained',
      description: 'Understand how blockchain technology transforms traditional bonds',
      lessons: 4,
      duration: '25 min',
      difficulty: 'Beginner',
      icon: GraduationCap,
      color: 'from-purple-500 to-pink-500'
    },
    {
      id: 'investing',
      title: 'Smart Investing Strategies',
      description: 'Build a diversified bond portfolio and maximize returns',
      lessons: 6,
      duration: '45 min',
      difficulty: 'Intermediate',
      icon: Video,
      color: 'from-green-500 to-emerald-500'
    },
    {
      id: 'advanced',
      title: 'Advanced Bond Trading',
      description: 'Master secondary markets and trading strategies',
      lessons: 7,
      duration: '60 min',
      difficulty: 'Advanced',
      icon: FileText,
      color: 'from-orange-500 to-red-500',
      locked: true
    }
  ];

  const glossary = [
    {
      term: 'Municipal Bond',
      definition: 'A debt security issued by a state, municipality, or county to finance public projects.'
    },
    {
      term: 'NFT (Non-Fungible Token)',
      definition: 'A unique digital certificate stored on blockchain that represents ownership of an asset.'
    },
    {
      term: 'APY (Annual Percentage Yield)',
      definition: 'The real rate of return earned on an investment, taking into account the effect of compounding interest.'
    },
    {
      term: 'Maturity Date',
      definition: 'The date when the principal amount of a bond is to be paid back to the investor.'
    },
    {
      term: 'Yield',
      definition: 'The income return on an investment, expressed as a percentage of the investment cost.'
    },
    {
      term: 'Secondary Market',
      description: 'Where investors buy and sell securities they already own, providing liquidity.'
    }
  ];

  const videos = [
    {
      title: 'What are Municipal Bonds?',
      duration: '5:30',
      thumbnail: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/40b4f9049_ChatGPTImageSep22202503_43_36PM.png'
    },
    {
      title: 'How Gazillion Works',
      duration: '8:45',
      thumbnail: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/40b4f9049_ChatGPTImageSep22202503_43_36PM.png'
    },
    {
      title: 'Building Your Portfolio',
      duration: '12:20',
      thumbnail: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/40b4f9049_ChatGPTImageSep22202503_43_36PM.png'
    }
  ];

  return (
    <div className="min-h-screen px-4 sm:px-6 py-12">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <GraduationCap className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Educational <span className="text-gradient">Hub</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Master municipal bond investing with our comprehensive learning resources
          </p>
        </div>

        <Tabs defaultValue="courses" className="space-y-8">
          <TabsList className="glass-effect bg-transparent border-white/20">
            <TabsTrigger value="courses" className="data-[state=active]:bg-cyan-600">
              <BookOpen className="w-4 h-4 mr-2" />
              Courses
            </TabsTrigger>
            <TabsTrigger value="videos" className="data-[state=active]:bg-cyan-600">
              <Video className="w-4 h-4 mr-2" />
              Videos
            </TabsTrigger>
            <TabsTrigger value="glossary" className="data-[state=active]:bg-cyan-600">
              <FileText className="w-4 h-4 mr-2" />
              Glossary
            </TabsTrigger>
          </TabsList>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              {courses.map((course) => {
                const Icon = course.icon;
                return (
                  <Card 
                    key={course.id} 
                    className={`glass-effect border-white/10 bg-transparent ${
                      course.locked ? 'opacity-60' : 'hover:bg-white/5'
                    } transition-all duration-300`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between mb-4">
                        <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${course.color} flex items-center justify-center`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        {course.locked && <Lock className="w-5 h-5 text-gray-400" />}
                      </div>
                      <CardTitle className="text-white text-xl">{course.title}</CardTitle>
                      <p className="text-gray-400 text-sm mt-2">{course.description}</p>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2 mb-4">
                        <Badge variant="outline" className="text-gray-300 border-white/20">
                          {course.lessons} Lessons
                        </Badge>
                        <Badge variant="outline" className="text-gray-300 border-white/20">
                          {course.duration}
                        </Badge>
                        <Badge variant="outline" className={`border-white/20 ${
                          course.difficulty === 'Beginner' ? 'text-green-400' :
                          course.difficulty === 'Intermediate' ? 'text-yellow-400' :
                          'text-red-400'
                        }`}>
                          {course.difficulty}
                        </Badge>
                      </div>
                      <Button 
                        className={`w-full ${
                          course.locked 
                            ? 'bg-gray-600 cursor-not-allowed' 
                            : 'primary-gradient hover:opacity-90'
                        }`}
                        disabled={course.locked}
                      >
                        {course.locked ? (
                          <>
                            <Lock className="w-4 h-4 mr-2" />
                            Unlock with 100 XP
                          </>
                        ) : (
                          <>
                            <Play className="w-4 h-4 mr-2" />
                            Start Course
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* Videos Tab */}
          <TabsContent value="videos" className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              {videos.map((video, index) => (
                <Card key={index} className="glass-effect border-white/10 bg-transparent hover:bg-white/5 transition-all duration-300">
                  <CardContent className="p-0">
                    <div className="relative group cursor-pointer">
                      <img 
                        src={video.thumbnail} 
                        alt={video.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-black/50 group-hover:bg-black/30 transition-all duration-300 flex items-center justify-center rounded-t-lg">
                        <div className="w-16 h-16 rounded-full bg-cyan-500/80 group-hover:bg-cyan-500 transition-colors duration-300 flex items-center justify-center">
                          <Play className="w-8 h-8 text-white ml-1" />
                        </div>
                      </div>
                      <Badge className="absolute top-2 right-2 bg-black/70 text-white">
                        {video.duration}
                      </Badge>
                    </div>
                    <div className="p-4">
                      <h3 className="text-white font-semibold">{video.title}</h3>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Glossary Tab */}
          <TabsContent value="glossary" className="space-y-4">
            <Card className="glass-effect border-white/10 bg-transparent">
              <CardContent className="p-6">
                <div className="space-y-6">
                  {glossary.map((item, index) => (
                    <div key={index} className="border-b border-white/10 last:border-0 pb-4 last:pb-0">
                      <h3 className="text-white font-semibold text-lg mb-2">{item.term}</h3>
                      <p className="text-gray-300">{item.definition}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}