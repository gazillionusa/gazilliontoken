import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Card } from "@/components/ui/card";
import { Bot, User as UserIcon, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { cn } from "@/lib/utils";

const FunctionDisplay = ({ toolCall }) => {
    const name = toolCall?.name || 'Function';
    const status = toolCall?.status || 'pending';
    
    const isError = status === 'failed' || status === 'error';
    
    const statusConfig = {
        pending: { icon: Loader2, color: 'text-slate-400', text: 'Pending...', spin: true },
        running: { icon: Loader2, color: 'text-slate-500', text: 'Running...', spin: true },
        in_progress: { icon: Loader2, color: 'text-slate-500', text: 'Running...', spin: true },
        completed: isError ? 
            { icon: AlertCircle, color: 'text-red-500', text: 'Failed' } : 
            { icon: CheckCircle2, color: 'text-green-600', text: 'Success' },
        success: { icon: CheckCircle2, color: 'text-green-600', text: 'Success' },
        failed: { icon: AlertCircle, color: 'text-red-500', text: 'Failed' },
        error: { icon: AlertCircle, color: 'text-red-500', text: 'Failed' }
    }[status] || { icon: Loader2, color: 'text-slate-500', text: 'Working...' };
    
    const Icon = statusConfig.icon;
    
    return (
        <div className="mt-2 text-xs">
            <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-lg border bg-slate-800/50 border-slate-700")}>
                <Icon className={cn("h-3 w-3", statusConfig.color, statusConfig.spin && "animate-spin")} />
                <span className="text-slate-300">Checking: {name.split('.').pop()}</span>
                {statusConfig.text && (
                    <span className={cn("text-slate-400", isError && "text-red-400")}>
                        • {statusConfig.text}
                    </span>
                )}
            </div>
        </div>
    );
};

export default function MessageBubble({ message }) {
    const isUser = message.role === 'user';
    const hasContent = message.content && message.content.trim().length > 0;
    const hasToolCalls = message.tool_calls && message.tool_calls.length > 0;

    if (!hasContent && !hasToolCalls) {
      return null;
    }

    return (
        <div className={cn("flex gap-3 my-4", isUser ? "justify-end" : "justify-start")}>
            {!isUser && (
                <div className="h-8 w-8 rounded-full bg-cyan-500/20 flex items-center justify-center flex-shrink-0 mt-1">
                    <Bot className="w-5 h-5 text-cyan-400" />
                </div>
            )}
            <div className={cn("max-w-[85%] flex flex-col", isUser ? "items-end" : "items-start")}>
                {hasContent && (
                    <div className={cn(
                        "rounded-2xl px-4 py-2.5",
                        isUser 
                            ? "bg-cyan-600 text-white rounded-br-lg" 
                            : "bg-slate-700/50 border border-slate-600 text-gray-200 rounded-bl-lg"
                    )}>
                        <ReactMarkdown 
                            className="text-sm prose prose-sm prose-invert max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0"
                            components={{
                                p: ({ children }) => <p className="my-1 leading-relaxed">{children}</p>,
                                ul: ({ children }) => <ul className="my-1 ml-4 list-disc">{children}</ul>,
                                ol: ({ children }) => <ol className="my-1 ml-4 list-decimal">{children}</ol>,
                            }}
                        >
                            {message.content}
                        </ReactMarkdown>
                    </div>
                )}
                
                {hasToolCalls && (
                    <div className="space-y-1 mt-2">
                        {message.tool_calls.map((toolCall, idx) => (
                            <FunctionDisplay key={idx} toolCall={toolCall} />
                        ))}
                    </div>
                )}
            </div>
            {isUser && (
                <div className="h-8 w-8 rounded-full bg-slate-600 flex items-center justify-center flex-shrink-0 mt-1">
                    <UserIcon className="w-5 h-5 text-slate-300" />
                </div>
            )}
        </div>
    );
}