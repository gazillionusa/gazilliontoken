
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
    Search, 
    Users, 
    Building, 
    Landmark, 
    Zap,
    Award,
    MapPin,
    Briefcase,
    Loader2
} from 'lucide-react';
import { useGazillionSocial } from './GazillionSocial';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const ProfileCard = ({ profile, type }) => {
    const getIcon = () => {
        switch (type) {
            case 'user': return <Users className="w-8 h-8 text-cyan-400" />;
            case 'business': return <Briefcase className="w-8 h-8 text-green-400" />;
            case 'municipality': return <Landmark className="w-8 h-8 text-blue-400" />;
            default: return <Users className="w-8 h-8 text-gray-400" />;
        }
    };

    const getProfileUrl = () => {
        switch (type) {
            case 'business': 
            case 'municipality': 
                return createPageUrl(`CivicPartnerProfile?slug=${profile.name?.toLowerCase().replace(/\s+/g, '-')}`);
            default: 
                return '#';
        }
    };

    const getDisplayName = () => {
        return profile.name || 'Unknown';
    };

    const getSubtitle = () => {
        switch (type) {
            case 'business': return 'Zoo Vendor';
            case 'municipality': return 'Civic Guardian';
            default: return '';
        }
    };

    return (
        <Card className="glass-effect border-white/10 bg-transparent hover:border-cyan-400/50 transition-all duration-300">
            <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0">
                        {profile.logo_url ? (
                            <img 
                                src={profile.logo_url} 
                                alt={getDisplayName()} 
                                className="w-14 h-14 rounded-full object-cover"
                            />
                        ) : (
                            getIcon()
                        )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                        <h3 className="text-lg font-bold text-white truncate">{getDisplayName()}</h3>
                        <p className="text-cyan-300 text-sm">{getSubtitle()}</p>
                        
                        {profile.description && (
                            <p className="text-gray-400 text-sm mb-4 line-clamp-2">{profile.description}</p>
                        )}

                        <div className="flex items-center space-x-3 mt-3">
                            <Badge variant="outline" className="text-xs text-green-400">
                                Active Partner
                            </Badge>
                        </div>

                        <Link to={getProfileUrl()}>
                            <Button variant="outline" size="sm" className="mt-4 text-white border-white/20">
                                View Profile
                            </Button>
                        </Link>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
};

export default function SocialDirectory() {
    const { api } = useGazillionSocial();
    const [profiles, setProfiles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [filters, setFilters] = useState({
        type: 'all',
        location: '',
        sortBy: 'recent'
    });

    const searchProfiles = useCallback(async () => {
        setLoading(true);
        try {
            const results = await api.searchProfiles(searchQuery, filters);
            setProfiles(results);
        } catch (error) {
            console.error("Failed to search profiles:", error);
        } finally {
            setLoading(false);
        }
    }, [api, searchQuery, filters]);

    // Debounced search
    useEffect(() => {
        const timer = setTimeout(() => {
            searchProfiles();
        }, 300);

        return () => clearTimeout(timer);
    }, [searchProfiles]);

    return (
        <div className="max-w-6xl mx-auto space-y-6">
            {/* Header */}
            <div className="text-center">
                <h1 className="text-3xl font-bold text-white mb-2">
                    Community <span className="text-gradient">Directory</span>
                </h1>
                <p className="text-gray-300">
                    Discover civic partners and organizations in our network
                </p>
            </div>

            {/* Search & Filters */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardContent className="p-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                            <Input
                                placeholder="Search organizations..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="pl-10 glass-effect border-white/20 bg-transparent text-white"
                            />
                        </div>
                        
                        <Select value={filters.type} onValueChange={(value) => setFilters({...filters, type: value})}>
                            <SelectTrigger className="glass-effect border-white/20 bg-transparent text-white">
                                <SelectValue placeholder="All Types" />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-800 border-white/20">
                                <SelectItem value="all">All Partners</SelectItem>
                                <SelectItem value="business">Zoo Vendors</SelectItem>
                                <SelectItem value="municipality">Civic Guardians</SelectItem>
                            </SelectContent>
                        </Select>

                        <Select value={filters.sortBy} onValueChange={(value) => setFilters({...filters, sortBy: value})}>
                            <SelectTrigger className="glass-effect border-white/20 bg-transparent text-white">
                                <SelectValue placeholder="Sort By" />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-800 border-white/20">
                                <SelectItem value="recent">Most Recent</SelectItem>
                                <SelectItem value="name">Alphabetical</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                </CardContent>
            </Card>

            {/* Note about user profiles */}
            <Card className="glass-effect border-amber-400/20 bg-amber-400/5">
                <CardContent className="p-4">
                    <div className="flex items-center space-x-2 text-amber-300">
                        <Users className="w-5 h-5" />
                        <p className="text-sm">
                            Individual user profiles are not shown here for privacy. Connect directly through messaging or community posts.
                        </p>
                    </div>
                </CardContent>
            </Card>

            {/* Results */}
            {loading ? (
                <div className="flex justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
                </div>
            ) : profiles.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {profiles.map((profile, index) => (
                        <ProfileCard 
                            key={`${profile.profileType}-${profile.id}-${index}`}
                            profile={profile} 
                            type={profile.profileType}
                        />
                    ))}
                </div>
            ) : (
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-12 text-center">
                        <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <h3 className="text-xl font-bold text-white mb-2">No Organizations Found</h3>
                        <p className="text-gray-400">Try adjusting your search terms or filters</p>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
