import React, { useState, useEffect, useCallback } from 'react';
import { Post } from '@/api/entities';
import { Like } from '@/api/entities';
import { Comment } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  TrendingUp,
  Users,
  MessageSquare,
  Heart,
  Share,
  Zap,
  Award,
  Filter } from
'lucide-react';
import { useGazillionSocial } from './GazillionSocial';
import PostCard from '../community/PostCard';
import CreatePostForm from '../community/CreatePostForm';

export default function SocialFeed() {
  const { currentUser, socialStats, api } = useGazillionSocial();
  const [posts, setPosts] = useState([]);
  const [likes, setLikes] = useState({});
  const [comments, setComments] = useState({});
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('trending');

  const loadFeedData = useCallback(async () => {
    try {
      setLoading(true);
      let feedPosts = [];

      switch (activeFilter) {
        case 'trending':
          feedPosts = await Post.list('-created_date', 50);
          break;
        case 'following':
          feedPosts = await Post.list('-created_date', 25);
          break;
        case 'investments':
          feedPosts = await Post.filter({ post_type: 'investment_update' }, '-created_date');
          break;
        case 'local':
          feedPosts = await Post.list('-created_date', 30);
          break;
        default:
          feedPosts = await Post.list('-created_date', 20);
      }

      setPosts(feedPosts);

      if (feedPosts.length > 0) {
        const postIds = feedPosts.map((p) => p.id);

        // Bulk fetch likes and comments
        const [allLikes, allComments] = await Promise.all([
        Like.filter({ post_id: { '$in': postIds } }),
        Comment.filter({ post_id: { '$in': postIds } })]
        );

        // Group by post_id
        const likesByPost = allLikes.reduce((acc, like) => {
          (acc[like.post_id] = acc[like.post_id] || []).push(like);
          return acc;
        }, {});

        const commentsByPost = allComments.reduce((acc, comment) => {
          (acc[comment.post_id] = acc[comment.post_id] || []).push(comment);
          return acc;
        }, {});

        // Sort comments by date
        for (const postId in commentsByPost) {
          commentsByPost[postId].sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
        }

        setLikes(likesByPost);
        setComments(commentsByPost);
      } else {
        setLikes({});
        setComments({});
      }

    } catch (error) {
      console.error("Failed to load feed:", error);
    } finally {
      setLoading(false);
    }
  }, [activeFilter]);

  useEffect(() => {
    loadFeedData();
  }, [loadFeedData]);

  const handleDataRefresh = (postId) => {
    // Refreshes likes and comments for a specific post after an action
    Promise.all([
    Like.filter({ post_id: postId }),
    Comment.filter({ post_id: postId }, '-created_date')]
    ).then(([postLikes, postComments]) => {
      setLikes((prev) => ({ ...prev, [postId]: postLikes }));
      setComments((prev) => ({ ...prev, [postId]: postComments }));
    }).catch((err) => console.error("Failed to refresh post data", err));
  };


  return (
    <div className="max-w-4xl mx-auto space-y-6">
            {/* Social Stats Header */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <Users className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{socialStats.totalUsers}</p>
                        <p className="text-xs text-gray-400">Community Members</p>
                    </CardContent>
                </Card>
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <MessageSquare className="w-8 h-8 text-green-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{socialStats.totalPosts}</p>
                        <p className="text-xs text-gray-400">Posts Shared</p>
                    </CardContent>
                </Card>
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{socialStats.totalXP.toLocaleString()}</p>
                        <p className="text-xs text-gray-400">Civic XP Earned</p>
                    </CardContent>
                </Card>
                <Card className="glass-effect border-white/10 bg-transparent">
                    <CardContent className="p-4 text-center">
                        <Award className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                        <p className="text-2xl font-bold text-white">{socialStats.activeCampaigns}</p>
                        <p className="text-xs text-gray-400">Active Campaigns</p>
                    </CardContent>
                </Card>
            </div>

            {/* Feed Filters */}
            <Card className="glass-effect border-white/10 bg-transparent">
                <CardContent className="p-4">
                    <Tabs value={activeFilter} onValueChange={setActiveFilter}>
                        <TabsList className="glass-effect bg-transparent border-white/10 w-full">
                            <TabsTrigger value="trending" className="data-[state=active]:bg-white/10">
                                <TrendingUp className="w-4 h-4 mr-2" />
                                Trending
                            </TabsTrigger>
                            <TabsTrigger value="following" className="data-[state=active]:bg-white/10">
                                <Users className="w-4 h-4 mr-2" />
                                Following
                            </TabsTrigger>
                            <TabsTrigger value="investments" className="inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:text-foreground data-[state=active]:shadow-sm data-[state=active]:bg-white/10">
                                <Zap className="w-4 h-4 mr-2" />
                                Investments
                            </TabsTrigger>
                            <TabsTrigger value="local" className="data-[state=active]:bg-white/10">
                                <Filter className="w-4 h-4 mr-2" />
                                Local
                            </TabsTrigger>
                        </TabsList>
                    </Tabs>
                </CardContent>
            </Card>

            {/* Post Creation */}
            {currentUser &&
      <CreatePostForm
        currentUser={currentUser}
        onPostCreated={loadFeedData} />

      }

            {/* Posts Feed */}
            <div className="space-y-6">
                {posts.map((post) =>
        <PostCard
          key={post.id}
          post={post}
          currentUser={currentUser}
          initialLikes={likes[post.id] || []}
          initialComments={comments[post.id] || []}
          onDataRefresh={() => handleDataRefresh(post.id)} />

        )}
            </div>
        </div>);

}