import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Post } from '@/api/entities';
import { CivicPartner } from '@/api/entities';

// Gazillion Social Context
const GazillionSocialContext = createContext();

export const useGazillionSocial = () => {
    const context = useContext(GazillionSocialContext);
    if (!context) {
        throw new Error('useGazillionSocial must be used within GazillionSocialProvider');
    }
    return context;
};

// Social Configuration
const GAZILLION_SOCIAL_CONFIG = {
    name: "Gazillion Social",
    features: {
        enablePosts: true,
        enableComments: true,
        enableReactions: true,
        xpIntegration: true,
        badgeIntegration: true,
        bondSupport: true,
        communityWall: true
    },
    profileTypes: ["user", "business", "municipality"],
    searchFilters: ["type", "location", "xp", "badges"],
    integrations: {
        auth: "GazillionAuth",
        xpEngine: "GazillionXP",
        bondsAPI: "GazillionBonds"
    },
    ui: {
        theme: "GazillionTheme",
        branding: "Gazillion"
    }
};

export function GazillionSocialProvider({ children }) {
    const [currentUser, setCurrentUser] = useState(null);
    const [socialStats, setSocialStats] = useState({
        totalUsers: 0,
        totalPosts: 0,
        totalXP: 0,
        activeCampaigns: 0
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        initializeSocialLayer();
    }, []);

    const initializeSocialLayer = async () => {
        try {
            // Load current user
            const user = await User.me().catch(() => null);
            setCurrentUser(user);

            // Load social stats (without trying to fetch all users)
            const [posts, partners] = await Promise.all([
                Post.list('-created_date', 20).catch(() => []),
                CivicPartner.filter({ status: 'active' }).catch(() => [])
            ]);

            // Use mock/estimated stats since we can't access user list
            setSocialStats({
                totalUsers: 1250, // Mock value since we can't fetch users
                totalPosts: posts.length,
                totalXP: user?.lifetime_earnings || 0, // Only show current user's XP
                activeCampaigns: partners.length
            });

        } catch (error) {
            console.error("Failed to initialize Gazillion Social:", error);
            // Set fallback stats
            setSocialStats({
                totalUsers: 1250,
                totalPosts: 0,
                totalXP: 0,
                activeCampaigns: 0
            });
        } finally {
            setLoading(false);
        }
    };

    const socialAPI = {
        // Profile Management - can only search by known criteria
        getProfile: async (handle, type = 'user') => {
            try {
                switch (type) {
                    case 'user':
                        // Since we can't list users, we'll need to use a different approach
                        // For now, return null - in a real app, you'd need a search endpoint
                        return null;
                    case 'business':
                    case 'municipality':
                        const partners = await CivicPartner.filter({ 
                            name: handle.replace('-', ' '), 
                            partner_type: type === 'business' ? 'business' : 'municipality',
                            status: 'active'
                        });
                        return partners[0] || null;
                    default:
                        return null;
                }
            } catch (error) {
                console.error("Failed to get profile:", error);
                return null;
            }
        },

        // Content Management
        createPost: async (postData) => {
            if (!currentUser) throw new Error('Authentication required');
            
            return await Post.create({
                ...postData,
                author_name: currentUser.full_name,
                author_avatar_url: currentUser.avatar_image_url
            });
        },

        // XP Integration - only for current user
        awardXP: async (userId, amount, reason) => {
            if (!currentUser || currentUser.role !== 'admin') return false;
            
            try {
                // This will only work if current user is admin
                const user = await User.get(userId);
                await User.update(userId, {
                    lifetime_earnings: (user.lifetime_earnings || 0) + amount
                });
                return true;
            } catch (error) {
                console.error("Failed to award XP:", error);
                return false;
            }
        },

        // Search & Directory - limited to partners only
        searchProfiles: async (query, filters = {}) => {
            const results = [];
            
            try {
                // Only search partners since we can't access users
                if (!filters.type || ['business', 'municipality'].includes(filters.type)) {
                    const partnerFilter = {
                        status: 'active',
                        is_public: true
                    };
                    
                    if (filters.type && filters.type !== 'user') {
                        partnerFilter.partner_type = filters.type;
                    }
                    
                    const partners = await CivicPartner.filter(partnerFilter);
                    
                    let filteredPartners = partners;
                    if (query) {
                        filteredPartners = partners.filter(partner =>
                            partner.name?.toLowerCase().includes(query.toLowerCase()) ||
                            partner.description?.toLowerCase().includes(query.toLowerCase())
                        );
                    }
                    
                    results.push(...filteredPartners.map(p => ({ ...p, profileType: p.partner_type })));
                }
            } catch (error) {
                console.error("Search failed:", error);
            }

            return results;
        }
    };

    return (
        <GazillionSocialContext.Provider value={{
            config: GAZILLION_SOCIAL_CONFIG,
            currentUser,
            socialStats,
            loading,
            api: socialAPI,
            refreshStats: initializeSocialLayer
        }}>
            {children}
        </GazillionSocialContext.Provider>
    );
}

export default GazillionSocialProvider;