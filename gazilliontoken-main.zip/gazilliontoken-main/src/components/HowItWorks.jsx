import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { ArrowDown } from "lucide-react";

export default function HowItWorks() {
  const processSteps = [
    {
      title: "1. Submit Your Project",
      description: "Municipalities submit their infrastructure project details through our secure platform for review and approval."
    },
    {
      title: "2. Bond Creation",
      description: "Our proprietary blockchain technology creates a unique NFT bond backed by government guarantee for your project."
    },
    {
      title: "3. Investor Access",
      description: "Your bond becomes available to global investors through our marketplace with transparent pricing and terms."
    },
    {
      title: "4. Funding Distribution", 
      description: "Once purchased, funds are automatically distributed to your municipality to begin project implementation."
    },
    {
      title: "5. Automatic Returns",
      description: "Investors receive their returns through our automated system until bond maturity, when principal is repaid."
    }
  ];

  return (
    <div className="mb-20">
      <h2 className="text-3xl font-bold text-white text-center mb-12">
        How <span className="text-gradient">Gazillion</span> Works
      </h2>
      
      <div className="grid lg:grid-cols-2 gap-12 items-center">
        {/* Diagram */}
        <div className="glass-effect p-6 rounded-2xl">
          <div className="text-center py-12">
            <div className="w-24 h-24 primary-gradient rounded-full flex items-center justify-center mx-auto mb-6">
              <div className="text-white text-2xl font-bold">NFT</div>
            </div>
            <h3 className="text-xl font-semibold text-white mb-4">Blockchain-Powered Bonds</h3>
            <p className="text-gray-400">Our proprietary technology transforms traditional municipal bonds into secure, tradeable NFT assets</p>
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-6">
          {processSteps.map((step, index) => (
            <Card key={index} className="glass-effect border-white/10 bg-transparent">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-white mb-2">{step.title}</h3>
                <p className="text-gray-400 leading-relaxed">{step.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}