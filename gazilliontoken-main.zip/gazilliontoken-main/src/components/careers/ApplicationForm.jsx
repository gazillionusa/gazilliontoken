
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Character } from '@/api/entities';
import { Application } from '@/api/entities';
import { UploadPrivateFile } from '@/api/integrations';
import { Loader2, Sparkles, Upload, User, Mail, ShieldCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from "sonner";

export default function ApplicationForm({ job, user, isOpen, onClose, onSubmitSuccess }) {
    const [formData, setFormData] = useState({ coverLetter: '' });
    const [resumeFile, setResumeFile] = useState(null);
    const [characters, setCharacters] = useState([]);
    const [selectedChar, setSelectedChar] = useState(null);
    const [ageConfirmed, setAgeConfirmed] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        if (isOpen) {
            const fetchCharacters = async () => {
                const allChars = await Character.list();
                setCharacters(allChars);
                const defaultChar = allChars.find(c => c.character_id === 'zillie');
                if (defaultChar) {
                    setSelectedChar(defaultChar);
                }
            };
            fetchCharacters();
        } else {
            setFormData({ coverLetter: '' });
            setResumeFile(null);
            setSelectedChar(null);
            setAgeConfirmed(false);
        }
    }, [isOpen]);

    const handleFileChange = (e) => {
        if (e.target.files.length > 0) {
            setResumeFile(e.target.files[0]);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!resumeFile || !selectedChar) {
            toast.error("Please upload a resume and select a character.");
            return;
        }
        if (!ageConfirmed) {
            toast.error("You must confirm you are 18 or older to apply.");
            return;
        }
        setIsSubmitting(true);

        try {
            const { file_uri } = await UploadPrivateFile({ file: resumeFile });
            if (!file_uri) {
                throw new Error("Resume upload failed.");
            }

            const applicationData = {
                job_id: job.id,
                job_title: job.title,
                applicant_name: user.full_name,
                applicant_email: user.email,
                resume_uri: file_uri,
                cover_letter: formData.coverLetter,
                selected_character_image_url: selectedChar.image_url,
            };

            await Application.create(applicationData);
            
            onSubmitSuccess();

        } catch (error) {
            console.error("Application submission failed:", error);
            toast.error("Something went wrong. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="glass-effect border-white/10 bg-slate-900 text-white max-w-2xl">
                <DialogHeader>
                    <DialogTitle className="text-3xl text-gradient">Apply for {job?.title}</DialogTitle>
                    <DialogDescription className="text-gray-400">
                        We're excited to learn more about you! Your name and email are from your profile.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 py-4">
                    {/* Character Selection */}
                    <div>
                        <Label className="text-white text-lg font-semibold flex items-center gap-2 mb-3">
                            <Sparkles className="w-5 h-5 text-amber-400" />
                            Choose Your Character
                        </Label>
                        <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-3">
                            {characters.map(char => (
                                <div key={char.id} onClick={() => setSelectedChar(char)} className="cursor-pointer aspect-square rounded-full p-1 transition-all duration-300" style={{ background: selectedChar?.id === char.id ? 'linear-gradient(135deg, #4ECDC4, #26A69A)' : 'transparent' }}>
                                    <img src={char.image_url} alt={char.name} title={char.name} className="w-full h-full object-cover rounded-full bg-white/10" />
                                </div>
                            ))}
                        </div>
                    </div>
                    
                    {/* Applicant Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label htmlFor="name" className="text-white">Full Name</Label>
                            <div className="relative">
                                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input id="name" value={user?.full_name || ''} disabled className="glass-effect border-white/20 bg-transparent pl-10" />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="email" className="text-white">Email</Label>
                             <div className="relative">
                                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                <Input id="email" type="email" value={user?.email || ''} disabled className="glass-effect border-white/20 bg-transparent pl-10" />
                            </div>
                        </div>
                    </div>

                    {/* Resume Upload */}
                    <div className="space-y-2">
                        <Label htmlFor="resume" className="text-white">Resume/CV</Label>
                        <div className="relative">
                             <Input id="resume" type="file" required onChange={handleFileChange} className="hidden" accept=".pdf,.doc,.docx" />
                             <Label htmlFor="resume" className="glass-effect border-dashed border-white/30 h-24 flex items-center justify-center cursor-pointer text-gray-400 hover:border-cyan-400 hover:text-cyan-400 transition-colors">
                                {resumeFile ? (
                                    <span>{resumeFile.name}</span>
                                ) : (
                                    <div className="flex items-center gap-2"><Upload className="w-4 h-4"/> Click to upload file (.pdf, .doc, .docx)</div>
                                )}
                             </Label>
                        </div>
                    </div>

                    {/* Cover Letter */}
                    <div className="space-y-2">
                        <Label htmlFor="coverLetter" className="text-white">Cover Letter (Optional)</Label>
                        <Textarea id="coverLetter" placeholder="Tell us why you're a great fit for this role..." value={formData.coverLetter} onChange={(e) => setFormData({...formData, coverLetter: e.target.value})} className="glass-effect border-white/20 bg-transparent min-h-[120px]" />
                    </div>

                    {/* Age Confirmation */}
                    <div className="flex items-start space-x-3 pt-2">
                        <Checkbox id="age-confirm" checked={ageConfirmed} onCheckedChange={setAgeConfirmed} className="mt-1" />
                        <div className="grid gap-1.5 leading-none">
                             <Label htmlFor="age-confirm" className="text-sm font-medium text-white">
                                Age & Eligibility Confirmation
                            </Label>
                            <p className="text-xs text-gray-400">
                                By checking this box, I confirm that I am 18 years of age or older and legally eligible to work in the location specified for this role.
                            </p>
                        </div>
                    </div>


                    <DialogFooter>
                        <Button type="button" variant="ghost" onClick={onClose} disabled={isSubmitting} className="text-gray-300 hover:bg-white/10">Cancel</Button>
                        <Button type="submit" disabled={isSubmitting || !ageConfirmed} className="primary-gradient text-white hover:opacity-90 data-[disabled]:opacity-50 data-[disabled]:cursor-not-allowed">
                            {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <ShieldCheck className="w-4 h-4 mr-2"/>}
                            Submit Application
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
