
import React, { useState, useEffect, useCallback } from 'react';
import { Friendship } from '@/api/entities';
import { User } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, UserPlus, UserCheck, UserX, Users, Clock } from 'lucide-react';
import { toast } from "sonner";

export default function FriendsList({ currentUser }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [friends, setFriends] = useState([]);
    const [pendingRequests, setPendingRequests] = useState([]);
    const [sentRequests, setSentRequests] = useState([]);
    const [allUsers, setAllUsers] = useState([]);

    const loadAllUsers = useCallback(async () => {
        try {
            const users = await User.list();
            setAllUsers(users.filter(u => u.email !== currentUser.email));
        } catch (error) {
            console.error("Failed to load users:", error);
            toast.error("Failed to load users.");
            return []; // Return empty array on error
        }
    }, [currentUser.email]);

    const loadFriendsData = useCallback(async () => {
        try {
            const [myFriendships, theirFriendships] = await Promise.all([
                Friendship.filter({ created_by: currentUser.email }),
                Friendship.filter({ friend_email: currentUser.email })
            ]);

            // Friends (accepted relationships)
            const acceptedFriends = [
                ...myFriendships.filter(f => f.status === 'accepted'),
                ...theirFriendships.filter(f => f.status === 'accepted')
            ];
            setFriends(acceptedFriends);

            // Pending requests I received
            const pending = theirFriendships.filter(f => f.status === 'pending');
            setPendingRequests(pending);

            // Requests I sent that are still pending
            const sent = myFriendships.filter(f => f.status === 'pending');
            setSentRequests(sent);

        } catch (error) {
            console.error("Failed to load friends data:", error);
            toast.error("Failed to load friends data.");
        }
    }, [currentUser.email]);

    // This useEffect ensures that all users are loaded first,
    // and then friend-related data is loaded. This prevents
    // UI components from trying to find user details in an empty `allUsers` array.
    useEffect(() => {
        const initializeData = async () => {
            try {
                // Ensure all users are loaded and their state is updated
                await loadAllUsers();
                // Then, load the friends data. The UI will re-render with
                // the now-populated `allUsers` when friend states are updated.
                await loadFriendsData();
            } catch (error) {
                console.error("Error during initial community data load:", error);
                toast.error("Failed to load community data.");
            }
        };
        initializeData();
    }, [loadAllUsers, loadFriendsData]); // Dependencies are the memoized callbacks

    const handleSearch = (term) => {
        setSearchTerm(term);
        if (term.length < 2) {
            setSearchResults([]);
            return;
        }

        const results = allUsers.filter(user => 
            user.full_name?.toLowerCase().includes(term.toLowerCase()) ||
            user.email.toLowerCase().includes(term.toLowerCase())
        ).slice(0, 10);
        
        setSearchResults(results);
    };

    const sendFriendRequest = async (userEmail) => {
        try {
            await Friendship.create({
                friend_email: userEmail,
                status: 'pending',
                friendship_type: 'friend_request'
            });
            toast.success("Friend request sent!");
            loadFriendsData();
            setSearchResults([]);
            setSearchTerm('');
        } catch (error) {
            console.error("Failed to send friend request:", error);
            toast.error("Failed to send friend request.");
        }
    };

    const acceptFriendRequest = async (friendshipId) => {
        try {
            await Friendship.update(friendshipId, { status: 'accepted' });
            toast.success("Friend request accepted!");
            loadFriendsData();
        } catch (error) {
            console.error("Failed to accept friend request:", error);
            toast.error("Failed to accept friend request.");
        }
    };

    const rejectFriendRequest = async (friendshipId) => {
        try {
            await Friendship.delete(friendshipId);
            toast.success("Friend request declined.");
            loadFriendsData();
        } catch (error) {
            console.error("Failed to decline friend request:", error);
            toast.error("Failed to decline friend request.");
        }
    };

    const removeFriend = async (friendshipId) => {
        try {
            await Friendship.delete(friendshipId);
            toast.success("Friend removed.");
            loadFriendsData();
        } catch (error) {
            console.error("Failed to remove friend:", error);
            toast.error("Failed to remove friend.");
        }
    };

    const getFriendStatus = (userEmail) => {
        const sentRequest = sentRequests.find(f => f.friend_email === userEmail);
        const receivedRequest = pendingRequests.find(f => f.created_by === userEmail);
        const friendship = friends.find(f => 
            (f.friend_email === userEmail && f.created_by === currentUser.email) || 
            (f.created_by === userEmail && f.friend_email === currentUser.email)
        );

        if (friendship) return 'friends';
        if (sentRequest) return 'pending_sent';
        if (receivedRequest) return 'pending_received';
        return 'none';
    };

    const renderUserCard = (user, showActions = true) => {
        // Ensure user object is valid before rendering
        if (!user) {
            return null;
        }

        return (
            <div key={user.email} className="flex items-center justify-between p-4 glass-effect rounded-lg border border-white/10">
                <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10 border-2 border-cyan-400/30">
                        <AvatarImage src={user.avatar_image_url} alt={user.full_name} />
                        <AvatarFallback>{user.full_name?.charAt(0) || user.email.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <p className="font-semibold text-white">{user.full_name || 'Anonymous'}</p>
                        <p className="text-sm text-gray-400">{user.email}</p>
                        {user.bio && <p className="text-xs text-gray-500 mt-1">{user.bio.substring(0, 50)}{user.bio.length > 50 ? '...' : ''}</p>}
                    </div>
                </div>
                {showActions && renderActionButton(user)}
            </div>
        );
    };

    const renderActionButton = (user) => {
        const status = getFriendStatus(user.email);
        
        switch (status) {
            case 'friends':
                return (
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                            const friendship = friends.find(f => 
                                (f.friend_email === user.email && f.created_by === currentUser.email) || 
                                (f.created_by === user.email && f.friend_email === currentUser.email)
                            );
                            if (friendship) removeFriend(friendship.id);
                        }}
                        className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                    >
                        <UserX className="w-4 h-4 mr-2" />
                        Remove
                    </Button>
                );
            case 'pending_sent':
                return (
                    <Button variant="outline" size="sm" disabled className="border-yellow-500/50 text-yellow-400">
                        <Clock className="w-4 h-4 mr-2" />
                        Sent
                    </Button>
                );
            case 'pending_received':
                return (
                    <div className="flex gap-2">
                        <Button 
                            size="sm" 
                            onClick={() => {
                                const request = pendingRequests.find(f => f.created_by === user.email);
                                if (request) acceptFriendRequest(request.id);
                            }}
                            className="primary-gradient text-white"
                        >
                            <UserCheck className="w-4 h-4" />
                        </Button>
                        <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => {
                                const request = pendingRequests.find(f => f.created_by === user.email);
                                if (request) rejectFriendRequest(request.id);
                            }}
                            className="border-red-500/50 text-red-400"
                        >
                            <UserX className="w-4 h-4" />
                        </Button>
                    </div>
                );
            default:
                return (
                    <Button 
                        size="sm" 
                        onClick={() => sendFriendRequest(user.email)}
                        className="primary-gradient text-white"
                    >
                        <UserPlus className="w-4 h-4 mr-2" />
                        Add Friend
                    </Button>
                );
        }
    };

    return (
        <div className="max-w-4xl mx-auto p-6">
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-white mb-4">
                    <Users className="w-8 h-8 inline-block mr-3 text-cyan-400" />
                    Friends & Community
                </h1>
                
                {/* Search Bar */}
                <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                        placeholder="Search for friends by name or email..."
                        value={searchTerm}
                        onChange={(e) => handleSearch(e.target.value)}
                        className="pl-10 glass-effect border-white/20 bg-transparent text-white"
                    />
                </div>

                {/* Search Results */}
                {searchResults.length > 0 && (
                    <div className="mt-4 space-y-3 max-h-60 overflow-y-auto">
                        {searchResults.map(user => renderUserCard(user))}
                    </div>
                )}
            </div>

            <Tabs defaultValue="friends" className="w-full">
                <TabsList className="glass-effect bg-transparent border-white/10 w-full">
                    <TabsTrigger value="friends" className="data-[state=active]:bg-white/10">
                        Friends ({friends.length})
                    </TabsTrigger>
                    <TabsTrigger value="requests" className="data-[state=active]:bg-white/10">
                        Requests ({pendingRequests.length})
                    </TabsTrigger>
                    <TabsTrigger value="sent" className="data-[state=active]:bg-white/10">
                        Sent ({sentRequests.length})
                    </TabsTrigger>
                </TabsList>

                <TabsContent value="friends" className="mt-6">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                            <CardTitle className="text-white">Your Friends</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {friends.length === 0 ? (
                                <p className="text-gray-400 text-center py-8">
                                    No friends yet. Use the search above to find and add friends!
                                </p>
                            ) : (
                                friends.map(friendship => {
                                    const friendEmail = friendship.friend_email === currentUser.email 
                                        ? friendship.created_by 
                                        : friendship.friend_email;
                                    const friend = allUsers.find(u => u.email === friendEmail);
                                    return friend ? renderUserCard(friend) : null;
                                })
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="requests" className="mt-6">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                            <CardTitle className="text-white">Friend Requests</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {pendingRequests.length === 0 ? (
                                <p className="text-gray-400 text-center py-8">No pending friend requests.</p>
                            ) : (
                                pendingRequests.map(request => {
                                    const requester = allUsers.find(u => u.email === request.created_by);
                                    return requester ? renderUserCard(requester) : null;
                                })
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>

                <TabsContent value="sent" className="mt-6">
                    <Card className="glass-effect border-white/10 bg-transparent">
                        <CardHeader>
                            <CardTitle className="text-white">Sent Requests</CardTitle>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            {sentRequests.length === 0 ? (
                                <p className="text-gray-400 text-center py-8">No sent requests.</p>
                            ) : (
                                sentRequests.map(request => {
                                    const recipient = allUsers.find(u => u.email === request.friend_email);
                                    // When rendering sent requests, actions should not be shown, as they are managed from 'requests' or 'friends'
                                    return recipient ? renderUserCard(recipient, false) : null; 
                                })
                            )}
                        </CardContent>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    );
}
