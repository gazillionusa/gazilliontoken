
import React, { useState, useEffect } from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Comment } from '@/api/entities';
import { formatDistanceToNow } from 'date-fns';
import { toast } from "sonner";

export default function CommentSection({ postId, currentUser, initialComments = [], onCommentPosted }) {
    const [comments, setComments] = useState(initialComments);
    const [newComment, setNewComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    useEffect(() => {
        setComments(initialComments || []);
    }, [initialComments]);

    const handleCommentSubmit = async () => {
        if (!newComment.trim() || !currentUser) {
            if (!currentUser) toast.info("Please sign in to comment.");
            return;
        }

        setIsSubmitting(true);
        try {
            await Comment.create({
                post_id: postId,
                content: newComment
            });
            setNewComment('');
            onCommentPosted(); // Notify parent to refresh data
        } catch (error) {
            toast.error("Failed to post comment.");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="mt-6 border-t border-white/10 pt-6">
            {/* New Comment Form */}
            {currentUser && (
                <div className="flex items-start gap-4 mb-6">
                    <Avatar className="w-10 h-10">
                        <AvatarImage src={currentUser.avatar_image_url} />
                        <AvatarFallback>{currentUser.full_name?.charAt(0) || 'U'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                        <Textarea
                            placeholder="Add a comment..."
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            className="glass-effect border-white/20 bg-transparent text-white"
                        />
                        <Button 
                            onClick={handleCommentSubmit} 
                            disabled={isSubmitting} 
                            className="mt-2 primary-gradient text-white"
                            size="sm"
                        >
                            {isSubmitting ? "Posting..." : "Post Comment"}
                        </Button>
                    </div>
                </div>
            )}

            {/* Existing Comments */}
            <div className="space-y-4">
                {comments.map((comment) => (
                    <div key={comment.id} className="flex items-start gap-3">
                        <Avatar className="w-8 h-8">
                            {/* In a real app, you'd fetch the commenter's avatar */}
                            <AvatarImage src={`https://ui-avatars.com/api/?name=${comment.created_by.charAt(0)}&background=random`} />
                            <AvatarFallback>{comment.created_by.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1 glass-effect p-3 rounded-lg border border-white/10">
                            <div className="flex items-center justify-between text-xs mb-1">
                                <span className="font-semibold text-white">
                                    {comment.created_by.split('@')[0]}
                                </span>
                                <span className="text-gray-400">
                                    {formatDistanceToNow(new Date(comment.created_date), { addSuffix: true })}
                                </span>
                            </div>
                            <p className="text-sm text-gray-300">{comment.content}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
