
import React, { useState } from 'react';
import { Post } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, ImagePlus, Video, Music, Film, Send, TrendingUp } from 'lucide-react';
import { toast } from "sonner";

export default function CreatePostForm({ onPostCreated, currentUser }) {
    const [content, setContent] = useState('');
    const [postType, setPostType] = useState('text');
    const [mediaFile, setMediaFile] = useState(null);
    const [mediaMetadata, setMediaMetadata] = useState({
        title: '',
        artist_or_director: '',
        genre: '',
        year: '',
        rating: 5
    });
    const [tags, setTags] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!content.trim()) {
            toast.error("Post content cannot be empty.");
            return;
        }
        setIsSubmitting(true);

        try {
            let mediaUrl = null;
            if (mediaFile) {
                const { file_url } = await UploadFile({ file: mediaFile });
                mediaUrl = file_url;
            }

            const postData = {
                content,
                post_type: postType,
                tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag),
                author_name: currentUser.full_name,
                author_avatar_url: currentUser.avatar_image_url
            };

            if (postType === 'image') {
                postData.image_url = mediaUrl;
            } else if (postType === 'video') {
                postData.video_url = mediaUrl;
            } else if (postType === 'music_share' || postType === 'movie_share') {
                postData.media_metadata = mediaMetadata;
            }

            await Post.create(postData);

            // Reset form
            setContent('');
            setPostType('text');
            setMediaFile(null);
            setMediaMetadata({ title: '', artist_or_director: '', genre: '', year: '', rating: 5 });
            setTags('');
            // Reset the file input value if it exists
            const fileInput = document.getElementById('post-media-upload');
            if (fileInput) {
                fileInput.value = null;
            }
            
            toast.success("Your post has been published!");
            onPostCreated();
        } catch (error) {
            console.error("Failed to create post:", error);
            toast.error("Could not publish your post. Please try again.");
        } finally {
            setIsSubmitting(false);
        }
    };
    
    return (
        <div className="glass-effect p-6 rounded-2xl mb-8">
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex items-start gap-4">
                     <img 
                        src={currentUser.avatar_image_url || `https://ui-avatars.com/api/?name=${currentUser.full_name}&background=0D8ABC&color=fff`} 
                        alt="Your avatar" 
                        className="w-12 h-12 rounded-full border-2 border-cyan-400/50 object-cover"
                    />
                    <div className="flex-1 space-y-4">
                        <Textarea
                            placeholder="What's on your mind, Gazillionaire?"
                            value={content}
                            onChange={(e) => setContent(e.target.value)}
                            className="glass-effect border-white/20 bg-transparent min-h-[80px] text-white"
                            rows={3}
                        />
                        
                        <Tabs value={postType} onValueChange={setPostType} className="w-full">
                            <TabsList className="glass-effect bg-transparent border-white/10 w-full">
                                <TabsTrigger value="text" className="data-[state=active]:bg-white/10">
                                    <TrendingUp className="w-4 h-4 mr-2" />
                                    Text
                                </TabsTrigger>
                                <TabsTrigger value="image" className="data-[state=active]:bg-white/10">
                                    <ImagePlus className="w-4 h-4 mr-2" />
                                    Photo
                                </TabsTrigger>
                                <TabsTrigger value="video" className="data-[state=active]:bg-white/10">
                                    <Video className="w-4 h-4 mr-2" />
                                    Video
                                </TabsTrigger>
                                <TabsTrigger value="music_share" className="data-[state=active]:bg-white/10">
                                    <Music className="w-4 h-4 mr-2" />
                                    Music
                                </TabsTrigger>
                                <TabsTrigger value="movie_share" className="data-[state=active]:bg-white/10">
                                    <Film className="w-4 h-4 mr-2" />
                                    Movie
                                </TabsTrigger>
                            </TabsList>
                            
                            <TabsContent value="image" className="space-y-4">
                                <div>
                                    <input 
                                        type="file" 
                                        id="post-media-upload"
                                        className="hidden" 
                                        accept="image/*"
                                        onChange={(e) => setMediaFile(e.target.files[0])}
                                    />
                                    <Button type="button" variant="outline" className="w-full glass-effect border-white/20 text-gray-300" onClick={() => document.getElementById('post-media-upload').click()}>
                                        <ImagePlus className="w-5 h-5 mr-2" />
                                        {mediaFile ? <span className="text-cyan-400">{mediaFile.name}</span> : 'Choose Image'}
                                    </Button>
                                </div>
                            </TabsContent>
                            
                            <TabsContent value="video" className="space-y-4">
                                <div>
                                    <input 
                                        type="file" 
                                        id="post-media-upload"
                                        className="hidden" 
                                        accept="video/*"
                                        onChange={(e) => setMediaFile(e.target.files[0])}
                                    />
                                    <Button type="button" variant="outline" className="w-full glass-effect border-white/20 text-gray-300" onClick={() => document.getElementById('post-media-upload').click()}>
                                        <Video className="w-5 h-5 mr-2" />
                                        {mediaFile ? <span className="text-cyan-400">{mediaFile.name}</span> : 'Choose Video'}
                                    </Button>
                                </div>
                            </TabsContent>
                            
                            <TabsContent value="music_share" className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label className="text-white text-sm">Song/Album Title</Label>
                                        <Input
                                            value={mediaMetadata.title}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, title: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Song or album name"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-white text-sm">Artist</Label>
                                        <Input
                                            value={mediaMetadata.artist_or_director}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, artist_or_director: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Artist name"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-white text-sm">Genre</Label>
                                        <Input
                                            value={mediaMetadata.genre}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, genre: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Music genre"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-white text-sm">Rating (1-5)</Label>
                                        <Select value={mediaMetadata.rating.toString()} onValueChange={(value) => setMediaMetadata({...mediaMetadata, rating: parseInt(value)})}>
                                            <SelectTrigger className="glass-effect border-white/20 bg-transparent text-white">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent className="bg-slate-800 border-white/20">
                                                {[1,2,3,4,5].map(num => (
                                                    <SelectItem key={num} value={num.toString()} className="text-white focus:bg-white/10">
                                                        {'★'.repeat(num)} {num}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                            </TabsContent>
                            
                            <TabsContent value="movie_share" className="space-y-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <Label className="text-white text-sm">Movie/Show Title</Label>
                                        <Input
                                            value={mediaMetadata.title}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, title: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Movie or show name"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-white text-sm">Director/Creator</Label>
                                        <Input
                                            value={mediaMetadata.artist_or_director}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, artist_or_director: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Director or creator"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-white text-sm">Genre</Label>
                                        <Input
                                            value={mediaMetadata.genre}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, genre: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Movie genre"
                                        />
                                    </div>
                                    <div>
                                        <Label className="text-white text-sm">Year</Label>
                                        <Input
                                            value={mediaMetadata.year}
                                            onChange={(e) => setMediaMetadata({...mediaMetadata, year: e.target.value})}
                                            className="glass-effect border-white/20 bg-transparent text-white"
                                            placeholder="Release year"
                                        />
                                    </div>
                                </div>
                            </TabsContent>
                        </Tabs>
                        
                        <div>
                            <Label className="text-white text-sm">Tags (optional)</Label>
                            <Input
                                value={tags}
                                onChange={(e) => setTags(e.target.value)}
                                className="glass-effect border-white/20 bg-transparent text-white"
                                placeholder="Enter tags separated by commas (e.g., investing, music, lifestyle)"
                            />
                        </div>
                    </div>
                </div>
                
                <div className="flex justify-end">
                    <Button type="submit" disabled={isSubmitting} className="primary-gradient text-white hover:opacity-90">
                        {isSubmitting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                        Share Post
                    </Button>
                </div>
            </form>
        </div>
    );
}
