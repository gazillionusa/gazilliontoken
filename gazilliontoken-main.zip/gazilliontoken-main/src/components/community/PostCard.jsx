
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Like } from '@/api/entities';
import { 
    MessageSquare, 
    Heart, 
    Repeat, 
    Send,
    Award,
    TrendingUp,
    Music, 
    Film, 
    Star, 
    Tag
} from 'lucide-react';
import { toast } from "sonner";
import CommentSection from './CommentSection';
import { formatDistanceToNow } from 'date-fns';

export default function PostCard({ post, currentUser, initialLikes = [], initialComments = [], onDataRefresh }) {
    const [likes, setLikes] = useState(initialLikes);
    const [showComments, setShowComments] = useState(false);
    
    useEffect(() => {
        setLikes(initialLikes || []);
    }, [initialLikes]);

    const userHasLiked = currentUser ? likes.some(like => like.created_by === currentUser.email) : false;

    const handleLike = async () => {
        if (!currentUser) {
            toast.info("Please sign in to like posts.");
            return;
        }

        try {
            if (userHasLiked) {
                const likeToDelete = likes.find(like => like.created_by === currentUser.email);
                if (likeToDelete) {
                    await Like.delete(likeToDelete.id);
                }
            } else {
                await Like.create({ post_id: post.id });
            }
            onDataRefresh(); // Refresh data from parent
        } catch (error) {
            toast.error("Something went wrong.");
        }
    };

    const author = {
        full_name: post.author_name || "Anonymous",
        avatar_image_url: post.author_avatar_url || `https://ui-avatars.com/api/?name=A&background=808080&color=fff`
    };

    const authorName = post.author_name || 'Anonymous';
    const authorAvatar = post.author_avatar_url || 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/c8697d8dc_ChatGPTImageSep22202503_14_30PM.png';

    // Special rendering for automated investment updates
    if (post.post_type === 'investment_update') {
        return (
            <Card className="glass-effect p-6 rounded-2xl border border-cyan-400/20 bg-cyan-400/5">
                <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full primary-gradient flex items-center justify-center flex-shrink-0">
                        <TrendingUp className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <p className="text-gray-300 text-sm leading-relaxed">{post.content}</p>
                        <p className="text-xs text-gray-400 mt-2">
                            {formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}
                        </p>
                    </div>
                </div>
            </Card>
        );
    }

    const renderMediaContent = () => {
        switch (post.post_type) {
            case 'image':
                return post.image_url && (
                    <div className="mb-4">
                        <img src={post.image_url} alt="Post image" className="rounded-lg max-h-[400px] w-full object-cover" />
                    </div>
                );
            
            case 'video':
                return post.video_url && (
                    <div className="mb-4">
                        <video controls className="rounded-lg max-h-[400px] w-full">
                            <source src={post.video_url} />
                            Your browser does not support the video tag.
                        </video>
                    </div>
                );
            
            case 'music_share':
                return post.media_metadata && (
                    <div className="mb-4 glass-effect p-4 rounded-lg border border-cyan-400/20">
                        <div className="flex items-center gap-3 mb-2">
                            <Music className="w-6 h-6 text-cyan-400" />
                            <div>
                                <h4 className="text-white font-semibold">{post.media_metadata.title}</h4>
                                <p className="text-gray-300 text-sm">by {post.media_metadata.artist_or_director}</p>
                            </div>
                        </div>
                        <div className="flex justify-between text-sm text-gray-400">
                            <span>{post.media_metadata.genre}</span>
                            <div className="flex items-center gap-1">
                                {[...Array(post.media_metadata.rating || 5)].map((_, i) => (
                                    <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                ))}
                            </div>
                        </div>
                    </div>
                );
            
            case 'movie_share':
                return post.media_metadata && (
                    <div className="mb-4 glass-effect p-4 rounded-lg border border-purple-400/20">
                        <div className="flex items-center gap-3 mb-2">
                            <Film className="w-6 h-6 text-purple-400" />
                            <div>
                                <h4 className="text-white font-semibold">{post.media_metadata.title}</h4>
                                <p className="text-gray-300 text-sm">by {post.media_metadata.artist_or_director}</p>
                            </div>
                        </div>
                        <div className="flex justify-between text-sm text-gray-400">
                            <span>{post.media_metadata.genre} • {post.media_metadata.year}</span>
                            <div className="flex items-center gap-1">
                                {
                                [...Array(post.media_metadata.rating || 5)].map((_, i) => (
                                    <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                                ))
                                }
                            </div>
                        </div>
                    </div>
                );
            
            default:
                return null;
        }
    };

    return (
        <Card className="glass-effect border-white/10 bg-transparent">
            <CardContent className="p-6">
                <div className="flex items-start gap-4 mb-4">
                    <Avatar className="w-12 h-12 border-2 border-cyan-400/30">
                        <AvatarImage src={author.avatar_image_url} alt={author.full_name} />
                        <AvatarFallback>{author.full_name?.charAt(0) || 'A'}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                        <div className="flex items-center gap-2">
                            <p className="font-semibold text-white">{author.full_name}</p>
                            {post.post_type !== 'text' && (
                                <Badge variant="secondary" className="text-xs">
                                    {post.post_type.replace('_', ' ')}
                                </Badge>
                            )}
                        </div>
                        <p className="text-xs text-gray-400">{formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}</p>
                    </div>
                </div>

                <p className="text-gray-200 mb-4 whitespace-pre-wrap">{post.content}</p>

                {renderMediaContent()}

                {post.tags && post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 mb-4">
                        {post.tags.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs text-cyan-400 border-cyan-400/30">
                                <Tag className="w-3 h-3 mr-1" />
                                {tag}
                            </Badge>
                        ))}
                    </div>
                )}
                
                <div className="flex items-center gap-6 text-gray-400">
                    <Button variant="ghost" size="sm" onClick={handleLike} className={`flex items-center gap-2 hover:text-red-500 ${userHasLiked ? 'text-red-500' : ''}`}>
                        <Heart className={`w-5 h-5 ${userHasLiked ? 'fill-current' : ''}`} /> 
                        <span>{likes.length}</span>
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => setShowComments(!showComments)} className="flex items-center gap-2 hover:text-cyan-400">
                        <MessageSquare className="w-5 h-5" /> 
                        <span>{initialComments.length}</span>
                    </Button>
                </div>

                {showComments && (
                    <CommentSection 
                        postId={post.id} 
                        currentUser={currentUser}
                        initialComments={initialComments}
                        onCommentPosted={onDataRefresh}
                    />
                )}
            </CardContent>
        </Card>
    );
}
