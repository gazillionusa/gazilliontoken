import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Calculator, TrendingUp, DollarSign, Clock } from 'lucide-react';

export default function YieldCalculator({ bond }) {
  const [investment, setInvestment] = useState(bond?.current_price || 1000);
  const [holdingPeriod, setHoldingPeriod] = useState(12);
  
  const calculateReturns = () => {
    const principal = parseFloat(investment) || 0;
    const apy = bond?.apy || 6.5;
    const years = holdingPeriod / 12;
    
    const interest = principal * (apy / 100) * years;
    const total = principal + interest;
    const monthlyReturn = interest / holdingPeriod;
    
    return {
      principal,
      interest: interest.toFixed(2),
      total: total.toFixed(2),
      monthlyReturn: monthlyReturn.toFixed(2),
      effectiveAPY: apy
    };
  };

  const results = calculateReturns();

  return (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <CardTitle className="text-white text-xl flex items-center gap-2">
          <Calculator className="w-5 h-5 text-cyan-400" />
          Yield Calculator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Investment Amount */}
        <div className="space-y-2">
          <Label className="text-white">Investment Amount ($)</Label>
          <Input
            type="number"
            value={investment}
            onChange={(e) => setInvestment(e.target.value)}
            className="glass-effect border-white/20 text-white"
            min="100"
            step="100"
          />
        </div>

        {/* Holding Period */}
        <div className="space-y-2">
          <div className="flex justify-between">
            <Label className="text-white">Holding Period</Label>
            <span className="text-cyan-400 font-semibold">{holdingPeriod} months</span>
          </div>
          <Slider
            value={[holdingPeriod]}
            onValueChange={(value) => setHoldingPeriod(value[0])}
            min={1}
            max={120}
            step={1}
            className="w-full"
          />
        </div>

        {/* Results */}
        <div className="glass-effect p-4 rounded-lg space-y-3 border border-cyan-400/20">
          <div className="flex justify-between items-center">
            <span className="text-gray-400 flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Principal
            </span>
            <span className="text-white font-semibold">${results.principal.toLocaleString()}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-gray-400 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Interest Earned
            </span>
            <span className="text-green-400 font-semibold">${parseFloat(results.interest).toLocaleString()}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-gray-400 flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Monthly Return
            </span>
            <span className="text-cyan-400 font-semibold">${parseFloat(results.monthlyReturn).toLocaleString()}</span>
          </div>
          
          <div className="border-t border-white/10 pt-3 flex justify-between items-center">
            <span className="text-white font-semibold">Total Return</span>
            <span className="text-2xl font-bold text-gradient">${parseFloat(results.total).toLocaleString()}</span>
          </div>
          
          <div className="text-center text-sm text-gray-400 mt-2">
            Effective APY: <span className="text-cyan-400 font-semibold">{results.effectiveAPY}%</span>
          </div>
        </div>

        {bond?.is_tax_exempt && (
          <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
            <p className="text-green-400 text-sm">
              🎉 Tax-Exempt Interest - Your returns may be exempt from federal taxes
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}