import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Activity } from 'lucide-react';

export default function LiveMarketWidget() {
  const [marketData, setMarketData] = useState({
    btc: { price: 0, change: 0 },
    eth: { price: 0, change: 0 },
    totalVolume: 0
  });

  useEffect(() => {
    // Fetch live crypto prices (placeholder - integrate with real API)
    const fetchMarketData = async () => {
      // Example: CoinGecko API
      try {
        const response = await fetch(
          'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true'
        );
        const data = await response.json();
        
        setMarketData({
          btc: {
            price: data.bitcoin?.usd || 0,
            change: data.bitcoin?.usd_24h_change || 0
          },
          eth: {
            price: data.ethereum?.usd || 0,
            change: data.ethereum?.usd_24h_change || 0
          },
          totalVolume: 892000000 // Placeholder
        });
      } catch (error) {
        console.error('Failed to fetch market data:', error);
      }
    };

    fetchMarketData();
    const interval = setInterval(fetchMarketData, 60000); // Update every minute

    return () => clearInterval(interval);
  }, []);

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const formatChange = (change) => {
    const formatted = Math.abs(change).toFixed(2);
    return change >= 0 ? `+${formatted}%` : `-${formatted}%`;
  };

  return (
    <Card className="glass-effect border-white/10 bg-transparent">
      <CardHeader>
        <CardTitle className="text-white text-lg flex items-center gap-2">
          <Activity className="w-5 h-5 text-cyan-400" />
          Live Market
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* BTC */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-orange-500/20 flex items-center justify-center">
              <span className="text-orange-400 font-bold text-sm">₿</span>
            </div>
            <span className="text-white font-medium">BTC</span>
          </div>
          <div className="text-right">
            <div className="text-white font-semibold">{formatPrice(marketData.btc.price)}</div>
            <div className={`text-sm flex items-center gap-1 ${
              marketData.btc.change >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {marketData.btc.change >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {formatChange(marketData.btc.change)}
            </div>
          </div>
        </div>

        {/* ETH */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
              <span className="text-blue-400 font-bold text-sm">Ξ</span>
            </div>
            <span className="text-white font-medium">ETH</span>
          </div>
          <div className="text-right">
            <div className="text-white font-semibold">{formatPrice(marketData.eth.price)}</div>
            <div className={`text-sm flex items-center gap-1 ${
              marketData.eth.change >= 0 ? 'text-green-400' : 'text-red-400'
            }`}>
              {marketData.eth.change >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {formatChange(marketData.eth.change)}
            </div>
          </div>
        </div>

        {/* Market Stats */}
        <div className="border-t border-white/10 pt-3">
          <div className="flex justify-between items-center">
            <span className="text-gray-400 text-sm">24h NFT Bond Volume</span>
            <span className="text-cyan-400 font-semibold">${(marketData.totalVolume / 1000000).toFixed(1)}M</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}