
import React, { useEffect, useMemo, useState } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { useGazillionWallet } from "../hooks/useGazillionWallet";

/**
 * GazillionUSA – Plug‑and‑Play Minting Widget (Adapted for Base44)
 */

// NOTE: ABIs and ethers.js have been removed from the frontend.
// All contract interactions will be mediated by backend functions.

// Utility for formatting numbers without ethers
const fmt = (n, dec = 18) => {
  if (typeof n !== 'bigint') {
    // Fallback for non-bigint values
    const num = Number(n);
    if (isNaN(num)) return '0.00';
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 });
  }
  // Simple bigint to string conversion for display
  const s = n.toString();
  const len = s.length;
  if (len <= dec) {
    return "0." + "0".repeat(dec - len) + s;
  }
  return s.slice(0, len - dec) + "." + s.slice(len - dec);
};


export default function MintWidget({
  stablecoinAddress,
  bondAddress,
  defaultBondId = 1,
  chainId: targetChainId, // Renamed to avoid conflict with hook's chainId
  theme = "dark",
  onSuccess
}) {
  const { account, chainId, error: walletError, connectWallet } = useGazillionWallet();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  // State now managed more simply, or fetched from backend
  const [scSymbol, setScSymbol] = useState("GUSD");
  const [scDecimals, setScDecimals] = useState(18);
  const [scBal, setScBal] = useState(0n);

  const [bondId, setBondId] = useState(defaultBondId);
  const [quantity, setQuantity] = useState(1);
  const [bondPrice, setBondPrice] = useState(0n);
  const [saleActive, setSaleActive] = useState(false);
  const [bondURI, setBondURI] = useState("");
  
  // This is now handled by the hook
  useEffect(() => {
    if(walletError) {
      setErr(walletError);
    }
  }, [walletError]);
  
  // This effect will be simplified, relying on backend functions for data
  useEffect(() => {
    if (account && targetChainId && chainId && chainId !== `0x${targetChainId.toString(16)}`) {
        setErr(`Incorrect network. Please switch to the correct network in your wallet.`);
    } else {
        setErr(""); // Clear network error if chain is correct
    }

    // In a full implementation, we'd call a backend function here to get all token/bond data
    // e.g., base44.functions.invoke('getMintingData', { account, bondId })
    // For now, we keep the placeholder values.
    setSaleActive(true); // Assume sale is active for demonstration
  }, [account, bondId, chainId, targetChainId]);

  const requestStablecoinMint = async (usdAmount) => {
    try {
      if (!account) throw new Error("Connect wallet first");
      setBusy(true); setErr("");

      const { data: kyc } = await base44.functions.invoke('kycVerification');
      if (!kyc?.ok) throw new Error(kyc?.error || "KYC/AML not satisfied. Please complete verification.");

      // The createPaymentIntent function is now expected to handle the minting process
      const { data: intent } = await base44.functions.invoke('createPaymentIntent', {
        address: account,
        amount: usdAmount,
        currency: 'USD'
      });
      if (!intent?.ok || !intent.txHash) throw new Error(intent?.error || "Mint intent failed");
      
      toast.success("Mint request submitted successfully!", { description: `Tx: ${intent.txHash}` });
      if (onSuccess) onSuccess({ kind: "stablecoin-mint", txHash: intent.txHash, amount: String(usdAmount) });
      
      // We would ideally refresh the balance from the backend
      // setScBal(await fetchBalanceFromServer(account));

    } catch (e) {
      setErr(e.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const mintBond = async () => {
    try {
      if (!account) throw new Error("Connect wallet first");
      setBusy(true); setErr("");
      if (!saleActive) throw new Error("Sale is not active for this bond ID");

      // The mintBondNFT function will handle approval and minting
      const { data: result } = await base44.functions.invoke('mintBondNFT', {
        bondId,
        quantity,
        buyerAddress: account
      });

      if (!result?.success) throw new Error(result?.error || "Failed to mint bond.");

      toast.success("Bond NFT minted successfully!", { description: `Tx: ${result.transaction?.hash.slice(0,10)}...` });
      if (onSuccess) onSuccess({ kind: "bond-mint", txHash: result.transaction?.hash, bondId, quantity });

    } catch (e) {
      setErr(e.message || String(e));
    } finally {
      setBusy(false);
    }
  };

  const card = theme === "dark" ? "bg-zinc-900 text-zinc-100" : "bg-white text-zinc-900";
  const sub = theme === "dark" ? "text-zinc-300" : "text-zinc-600";
  const btn = theme === "dark" ? "bg-teal-500 hover:bg-teal-400 text-black" : "bg-teal-600 hover:bg-teal-700 text-white";
  const ipt = theme === "dark" ? "bg-zinc-800 border-zinc-700 text-zinc-100" : "bg-white border-zinc-200 text-zinc-900";

  return (
    <div className={`w-full max-w-3xl mx-auto p-4 ${theme === "dark" ? "bg-zinc-950" : "bg-zinc-50"}`}>
      <div className={`rounded-2xl shadow-sm border ${card}`}>
        <div className="p-6 border-b border-zinc-200/20">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">GazillionUSA Minting</h2>
            {!account ? (
              <button onClick={connectWallet} className={`px-4 py-2 rounded-xl ${btn}`}>Connect Wallet</button>
            ) : (
              <div className="text-sm font-mono">{account.slice(0, 6)}…{account.slice(-4)}</div>
            )}
          </div>
          <p className={`mt-2 text-sm ${sub}`}>Mint stablecoin (via USD deposit + server authorization) and mint Gazillion Bond NFTs using the stablecoin.</p>
        </div>

        {/* Stablecoin Mint */}
        <div className="p-6 grid md:grid-cols-2 gap-6">
          <div className={`rounded-xl border p-4 ${card}`}>
            <h3 className="text-lg font-semibold mb-2">Stablecoin</h3>
            <p className={`text-sm mb-3 ${sub}`}>Balance: <b>{fmt(scBal, scDecimals)} {scSymbol}</b></p>
            <StablecoinForm busy={busy} theme={theme} onMint={requestStablecoinMint} />
            <p className={`text-xs mt-3 ${sub}`}>Minting requires completed KYC/AML and server approval. USD funds settle off‑chain; your backend mints 1:1 on‑chain.</p>
          </div>

          {/* Bond Mint */}
          <div className={`rounded-xl border p-4 ${card}`}>
            <h3 className="text-lg font-semibold mb-2">Bond NFT (ERC‑1155)</h3>
            <div className="grid grid-cols-2 gap-3">
              <label className="text-sm">
                <span className={`${sub}`}>Bond ID</span>
                <input type="number" className={`mt-1 w-full px-3 py-2 rounded-lg border ${ipt}`} value={bondId} onChange={e => setBondId(Number(e.target.value))} />
              </label>
              <label className="text-sm">
                <span className={`${sub}`}>Quantity</span>
                <input type="number" className={`mt-1 w-full px-3 py-2 rounded-lg border ${ipt}`} min={1} value={quantity} onChange={e => setQuantity(Math.max(1, Number(e.target.value)))} />
              </label>
            </div>
            <div className={`text-sm mt-2 ${sub}`}>Price (each): {fmt(bondPrice, scDecimals)} {scSymbol}</div>
            <div className={`text-sm ${sub}`}>Total: {fmt(bondPrice * BigInt(Math.max(1, quantity)), scDecimals)} {scSymbol}</div>
            <div className="mt-3 flex items-center gap-2">
              <span className={`text-xs ${saleActive ? "text-emerald-500" : "text-amber-500"}`}>{saleActive ? "Sale Active" : "Sale Paused"}</span>
              {bondURI && <a className="text-xs underline" href={bondURI} target="_blank" rel="noreferrer">View Metadata</a>}
            </div>
            <button disabled={busy || !saleActive} onClick={mintBond} className={`mt-4 w-full px-4 py-2 rounded-xl ${btn} disabled:opacity-50`}>
              {busy ? "Processing…" : "Mint Bond"}
            </button>
          </div>
        </div>

        {err && (
          <div className="px-6 pb-6">
            <div className="rounded-xl border border-rose-200 bg-rose-50 text-rose-800 p-3 text-sm">
              {err}
            </div>
          </div>
        )}
      </div>

      <BackendSpec theme={theme} />
    </div>
  );
}

function StablecoinForm({ busy, theme, onMint }) {
  const [amount, setAmount] = useState("");
  const btn = theme === "dark" ? "bg-teal-500 hover:bg-teal-400 text-black" : "bg-teal-600 hover:bg-teal-700 text-white";
  const ipt = theme === "dark" ? "bg-zinc-800 border-zinc-700 text-zinc-100" : "bg-white border-zinc-200 text-zinc-900";

  const submit = async (e) => {
    e.preventDefault();
    const v = Number(amount);
    if (!Number.isFinite(v) || v <= 0) return;
    await onMint(v);
    setAmount("");
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <label className="text-sm block">
        <span className="text-zinc-500">USD Amount</span>
        <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="1000" className={`mt-1 w-full px-3 py-2 rounded-lg border ${ipt}`} />
      </label>
      <button type="submit" disabled={busy} className={`w-full px-4 py-2 rounded-xl ${btn} disabled:opacity-50`}>
        {busy ? "Processing…" : "Request Stablecoin Mint"}
      </button>
    </form>
  );
}

function BackendSpec({ theme }) {
  const sub = theme === "dark" ? "text-zinc-300" : "text-zinc-600";
  return (
    <div className="max-w-3xl mx-auto mt-6">
      <div className="text-sm">
        <h4 className="font-semibold mb-2">Backend API Spec (implement these functions):</h4>
        <ol className={`list-decimal ml-5 space-y-2 ${sub}`}>
          <li>
            <code>kycVerification</code> → <em>{`{ ok: boolean, ... }`}</em><br/>
            Returns if the user is cleared for minting.
          </li>
          <li>
            <code>createPaymentIntent</code> body: <em>{`{ address: string, amount: number }`}</em><br/>
            Server validates, processes fiat, mints stablecoin, returns <em>{`{ ok: true, txHash: string }`}</em>.
          </li>
        </ol>
        <p className={`mt-3 ${sub}`}>
          <b>Security tips:</b> Keep issuer keys off the client (use HSM/KMS on server), rate‑limit intents, monitor sanctions lists, and publish monthly reserve attestations.
        </p>
      </div>
    </div>
  );
}
