import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Circle, CheckCircle, XCircle, Scale, BarChart2 } from 'lucide-react';
import { Progress } from "@/components/ui/progress";

// Mock data for governance proposals
const mockProposals = [
  {
    id: 'GIP-001',
    title: 'Implement Secondary Market Trading Fees',
    status: 'active',
    category: 'Revenue',
    description: 'Introduce a 0.5% platform fee on all secondary market trades to fund development and security.',
    votes_for: 781234,
    votes_against: 123456,
    end_date: '2025-10-15T23:59:59Z'
  },
  {
    id: 'GIP-002',
    title: 'Add Support for Avalanche C-Chain',
    status: 'active',
    category: 'Technology',
    description: 'Integrate the Avalanche network to offer lower gas fees and faster transactions for bond minting.',
    votes_for: 450987,
    votes_against: 201765,
    end_date: '2025-10-20T23:59:59Z'
  },
  {
    id: 'GIP-003',
    title: 'Launch Bug Bounty Program',
    status: 'passed',
    category: 'Security',
    description: 'Establish a bug bounty program with a budget of $50,000 to enhance platform security.',
    votes_for: 987654,
    votes_against: 12345,
    end_date: '2025-09-30T23:59:59Z'
  },
  {
    id: 'GIP-004',
    title: 'Allocate Funds for Educational Content',
    status: 'failed',
    category: 'Community',
    description: 'Allocate $20,000 from the treasury to create a series of educational videos for new investors.',
    votes_for: 234567,
    votes_against: 345678,
    end_date: '2025-09-25T23:59:59Z'
  }
];

export default function GovernanceVoting() {
  const [proposals, setProposals] = useState(mockProposals);
  const [voted, setVoted] = useState({});

  const handleVote = (proposalId, vote) => {
    setVoted({ ...voted, [proposalId]: vote });
  };
  
  const statusConfig = {
    active: { color: "bg-blue-500", text: "Active", icon: Circle },
    passed: { color: "bg-green-500", text: "Passed", icon: CheckCircle },
    failed: { color: "bg-red-500", text: "Failed", icon: XCircle }
  };

  return (
    <div className="min-h-screen px-4 sm:px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <Scale className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">
            Platform <span className="text-gradient">Governance</span>
          </h1>
          <p className="text-lg text-gray-300">
            Your voice matters. Vote on proposals to shape the future of Gazillion.
          </p>
        </div>

        <div className="space-y-6">
          {proposals.map(proposal => {
            const totalVotes = proposal.votes_for + proposal.votes_against;
            const forPercentage = totalVotes > 0 ? (proposal.votes_for / totalVotes) * 100 : 0;
            const againstPercentage = totalVotes > 0 ? (proposal.votes_against / totalVotes) * 100 : 0;
            const { color, text, icon: Icon } = statusConfig[proposal.status];

            return (
              <Card key={proposal.id} className="glass-effect border-white/10 bg-transparent">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-white text-xl mb-2">{proposal.title}</CardTitle>
                    <Badge className={`${color} text-white flex items-center gap-2`}>
                      <Icon className="w-3 h-3"/>
                      {text}
                    </Badge>
                  </div>
                  <div className="text-sm text-gray-400">
                    ID: {proposal.id} &bull; Category: {proposal.category}
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-6">{proposal.description}</p>
                  
                  <div className="mb-4">
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-green-400 font-medium">For: {forPercentage.toFixed(2)}%</span>
                      <span className="text-red-400 font-medium">Against: {againstPercentage.toFixed(2)}%</span>
                    </div>
                    <Progress value={forPercentage} className="h-3 [&>div]:bg-green-500" />
                  </div>

                  {proposal.status === 'active' && !voted[proposal.id] && (
                    <div className="flex gap-4 mt-6">
                      <Button onClick={() => handleVote(proposal.id, 'for')} className="w-full bg-green-600 hover:bg-green-700">
                        <CheckCircle className="w-4 h-4 mr-2" /> Vote For
                      </Button>
                      <Button onClick={() => handleVote(proposal.id, 'against')} className="w-full bg-red-600 hover:bg-red-700">
                        <XCircle className="w-4 h-4 mr-2" /> Vote Against
                      </Button>
                    </div>
                  )}

                  {voted[proposal.id] && (
                     <div className="mt-6 text-center text-cyan-400 font-semibold p-3 bg-cyan-500/10 rounded-lg">
                       You voted "{voted[proposal.id].toUpperCase()}" on this proposal.
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}