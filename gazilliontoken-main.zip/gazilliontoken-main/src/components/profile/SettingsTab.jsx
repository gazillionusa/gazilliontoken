import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

export default function SettingsTab({ user }) {
  const queryClient = useQueryClient();
  const [formData, setFormData] = useState({
    full_name: user.full_name || '',
    bio: user.bio || '',
    location: user.location || '',
    avatar_image_url: user.avatar_image_url || '',
    cover_image_url: user.cover_image_url || '',
    social_links: {
      twitter: user.social_links?.twitter || '',
      linkedin: user.social_links?.linkedin || '',
      website: user.social_links?.website || '',
    }
  });

  const mutation = useMutation({
    mutationFn: (updatedData) => base44.auth.updateMe(updatedData),
    onSuccess: () => {
      toast.success('Profile updated successfully!');
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
    onError: (error) => {
      toast.error('Failed to update profile', { description: error.message });
    },
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSocialChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ 
        ...prev, 
        social_links: {
            ...prev.social_links,
            [name]: value
        }
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    mutation.mutate(formData);
  };

  return (
    <Card className="glass-effect max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-white">Edit Profile</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="full_name" className="text-gray-300">Full Name</Label>
            <Input id="full_name" name="full_name" value={formData.full_name} onChange={handleInputChange} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="bio" className="text-gray-300">Bio</Label>
            <Textarea id="bio" name="bio" value={formData.bio} onChange={handleInputChange} placeholder="Tell us a little about yourself" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="location" className="text-gray-300">Location</Label>
            <Input id="location" name="location" value={formData.location} onChange={handleInputChange} placeholder="City, State" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="avatar_image_url" className="text-gray-300">Avatar URL</Label>
            <Input id="avatar_image_url" name="avatar_image_url" value={formData.avatar_image_url} onChange={handleInputChange} placeholder="https://..." />
          </div>
           <div className="space-y-2">
            <Label htmlFor="cover_image_url" className="text-gray-300">Cover Image URL</Label>
            <Input id="cover_image_url" name="cover_image_url" value={formData.cover_image_url} onChange={handleInputChange} placeholder="https://..." />
          </div>
          
           <div className="space-y-4">
             <h3 className="text-lg font-medium text-white">Social Links</h3>
             <div className="space-y-2">
                <Label htmlFor="twitter" className="text-gray-300">Twitter URL</Label>
                <Input id="twitter" name="twitter" value={formData.social_links.twitter} onChange={handleSocialChange} placeholder="https://twitter.com/username"/>
             </div>
             <div className="space-y-2">
                <Label htmlFor="linkedin" className="text-gray-300">LinkedIn URL</Label>
                <Input id="linkedin" name="linkedin" value={formData.social_links.linkedin} onChange={handleSocialChange} placeholder="https://linkedin.com/in/username"/>
             </div>
              <div className="space-y-2">
                <Label htmlFor="website" className="text-gray-300">Website URL</Label>
                <Input id="website" name="website" value={formData.social_links.website} onChange={handleSocialChange} placeholder="https://your-website.com"/>
             </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button type="submit" disabled={mutation.isPending} className="primary-gradient">
            {mutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
            Save Changes
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}