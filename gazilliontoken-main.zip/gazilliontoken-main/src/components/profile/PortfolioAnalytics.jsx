import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

// Mock data for demonstration purposes
const portfolioData = [
  { name: 'Infrastructure', value: 40000 },
  { name: 'Green Energy', value: 25000 },
  { name: 'Education', value: 15000 },
  { name: 'Healthcare', value: 20000 },
];

const riskData = [
    { name: 'Low Risk', value: 65000 },
    { name: 'Medium Risk', value: 35000 },
];

const COLORS_CATEGORY = ['#14B8A6', '#5EEAD4', '#0D9488', '#F0FDF4'];
const COLORS_RISK = ['#14B8A6', '#FDE047'];

export default function PortfolioAnalytics() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="text-white">Portfolio by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={portfolioData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                  {portfolioData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS_CATEGORY[index % COLORS_CATEGORY.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(30, 41, 59, 0.8)', border: '1px solid #334155', borderRadius: '0.5rem' }}
                  labelStyle={{ color: '#cbd5e1' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
       <Card className="glass-effect">
        <CardHeader>
          <CardTitle className="text-white">Portfolio by Risk</CardTitle>
        </CardHeader>
        <CardContent>
          <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={riskData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                  {riskData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS_RISK[index % COLORS_RISK.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: 'rgba(30, 41, 59, 0.8)', border: '1px solid #334155', borderRadius: '0.5rem' }}
                  labelStyle={{ color: '#cbd5e1' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}