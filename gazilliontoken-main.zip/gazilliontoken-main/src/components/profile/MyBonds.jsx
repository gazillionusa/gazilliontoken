import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, ShieldCheck, TrendingUp } from 'lucide-react';
import { format, parseISO } from 'date-fns';

export default function MyBonds({ user }) {
  const { data: holdings, isLoading } = useQuery({
    queryKey: ['userHoldings', user.email],
    queryFn: () => base44.entities.UserHolding.filter({ user_email: user.email }),
    enabled: !!user.email,
  });

  if (isLoading) {
    return <div className="flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-teal-400" /></div>;
  }

  if (!holdings || holdings.length === 0) {
    return (
      <Card className="glass-effect text-center">
        <CardContent className="p-10">
          <h3 className="text-lg font-semibold text-white">No Bonds Held</h3>
          <p className="text-gray-400 mt-2">Your portfolio is empty. Explore the marketplace to start investing.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {holdings.map(holding => (
        <Card key={holding.id} className="glass-effect hover:border-teal-500/50 transition-all">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-xl text-teal-300">{holding.bond_name}</CardTitle>
                <p className="text-sm text-gray-400">{holding.municipality_name}</p>
              </div>
              <ShieldCheck className="w-6 h-6 text-green-400" />
            </div>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-500">Yield (APY)</p>
              <p className="font-semibold text-lg text-white">{holding.yield_rate}%</p>
            </div>
            <div>
              <p className="text-gray-500">Maturity</p>
              <p className="font-semibold text-lg text-white">{format(parseISO(holding.maturity_date), 'MMM yyyy')}</p>
            </div>
            <div>
              <p className="text-gray-500">Tokens Held</p>
              <p className="font-semibold text-lg text-white">{holding.token_quantity.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-gray-500">Accrued Interest</p>
              <p className="font-semibold text-lg text-white">${holding.accrued_interest.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}