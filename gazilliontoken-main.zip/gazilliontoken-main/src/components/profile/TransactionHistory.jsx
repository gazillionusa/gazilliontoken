import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, ArrowRight } from 'lucide-react';
import { format, parseISO } from 'date-fns';

export default function TransactionHistory({ user }) {
  const { data: purchases, isLoading } = useQuery({
    queryKey: ['userPurchases', user.id],
    queryFn: () => base44.entities.UserPurchase.filter({ user_id: user.id }, '-purchase_timestamp'),
    enabled: !!user.id,
  });

  if (isLoading) {
    return <div className="flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-teal-400" /></div>;
  }

  if (!purchases || purchases.length === 0) {
    return (
      <Card className="glass-effect text-center">
        <CardContent className="p-10">
          <h3 className="text-lg font-semibold text-white">No Recent Activity</h3>
          <p className="text-gray-400 mt-2">Your recent bond purchases will appear here.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect">
      <CardHeader>
        <CardTitle className="text-white">Recent Purchases</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="divide-y divide-gray-700">
          {purchases.map(p => (
            <li key={p.id} className="py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center">
              <div>
                <p className="font-semibold text-white">Invested in {p.bond_name}</p>
                <p className="text-sm text-gray-400">
                  {format(parseISO(p.purchase_timestamp), 'PPpp')}
                </p>
                <p className="text-sm text-green-400 mt-1">+{p.civic_rewards_earned} Civic XP</p>
              </div>
              <div className="text-right mt-2 sm:mt-0">
                <p className="font-bold text-lg text-teal-300">${p.purchase_amount.toLocaleString()}</p>
                <a href={`https://etherscan.io/tx/${p.transaction_hash}`} target="_blank" rel="noreferrer" className="text-xs text-gray-500 hover:text-teal-400 flex items-center justify-end gap-1">
                  View TX <ArrowRight className="w-3 h-3"/>
                </a>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}