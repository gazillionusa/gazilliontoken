import React, { useState } from 'react';
import { User } from '@/api/entities';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Users, Building, Landmark, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function GazillionGate() {
    const [loading, setLoading] = useState(false);

    const handleLogin = async () => {
        setLoading(true);
        try {
            await User.login();
        } catch (error) {
            console.error("Login failed:", error);
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
            <style>{`
                .teal-gradient {
                    background: linear-gradient(135deg, #008080, #00a0a0);
                }
            `}</style>
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                     <img
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68ad3bf0aa50c66bb89de466/40b4f9049_ChatGPTImageSep22202503_43_36PM.png"
                        alt="Gazillion Logo"
                        className="w-20 h-20 mx-auto mb-4"
                    />
                    <h1 className="text-4xl font-bold text-slate-800">Sign in to Gazillion</h1>
                    <p className="text-slate-600 mt-2">Connect with investors and the world around you.</p>
                </div>
                
                <Card className="bg-white shadow-lg border-gray-200">
                    <CardContent className="p-8 space-y-6">
                         <Button 
                            onClick={handleLogin}
                            disabled={loading}
                            className="w-full teal-gradient text-white font-semibold py-3 text-base rounded-md hover:opacity-90"
                        >
                            {loading ? (
                                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                            ) : (
                                "Log In"
                            )}
                        </Button>

                         <div className="relative">
                            <div className="absolute inset-0 flex items-center">
                                <span className="w-full border-t border-gray-300" />
                            </div>
                            <div className="relative flex justify-center text-xs uppercase">
                                <span className="bg-white px-2 text-gray-500">Or continue with</span>
                            </div>
                        </div>

                         <div className="grid grid-cols-2 gap-4">
                            <Button variant="outline" className="w-full" onClick={handleLogin}>
                                <svg role="img" viewBox="0 0 24 24" className="mr-2 h-4 w-4"><path fill="currentColor" d="M12.48 10.92v3.28h7.84c-.24 1.84-.85 3.18-1.73 4.1-1.02 1.08-2.58 1.9-5.24 1.9-4.56 0-8.3-3.67-8.3-8.17s3.74-8.17 8.3-8.17c2.62 0 4.37 1.04 5.4 2.02l2.6-2.6C18.4 1.53 15.7.02 12.48.02c-6.6 0-11.95 5.36-11.95 11.98s5.35 11.98 11.95 11.98c3.22 0 6.02-1.08 8.03-3.04 2.05-2.01 2.6-5.02 2.6-7.32 0-.6-.05-1.18-.15-1.72h-10.4z"></path></svg>
                                Google
                            </Button>
                             <Button variant="outline" className="w-full" onClick={handleLogin}>
                                <svg role="img" viewBox="0 0 24 24" className="mr-2 h-4 w-4"><path fill="currentColor" d="M12.032 6.302c-1.34 0-2.39.813-2.39 2.152 0 1.34 1.05 2.152 2.39 2.152 1.34 0 2.39-.812 2.39-2.152 0-1.339-1.05-2.152-2.39-2.152m1.075 11.162c.39 0 .705-.333.705-.747 0-.413-.315-.747-.705-.747-.39 0-.705.334-.705.747 0 .414.315.747.705.747m-2.155.005c.39 0 .705-.333.705-.747 0-.413-.315-.747-.705-.747-.39 0-.705.334-.705.747 0 .414.315.747.705.747m-1.025-17.469c3.42 0 5.613 2.06 5.613 5.347 0 3.12-1.923 5.455-4.83 5.455-1.223 0-2.15-.55-2.82-1.232l-.203.186v1.01h-1.573V.002h1.573v5.18c.67-.813 1.63-1.428 2.94-1.428m7.02 10.375c1.385 0 2.22-.843 2.22-2.06 0-1.218-.835-2.06-2.22-2.06-1.385 0-2.22.842-2.22 2.06 0 1.217.835 2.06 2.22 2.06M23.997 12.002c0 6.627-5.372 12-12 12s-12-5.373-12-12c0-6.628 5.372-12 12-12s12 5.372 12 12"></path></svg>
                                Apple
                            </Button>
                        </div>
                        
                         <div className="text-center text-sm">
                            <p className="text-gray-500">
                                <a href="#" className="underline font-medium text-slate-600 hover:text-teal-600">Forgot password?</a>
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <div className="text-center mt-6 text-sm text-slate-600">
                    <p>
                        Don't have an account? <Link to={createPageUrl("Onboarding")} className="font-semibold text-teal-600 hover:underline">Create a Page for a Person, Municipality, or Business</Link>.
                    </p>
                </div>
            </div>
        </div>
    );
}