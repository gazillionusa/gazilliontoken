import React from 'react';
import { ShieldCheck } from 'lucide-react';

export default function AntiPhishingBanner() {
  return (
    <div className="bg-cyan-600 text-white text-center py-2 text-sm font-semibold flex items-center justify-center gap-2">
        <ShieldCheck className="w-4 h-4" />
        <span>Always verify you are on an official Gazillion domain.</span>
    </div>
  );
}